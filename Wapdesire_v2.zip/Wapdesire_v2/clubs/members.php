<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CLUB MEMBERS/////////////////////////

$clinfo=mysql_fetch_array(mysql_query("SELECT name, owner, description, rules, logo, points, created FROM clubs WHERE id='".$id."'"));
addonline(getuid_sid($sid),"Viewing Club Members","");
echo head_tag(getnick_sid($sid)."@Club Members",1,getnick_sid($sid));
$title="<b>Club Members</b>";
$main="<p align=".align().">\n";
$cowner=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
if($page==""||$page<=0)$page=1;
$noi=
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$id."' AND accepted='1'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT uid, joined, points FROM clubmembers WHERE clubid='".$id."' AND accepted='1' ORDER BY joined DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
echo mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
$main.="<a href=\"../profile.php?who=$item[0]&amp;sid=$sid\">".getnick_uid($item[0])."</a>: \n";
if($cowner[0]==getuid_sid($sid)){
$main.="<a href=\"./delete.php?user=1&amp;who=$item[0]&amp;id=$id&amp;sid=$sid\">Remove</a><br/>\n";
}
$main.="Joined: ".date("d/m/y", $item[1])." - Club Points: $item[2]<br/>\n";
}
}
if($page>1){
$main.="<br/><a href=\"./members.php?id=$id&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./members.php?id=$id&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("members","","",$sid);}
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>