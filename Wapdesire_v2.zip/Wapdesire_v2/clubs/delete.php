<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////DELETE CLUB/////////////////////////

if($user==1)
{
addonline(getuid_sid($sid),"Removing Club Member","");
echo head_tag(getnick_sid($sid)."@Removing Club Member",1,getnick_sid($sid));
$title="<b>Removing Club Member</b>";
$main="<p align=".align().">\n";
$cowner=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
if($cowner[0]==getuid_sid($sid)){
$res=mysql_query("DELETE FROM clubmembers WHERE clubid='".$id."' AND uid='".$who."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Member deleted from your club";
}else{
$main.="<img src=\"../images/notok.gif\" alt=\"[x]\"/><br/>Database Error!";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Deleting Club","");
echo head_tag(getnick_sid($sid)."@Deleting Club",1,getnick_sid($sid));
$title="<b>Deleting Club</b>";
$main="<p align=".align().">\n";
if(club_tools(getuid_sid($sid))){
$fid=mysql_fetch_array(mysql_query("SELECT id FROM forums WHERE clubid='".$id."'"));
$topics=mysql_query("SELECT id FROM forumtopics WHERE fid=".$fid[0]."");
if(mysql_num_rows($topics)>0){
while($topic=mysql_fetch_array($topics)){
$res=mysql_query("DELETE FROM forumposts WHERE thread='".$topic[0]."'");
}
}
$res=mysql_query("DELETE FROM forumtopics WHERE fid='".$fid[0]."'");
$res=mysql_query("DELETE FROM forums WHERE clubid='".$id."'");
$res=mysql_query("DELETE FROM chatrooms WHERE clubid='".$id."'");
$res=mysql_query("DELETE FROM clubmembers WHERE clubid='".$id."'");
$res=mysql_query("DELETE FROM announcements WHERE clubid='".$id."'");
$res=mysql_query("DELETE FROM clubs WHERE id=".$id."");
echo mysql_error();
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Club Deleted\n";
}else{
$main.="<img src=\"../images/notok.gif\" alt=\"[x]\"/><br/>Database Error\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>