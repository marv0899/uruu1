<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CLUBS/////////////////////////

if($create==1)
{
addonline(getuid_sid($sid),"Creating Announcement","");
echo head_tag(getnick_sid($sid)."@Create Announcement",1,getnick_sid($sid));
$title="<b>Create Announcement</b>";
$cow=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
if($cow[0]!=getuid_sid($sid)){
$main="<p align=".align().">
This club is not yours!
</p>\n";
}else{
$main="<div class=".align().">
<form action=\"./announcements.php?save=1&amp;id=$id&amp;sid=$sid\" method=\"post\">
Text:<input name=\"antx\" maxlength=\"200\"/><br/>
<input type=\"Submit\" value=\"Announce\"/>
</form>
</div>\n";
}
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
exit;
}

else if($save==1)
{
addonline(getuid_sid($sid),"Creating Announcement","");
echo head_tag(getnick_sid($sid)."@Creating Announcement",1,getnick_sid($sid));
$title="<b>Creating Announcement</b>";
$cow=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
$main="<p align=".align().">\n";
if($cow[0]!=getuid_sid($sid)){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>This is not your club!\n";
}else{
$res=mysql_query("INSERT INTO announcements SET text='".$antx."', clubid='".$id."', date='".time()."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Announcement Added!\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Database Error\n";
}
}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"deleting Announcement","");
echo head_tag(getnick_sid($sid)."@deleting Announcement",1,getnick_sid($sid));
$title="<b>deleting Announcement</b>";
$main="<p align=".align().">\n";
$pid=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
$exs=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM announcements WHERE id='".$anid."' AND clubid='".$id."'"));
if((getuid_sid($sid)==$pid[0])&&($exs[0]>0)){
$res=mysql_query("DELETE FROM announcements WHERE id='".$anid."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Announcement Deleted\n";
}else{
echo "<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Database Error!\n";
}
}else{
echo "<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Yo can't delete this announcement!\n";
}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Announcements","");
echo head_tag(getnick_sid($sid)."@Announcements",1,getnick_sid($sid));
$title="<b>Announcements</b>";
$main="<p align=".align().">\n";
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM announcements WHERE clubid='".$id."'"));
$items_per_page=5;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, text, date FROM announcements WHERE clubid='".$id."' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$cow=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
$items=mysql_query($sql);
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
$main.="$item[1]<br/>
<small>(".date("D jS M y",$item[2]).")</small><br/>\n";
if($cow[0]==getuid_sid($sid)){
$main.="<a href=\"./announcements.php?delete=1&amp;anid=$item[0]&amp;id=$id&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[x]\"/></a><br/>\n";
}
}
}
if($page>1){
$main.="<br/><a href=\"./announcements.php?id=$id&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./announcements.php?id=$id&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("announcements","","",$sid);}
if($cow[0]==getuid_sid($sid)){
$main.="<p align=".align().">\n<a href=\"./announcements.php?create=1&amp;id=$id&amp;sid=$sid\">Announce!</a></p>\n";
}
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>