<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CLUBS/////////////////////////

addonline(getuid_sid($sid),"Clubs","");
echo head_tag(getnick_sid($sid)."@Clubs",1,getnick_sid($sid));
$title="<b>Clubs</b>";
$main="<p align=".align().">
Clubs are small communities that users can create<br/>
every community should have things in common<br/>
for example a community for goths, sex freaks, alocholics<br/>
rappers and anythin else you can think of<br/>
currently people who have more than 200 points can only create clubs<br/>
every user can create up to maximum of 3 clubs<br/>
using forums, chat or inviting friends etc...<br/>
will get you more points,<br/>You can also get club points,<br/>
the more users that join and more activities in your club will put ur club on top\n";
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubs WHERE owner='".getuid_sid($sid)."'"));
$uclubs=mysql_query("SELECT id, name FROM clubs WHERE owner='".getuid_sid($sid)."'");
if($noi[0]>0){$main.="<br/><b>My Clubs</b><br/>\n";}
if(mysql_num_rows($uclubs)>0){
while($club=mysql_fetch_array($uclubs)){
$main.="<a href=\"./view.php?id=$club[0]&amp;sid=$sid\">$club[1] Club</a><br/>\n";
}
}
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) 
FROM clubmembers a INNER JOIN clubs b ON a.clubid=b.id 
WHERE a.uid='".getuid_sid($sid)."' AND a.accepted='1' 
AND b.owner!='".getuid_sid($sid)."'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT a.clubid, b.name FROM clubmembers a INNER JOIN 
clubs b ON a.clubid=b.id WHERE a.uid='".getuid_sid($sid)."' 
AND a.accepted='1' AND b.owner!='".getuid_sid($sid)."' 
ORDER BY a.joined DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
echo mysql_error();
if($num_items[0]>0){$main.="<br/><b>Joined Clubs</b><br/>\n";}
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
$main.="<a href=\"./view.php?id=$item[0]&amp;sid=$sid\">$item[1] Club</a><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./clubs.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./clubs.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("clubs","","",$sid);}
$main.="<p align=".align().">\n";
}
if(points(getuid_sid($sid))>=200&&$noi[0]<3){
$main.="You can now create a club <a href=\"./create.php?sid=$sid\">Click here</a><br/>\n<br/>\n";
}else if(points(getuid_sid($sid))<200){
$points="points";
if(points(getuid_sid($sid))==1){$points="point";}
$main.="You need ".(200-points(getuid_sid($sid)))." more $points to create a club!<br/>\n<br/>\n";
}
$main.="<a href=\"./clublist.php?sid=$sid\">View All Clubs</a><br/>\n";
$ncl=mysql_fetch_array(mysql_query("SELECT id, name FROM clubs ORDER BY created DESC LIMIT 1"));
$main.="The Newest Club Is: <a href=\"./view.php?id=$ncl[0]&amp;sid=$sid\">$ncl[1]</a>\n";
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>