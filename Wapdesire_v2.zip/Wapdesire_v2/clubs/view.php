<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW CLUB/////////////////////////

$clinfo=mysql_fetch_array(mysql_query("SELECT name, owner, description, rules, logo, points, created FROM clubs WHERE id='".$id."'"));
addonline(getuid_sid($sid),"Viewing $clinfo[0] Club","");
echo head_tag(getnick_sid($sid)."@View Club",1,getnick_sid($sid));
$title="<b>View Club</b>";
$main="<p align=".align().">\n";
$clb=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubs WHERE id='".$id."'"));
if($clb[0]>0){
if(club_tools(getuid_sid($sid))){
$main.="<a href=\"./tools.php?id=$id&amp;sid=$sid\">*Club Tools*</a><br/>";
}
$main.="<b>$clinfo[0]</b><br/>\n";
if(trim($clinfo[4])==""){$main.="<img src=\"../images/logo.gif\" alt=\"logo\"/><br/>\n";}
else{$main.="<img src=\"$clinfo[4]\" alt=\"logo\"/><br/>\n";}
$main.="<b>Club Id:</b> $id<br/>\n";
$cango=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$id."' AND uid='".getuid_sid($sid)."' AND accepted='1'"));
$main.="<b>Owner:</b> <a href=\"../profile.php?who=$clinfo[1]&amp;sid=$sid\">".getnick_uid($clinfo[1])."</a><br/>\n";
$mems=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$id."' AND accepted='1'"));
$main.="<b>Members:</b> <a href=\"./members.php?id=$id&amp;sid=$sid\">$mems[0]</a><br/>\n";
$main.="<b>Created:</b> ".date("D jS M y", $clinfo[6])."<br/>\n";
$main.="<b>Club Points:</b> $clinfo[5]<br/>\n";
$fid=mysql_fetch_array(mysql_query("SELECT id FROM forums WHERE clubid='".$id."'"));
$rid=mysql_fetch_array(mysql_query("SELECT id FROM chatrooms WHERE clubid='".$id."'"));
$tps=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$fid[0]."'"));
$pss=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread = b.id WHERE b.fid='".$fid[0]."'"));
if(($cango[0]>0)||club_tools(getuid_sid($sid))){
$noa=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM announcements WHERE clubid='".$id."'"));
$main.="<a href=\"announcements.php?id=$id&amp;sid=$sid\">Announcements $noa[0]</a><br/>";
$noa=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chat WHERE rid='".$rid[0]."'"));
$main.="<a href=\"../chat/chat.php?rid=$rid[0]&amp;sid=$sid\">$clinfo[0] Chat $noa[0]</a><br/>\n";
$main.="<a href=\"../forums/viewforum.php?fid=$fid[0]&amp;sid=$sid\">$clinfo[0] Forum $tps[0]/$pss[0]</a>\n";
$ismem=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$id."' AND uid='".getuid_sid($sid)."'"));
if($ismem[0]>0){
if($clinfo[1]!=getuid_sid($sid)){
$main.="<br/><a href=\"genproc.php?action=unjc&amp;sid=$sid&amp;clid=$clid\">Unjoin Club</a><br/>\n";
}
}else{
$main.="<br/><a href=\"./join.php?id=$id&amp;sid=$sid\">Join Now!</a><br/>\n";
}
if($clinfo[1]==getuid_sid($sid)){
$mems=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$id."' AND accepted='0'"));
$main.="<br/>\n<a href=\"requests.php?id=$id&amp;sid=$sid\">Requests $mems[0]</a>\n";
}
}else{
$main.="Topics: <b>$tps[0]</b>, Posts: <b>$pss[0]</b><br/>
<b>Description:</b><br/>
$clinfo[2]<br/>
<br/>
<b>Rules:</b><br/>
$clinfo[3]<br/>
<br/>
Seems Good? <a href=\"./join.php?id=$id&amp;sid=$sid\">Join Now!</a>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Club does not exist!!!\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>