<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ACCEPT REQUEST/////////////////////////

addonline(getuid_sid($sid),"Accept/Deny Club Request","");
echo head_tag(getnick_sid($sid)."@Accept/Deny Request",1,getnick_sid($sid));
$title="<b>Accept/Deny Request</b>";
$main="<p align=".align().">\n";
$owner=mysql_fetch_array(mysql_query("SELECT owner FROM clubs WHERE id='".$id."'"));
if($owner[0]==getuid_sid($sid)){
if($add==1){$res=mysql_query("UPDATE clubmembers SET accepted='1' WHERE clubid='".$id."' AND uid='".$who."'");}
else if($add==0){$res=mysql_query("DELETE FROM clubmembers WHERE clubid='".$id."' AND uid='".$who."'");}
if($res){
if($add==0){
$mode="deleted from";
}else if($add==1){
$pts=mysql_fetch_array(mysql_query("SELECT points FROM clubs WHERE id='".$id."'"));
mysql_query("UPDATE clubs SET points='".($pts[0]+10)."' WHERE id='".$id."'");
$mode="added to";
}
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Member $mode your club\n";
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Database Error!\n";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>This club ain't yours\n";}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
?>