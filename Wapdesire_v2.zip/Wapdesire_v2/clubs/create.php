<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CREATE CLUB/////////////////////////

if($add==1)
{
addonline(getuid_sid($sid),"Creating Club","");
echo head_tag(getnick_sid($sid)."@Creating Club",1,getnick_sid($sid));
$title="<b>Creating Clubs</b>";
$main="<p align=".align().">\n";
if(points(getuid_sid($sid))>=200){
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubs WHERE owner='".getuid_sid($sid)."'"));
if($noi[0]<3){
if($name==""||$description==""||$rules==""){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Please be sure to fill, club name, description and rules\n";
}else{
$nmex=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubs WHERE name LIKE '".$name."'"));
if($nmex[0]>0){$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Club Name Already exist\n";}
else{
$res=mysql_query("INSERT INTO clubs SET 
name='".$name."', owner='".getuid_sid($sid)."', 
description='".$description."', rules='".$rules."', 
logo='".$clublogo."', points='0', created='".time()."'");
if($res){
$clid=mysql_fetch_array(mysql_query("SELECT id FROM clubs WHERE owner='".getuid_sid($sid)."' AND name='".$name."'"));
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Congratulations! 
you have your own club, your own rules, message board, chatroom, announcements board, 50 club points also for you\n";
mysql_query("INSERT INTO clubmembers SET uid='".getuid_sid($sid)."', clubid='".$clid[0]."', accepted='1', points='0', joined='".time()."'");
mysql_query("INSERT INTO forums SET name='".$name."', position='0', catid='0', clubid='".$clid[0]."'");
mysql_query("INSERT INTO chatrooms SET name='".$name."', password='', public='1', censored='0', freaky='0', lastmsg='".time()."', clubid='".$clid[0]."'");
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Database Error!\n";}
}
}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You already have 3 clubs\n";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You cant create clubs\n";}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$clid[0]."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$clid[0]&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Create Club","");
echo head_tag(getnick_sid($sid)."@Create Club",1,getnick_sid($sid));
$title="<b>Create Clubs</b>";
$main="<p align=".align().">\n";
if(points(getuid_sid($sid))>=200){
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubs WHERE owner='".getuid_sid($sid)."'"));
if($noi[0]<3){
$main.="<img src=\"../images/point.gif\" alt=\"[!]\"/>All Info are required except the logo<br/>
<img src=\"../images/point.gif\" alt=\"[!]\"/>Beside you, mods can moderate your club forums and chat<br/>
<img src=\"../images/point.gif\" alt=\"[!]\"/>Any leading spaces for description, name, logo, or rules will be removed<br/>
<img src=\"../images/point.gif\" alt=\"[!]\"/>Admins will delete your club and subtract your plusses if you abuse the rules of owning a club<br/>
<img src=\"../images/point.gif\" alt=\"[!]\"/>Admins have the right to delete your club if it wasnt active or if it was useless<br/></small><br/>
</p>
<div class=".align().">
<form action=\"./create.php?add=1&amp;sid=$sid\" method=\"post\">
<b>Club Name:</b><br/><input name=\"name\" maxlength=\"30\"/><br/>
<b>Description:</b><br/><input name=\"description\" maxlength=\"200\"/><br/>
<b>Rules:</b><br/><input name=\"rules\" maxlength=\"500\"/><br/>
<b>Logo:</b><br/><input name=\"clublogo\" maxlength=\"200\"/><br/>
<input type=\"submit\" value=\"Create\"/>
</form>
</div>\n";
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>You already have 3 clubs\n";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>You cant create any clubs :o/ \n";}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>