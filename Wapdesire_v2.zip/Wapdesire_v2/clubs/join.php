<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////JOIN CLUB/////////////////////////

addonline(getuid_sid($sid),"Joining Club","");
echo head_tag(getnick_sid($sid)."@Joining Club",1,getnick_sid($sid));
$title="<b>Joining Club</b>";
$main="<p align=".align().">\n";
$isin=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE uid='".getuid_sid($sid)."' AND clubid='".$id."'"));
$club=mysql_fetch_array(mysql_query("SELECT * FROM clubs WHERE id='".$id."'"));
if($isin[0]==0){
$res=mysql_query("INSERT INTO clubmembers SET uid='".getuid_sid($sid)."', clubid='".$id."', accepted='0', points='0', joined='".time()."'");
if($res){
if($club[owner]!=getuid_sid($sid)&&automsgs($club[owner])){
$msg="".getnick_sid($sid)." Has Requested to Join Your [club=$id]".$club[name]."[/club] Club[br/][small][i]p.s: this is an automated pm[/i][/small]";
autopm($msg,$club[owner]);
}
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Request sent! the club owner should accept your request\n";
}else{
echo "<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Database Error!\n";
}
}else{
echo "<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>You already in this club or request sent and waiting for acception\n";
}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>