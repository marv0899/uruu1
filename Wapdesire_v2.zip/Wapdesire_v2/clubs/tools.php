<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CLUB TOOLS/////////////////////////

addonline(getuid_sid($sid),"Club Tools","");
echo head_tag(getnick_sid($sid)."@Club Tools",1,getnick_sid($sid));
$title="<b>Club Tools</b>";
$main="<p align=".align().">\n";
if(club_tools(getuid_sid($sid))){
$main.="<a href=\"./points.php?id=$id&amp;sid=$sid\">Club Points</a><br/>
<a href=\"./delete.php?id=$id&amp;sid=$sid\">Delete Club</a><br/>";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$club=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$id."'"));
$L1="$fivekey<a $key5 href=\"./view.php?id=$id&amp;sid=$sid\">Back To $club[0] Club</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>