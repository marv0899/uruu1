-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 20, 2008 at 11:02 PM
-- Server version: 4.1.22
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `teaze_chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintools`
--

CREATE TABLE `admintools` (
  `uid` int(100) NOT NULL default '0',
  `tools` char(1) NOT NULL default '0',
  `boot` char(1) NOT NULL default '0',
  `ban` char(1) NOT NULL default '0',
  `unban` char(1) NOT NULL default '0',
  `ipban` char(1) NOT NULL default '0',
  `del` char(1) NOT NULL default '0',
  `validate` char(1) NOT NULL default '0',
  `delshout` char(1) NOT NULL default '0',
  `userinfo` char(1) NOT NULL default '0',
  `settings` char(1) NOT NULL default '0',
  `ghosts` char(1) NOT NULL default '0',
  `chat_tools` char(1) NOT NULL default '0',
  `forum_tools` char(1) NOT NULL default '0',
  `club_tools` char(1) NOT NULL default '0',
  `quiz_tools` char(1) NOT NULL default '0',
  `gallery_tools` char(1) NOT NULL default '0',
  `game_tools` char(1) NOT NULL default '0',
  `download_tools` char(1) NOT NULL default '0',
  `link_tools` char(1) NOT NULL default '0',
  `editusers` char(1) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintools`
--

INSERT INTO `admintools` VALUES(1, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(100) NOT NULL auto_increment,
  `text` varchar(200) NOT NULL default '',
  `clubid` int(100) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `announcements`
--

-- --------------------------------------------------------

--
-- Table structure for table `banned`
--

CREATE TABLE `banned` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(100) NOT NULL default '0',
  `penalty` char(1) NOT NULL default '0',
  `byid` int(100) NOT NULL default '0',
  `remaining` int(100) NOT NULL default '0',
  `reason` varchar(100) NOT NULL default '',
  `ipaddress` varchar(30) NOT NULL default '',
  `browser` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `banned`
--

-- --------------------------------------------------------

--
-- Table structure for table `blocked`
--

CREATE TABLE `blocked` (
  `id` int(11) NOT NULL auto_increment,
  `site` varchar(255) NOT NULL default 'NULL',
  `autoreport` char(1) NOT NULL default '0',
  `ipaddress` varchar(15) NOT NULL default 'NULL',
  `browser` varchar(255) NOT NULL default 'NULL',
  `network` varchar(255) NOT NULL default 'NULL',
  `reason` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `blocked`
--

INSERT INTO `blocked` VALUES(1, 'NULL', '0', 'NULL', 'Anonymouse.org', 'NULL', 'Forbidden Proxy');
INSERT INTO `blocked` VALUES(2, 'checkout', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(3, 'visit', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(4, 'http:', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(5, 'www.', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(6, '.com', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(7, '.net', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(8, '.org', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(9, '.info', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(10, '.biz', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(11, '.mobi', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(12, '.ro', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(13, '.co.uk', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(14, '.me.uk', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(15, '.uk.to', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(16, '.co.za', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(17, '.web.tr', '1', 'NULL', 'NULL', 'NULL', '');
INSERT INTO `blocked` VALUES(18, '.wen.ru', '1', 'NULL', 'NULL', 'NULL', '');


-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(100) NOT NULL auto_increment,
  `blogid` int(10) NOT NULL default '0',
  `uid` int(10) NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `date` int(30) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blog_comments`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(100) NOT NULL auto_increment,
  `date` int(20) NOT NULL default '0',
  `uid` int(10) NOT NULL default '0',
  `subject` varchar(50) NOT NULL default '',
  `body` varchar(255) NOT NULL default '',
  `reported` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blogs`
--

-- --------------------------------------------------------

--
-- Table structure for table `buds`
--

CREATE TABLE `buds` (
  `id` int(100) NOT NULL auto_increment,
  `uid` int(100) NOT NULL default '0',
  `tid` int(100) NOT NULL default '0',
  `agreed` char(1) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `buds`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(99) NOT NULL auto_increment,
  `uid` int(100) NOT NULL default '0',
  `toid` int(100) NOT NULL default '0',
  `timesent` int(50) NOT NULL default '0',
  `text` text NOT NULL,
  `rid` int(99) NOT NULL default '0',
  `exposed` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `chat`
--


-- --------------------------------------------------------

--
-- Table structure for table `chatonline`
--

CREATE TABLE `chatonline` (
  `lton` int(15) NOT NULL default '0',
  `uid` int(100) NOT NULL default '0',
  `rid` int(99) NOT NULL default '0',
  PRIMARY KEY  (`lton`),
  UNIQUE KEY `username` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chatonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `chatrooms`
--

CREATE TABLE `chatrooms` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `public` char(1) NOT NULL default '0',
  `censored` char(1) NOT NULL default '1',
  `freaky` char(1) NOT NULL default '0',
  `lastmsg` int(100) NOT NULL default '0',
  `clubid` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `chatrooms`
--

INSERT INTO `chatrooms` VALUES(1, 'Admin', '', '0', '1', '0', 1197112158, 1);
INSERT INTO `chatrooms` VALUES(2, 'General', '', '1', '1', '0', 1203493431, 0);
INSERT INTO `chatrooms` VALUES(3, 'Adults 18+', '', '1', '0', '0', 1203508898, 0);
INSERT INTO `chatrooms` VALUES(4, 'Gay n Lez', '', '1', '1', '0', 1202543992, 0);
INSERT INTO `chatrooms` VALUES(5, 'International', '', '1', '1', '0', 1203350696, 0);
INSERT INTO `chatrooms` VALUES(6, 'Garbage', '', '1', '1', '0', 1202939826, 0);
INSERT INTO `chatrooms` VALUES(7, 'Whats Hot', '', '1', '0', '0', 1203338295, 0);

-- --------------------------------------------------------

--
-- Table structure for table `clubmembers`
--

CREATE TABLE `clubmembers` (
  `id` int(100) NOT NULL auto_increment,
  `uid` int(100) NOT NULL default '0',
  `clubid` int(100) NOT NULL default '0',
  `accepted` char(1) NOT NULL default '0',
  `points` int(100) NOT NULL default '0',
  `joined` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `clubmembers`
--

INSERT INTO `clubmembers` VALUES(1, 1, 1, '1', 0, 1186818708);

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `id` int(100) NOT NULL auto_increment,
  `owner` int(100) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `description` varchar(200) NOT NULL default '',
  `rules` text NOT NULL,
  `logo` varchar(200) NOT NULL default '',
  `points` int(100) NOT NULL default '0',
  `created` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` VALUES(1, 1, 'Admin', 'Admin Club', 'For admins only!!!', '../images/admin.gif', 139, 1186818708);

-- --------------------------------------------------------

--
-- Table structure for table `download_categories`
--

CREATE TABLE `download_categories` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `active` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `download_categories`
--

INSERT INTO `download_categories` VALUES(1, 'Music', 'mp3 Tones, Real Tones, Mono Tones Etc...', '1');
INSERT INTO `download_categories` VALUES(2, 'Pics', 'Wallpapers, Pictures, Animations and Screen Savers.', '1');
INSERT INTO `download_categories` VALUES(3, 'Applications/Games', 'Java Apps, S30, S40, S60 Apps Etc...', '1');
INSERT INTO `download_categories` VALUES(4, 'Movies', '3gp, Mp4 And Other Video Files', '1');

-- --------------------------------------------------------

--
-- Table structure for table `download_files`
--

CREATE TABLE `download_files` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `path` varchar(255) NOT NULL default '0',
  `description` varchar(255) NOT NULL default '',
  `category` char(1) NOT NULL default '0',
  `hits` int(10) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  `active` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `download_files`
--

-- --------------------------------------------------------

--
-- Table structure for table `filter`
--

CREATE TABLE `filter` (
  `id` int(10) NOT NULL auto_increment,
  `word` varchar(25) NOT NULL default '',
  `replace` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `filter`
--

INSERT INTO `filter` VALUES(1, 'fuck', 'f**k');

-- --------------------------------------------------------

--
-- Table structure for table `forumcats`
--

CREATE TABLE `forumcats` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `position` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `forumcats`
--

INSERT INTO `forumcats` VALUES(1, 'General', 1);
INSERT INTO `forumcats` VALUES(2, 'Entertainment', 2);
INSERT INTO `forumcats` VALUES(3, 'Technology', 3);
INSERT INTO `forumcats` VALUES(4, 'Just 4 Fun', 4);
INSERT INTO `forumcats` VALUES(5, 'Others+Info', 5);

-- --------------------------------------------------------

--
-- Table structure for table `forumposts`
--

CREATE TABLE `forumposts` (
  `id` int(100) NOT NULL auto_increment,
  `text` text NOT NULL,
  `thread` int(100) NOT NULL default '0',
  `uid` int(100) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  `reported` char(1) NOT NULL default '0',
  `quote` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forumposts`
--

-- --------------------------------------------------------

--
-- Table structure for table `forums`
--

CREATE TABLE `forums` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `position` int(50) NOT NULL default '0',
  `catid` int(100) NOT NULL default '0',
  `clubid` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `forums`
--

INSERT INTO `forums` VALUES(1, 'Admin', 0, 0, 1);
INSERT INTO `forums` VALUES(2, 'General', 1, 1, 0);
INSERT INTO `forums` VALUES(3, 'Adults 18+', 2, 1, 0);
INSERT INTO `forums` VALUES(4, 'Newbies', 3, 1, 0);
INSERT INTO `forums` VALUES(5, 'Gay n Lez', 4, 1, 0);
INSERT INTO `forums` VALUES(6, 'international', 5, 1, 0);
INSERT INTO `forums` VALUES(7, 'Music', 1, 2, 0);
INSERT INTO `forums` VALUES(8, 'Movies', 2, 2, 0);
INSERT INTO `forums` VALUES(9, 'Whats Hot', 3, 2, 0);
INSERT INTO `forums` VALUES(10, 'Poems n Such', 4, 2, 0);
INSERT INTO `forums` VALUES(11, 'pc', 1, 3, 0);
INSERT INTO `forums` VALUES(12, 'Mobiles', 2, 3, 0);
INSERT INTO `forums` VALUES(13, 'Web n Wap', 3, 3, 0);
INSERT INTO `forums` VALUES(14, 'Joke Box', 1, 4, 0);
INSERT INTO `forums` VALUES(15, 'Suggestions', 1, 5, 0);
INSERT INTO `forums` VALUES(16, 'Download Requests', 2, 5, 0);
INSERT INTO `forums` VALUES(17, 'Problems', 3, 5, 0);
INSERT INTO `forums` VALUES(18, 'Garbage', 4, 5, 0);
INSERT INTO `forums` VALUES(19, 'Site Info', 5, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `forumtopics`
--

CREATE TABLE `forumtopics` (
  `id` int(100) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `fid` int(100) NOT NULL default '0',
  `uid` int(100) NOT NULL default '0',
  `text` text NOT NULL,
  `pinned` char(1) NOT NULL default '0',
  `closed` char(1) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  `views` int(100) NOT NULL default '0',
  `reported` char(1) NOT NULL default '0',
  `lastpost` int(100) NOT NULL default '0',
  `moved` char(1) NOT NULL default '0',
  `poll` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forumtopics`
--

-- --------------------------------------------------------

--
-- Table structure for table `gallery_categories`
--

CREATE TABLE `gallery_categories` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `active` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `gallery_categories`
--

INSERT INTO `gallery_categories` VALUES(1, 'Male', '1');
INSERT INTO `gallery_categories` VALUES(2, 'Female', '1');
INSERT INTO `gallery_categories` VALUES(3, 'Adult', '1');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_files`
--

CREATE TABLE `gallery_files` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL default '0',
  `filename` varchar(50) NOT NULL default '',
  `path` varchar(255) NOT NULL default '0',
  `category` char(1) NOT NULL default '0',
  `hits` int(10) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `gallery_files`
--

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `uid` int(100) NOT NULL default '0',
  `category` varchar(50) NOT NULL default '',
  `word1` varchar(50) NOT NULL default '',
  `word2` varchar(50) NOT NULL default '',
  `word3` varchar(50) NOT NULL default '',
  `word4` varchar(50) NOT NULL default '',
  `word5` varchar(50) NOT NULL default '',
  `word6` varchar(50) NOT NULL default '',
  `word7` varchar(50) NOT NULL default '',
  `word8` varchar(50) NOT NULL default '',
  `word9` varchar(50) NOT NULL default '',
  `word10` varchar(50) NOT NULL default '',
  `word11` varchar(50) NOT NULL default '',
  `word12` varchar(50) NOT NULL default '',
  `word13` varchar(50) NOT NULL default '',
  `word14` varchar(50) NOT NULL default '',
  `word15` varchar(50) NOT NULL default '',
  `word16` varchar(50) NOT NULL default '',
  `word17` varchar(50) NOT NULL default '',
  `word18` varchar(50) NOT NULL default '',
  `word19` varchar(50) NOT NULL default '',
  `word20` varchar(50) NOT NULL default '',
  `active` char(1) NOT NULL default '0',
  PRIMARY KEY  (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `games`
--

INSERT INTO `games` VALUES('0', 'wordscramble', 'dictionary', 'recognize', 'example', 'entertainment', 'experiment', 'appreciation', 'information', 'pronunciation', 'language', 'government', 'psychic', 'blueberry', 'selection', 'automatic', 'strawberry', 'bakery', 'shopping', 'eggplant', 'chicken', 'organic', '1');
INSERT INTO `games` VALUES('0', 'Colors', 'black', 'blue', 'brown', 'cyan', 'gold', 'green', 'grey', 'lavender', 'maroon', 'olive', 'orange', 'pink', 'purple', 'red', 'scarlet', 'teal', 'turquoise', 'violet', 'white', 'yellow', '1');
INSERT INTO `games` VALUES('0', 'Food', 'Sausages', 'Hamburger', 'Carrot', 'Cheese', 'Strawberry', 'Apple', 'Lettuce', 'Tomatoes', 'Chocolate', 'Cereal', 'Onions', 'Coconut', 'Gooseberry', 'Marmite', 'Spaghetti', 'Mango', 'Pasties', 'Cucumber', 'Tomatoes', 'Steak', '1');
INSERT INTO `games` VALUES('0', 'Pc', 'Central Processing Unit', 'Motherboard', 'Radeon', 'Sound blaster', 'nvidia', 'Hard disk drive', 'Bios', 'Cmos', 'Power supply', 'Sata', 'Raid', 'Serial', 'Universal serial bus', 'Infra red', 'Accelerated graphics port', 'North bridge', 'South bridge', 'Logitech', 'Microsoft', 'Windows', '1');
INSERT INTO `games` VALUES('0', 'Films', 'Free willy', 'Rocky', 'Star wars', 'Stargate', 'Home alone', 'Eragon', 'Garfield', 'Holiday', 'Green mile', 'Longest yard', 'Click', 'Wedding singer', 'XXX', 'Simpson the movie', 'I.T', 'Lord of the rings', 'Land before time', 'St. Trinians', 'Flushed away', 'Shrek', '1');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `minage` int(10) NOT NULL default '0',
  `maxage` int(10) NOT NULL default '0',
  `level` char(1) NOT NULL default '0',
  `points` int(100) NOT NULL default '0',
  `fid` int(10) NOT NULL default '0',
  `rid` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` VALUES(1, 'admin', 0, 0, '1', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `guestbook`
--

CREATE TABLE `guestbook` (
  `id` int(100) NOT NULL auto_increment,
  `uid` int(100) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `message` varchar(255) NOT NULL default '',
  `date` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `guestbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `ignored`
--

CREATE TABLE `ignored` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(99) NOT NULL default '0',
  `tid` int(99) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ignored`
--

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `id` int(100) NOT NULL auto_increment,
  `text` text NOT NULL,
  `byid` int(100) NOT NULL default '0',
  `toid` int(100) NOT NULL default '0',
  `fwd` int(100) NOT NULL default '0',
  `unread` char(1) NOT NULL default '1',
  `timesent` int(100) NOT NULL default '0',
  `archive` char(1) NOT NULL default '0',
  `reported` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `inbox`
--

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `url` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `links`
--

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` int(100) NOT NULL auto_increment,
  `uid` int(10) NOT NULL default '0',
  `username` varchar(50) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `ip` varchar(50) NOT NULL default '',
  `host` varchar(200) NOT NULL default '',
  `browser` varchar(200) NOT NULL default '',
  `date` varchar(50) NOT NULL default '',
  `action` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logins`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(100) NOT NULL auto_increment,
  `action` varchar(20) NOT NULL default '',
  `details` text NOT NULL,
  `date` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logs`
--

-- --------------------------------------------------------

--
-- Table structure for table `modtools`
--

CREATE TABLE `modtools` (
  `id` int(100) NOT NULL auto_increment,
  `uid` int(100) NOT NULL default '0',
  `fid` int(100) NOT NULL default '0',
  `rid` int(100) NOT NULL default '0',
  `clubid` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `modtools`
--

-- --------------------------------------------------------

--
-- Table structure for table `mpot`
--

CREATE TABLE `mpot` (
  `id` int(10) NOT NULL auto_increment,
  `ddt` varchar(50) NOT NULL default '',
  `dtm` varchar(20) NOT NULL default '',
  `ppl` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mpot`
--

-- --------------------------------------------------------

--
-- Table structure for table `network`
--

CREATE TABLE `network` (
  `id` int(255) NOT NULL auto_increment,
  `subone` text NOT NULL,
  `subtwo` text NOT NULL,
  `isp` text NOT NULL,
  `country` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `network`
--

-- --------------------------------------------------------

--
-- Table structure for table `nicks`
--

CREATE TABLE `nicks` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `nicklvl` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nicks`
--

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE `online` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(12) NOT NULL default '0',
  `time` int(100) NOT NULL default '0',
  `place` varchar(50) NOT NULL default '',
  `link` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `online`
--

-- --------------------------------------------------------

--
-- Table structure for table `pollresults`
--

CREATE TABLE `pollresults` (
  `id` int(100) NOT NULL auto_increment,
  `pollid` int(100) NOT NULL default '0',
  `uid` int(100) NOT NULL default '0',
  `answer` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pollresults`
--

-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

CREATE TABLE `polls` (
  `id` int(100) NOT NULL auto_increment,
  `question` varchar(255) NOT NULL default '',
  `option1` varchar(100) NOT NULL default '',
  `option2` varchar(100) NOT NULL default '',
  `option3` varchar(100) NOT NULL default '',
  `option4` varchar(100) NOT NULL default '',
  `option5` varchar(100) NOT NULL default '',
  `date` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `polls`
--

-- --------------------------------------------------------

--
-- Table structure for table `popups`
--

CREATE TABLE `popups` (
  `id` int(100) NOT NULL auto_increment,
  `text` text NOT NULL,
  `byid` int(100) NOT NULL default '0',
  `toid` int(100) NOT NULL default '0',
  `unread` char(1) NOT NULL default '1',
  `timesent` int(100) NOT NULL default '0',
  `reported` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `popups`
--

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `uid` varchar(100) NOT NULL default '',
  `time` int(100) NOT NULL default '0',
  `birthday` varchar(10) NOT NULL default '',
  `sex` char(1) NOT NULL default '',
  `location` varchar(100) NOT NULL default '',
  `moreinfo` varchar(100) NOT NULL default '',
  `picture` varchar(100) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `status` varchar(50) NOT NULL default '',
  `mood` varchar(20) NOT NULL default '',
  `site_mood` char(1) NOT NULL default '0',
  `image` varchar(100) NOT NULL default '',
  `points` varchar(50) NOT NULL default '0',
  `forumposts` int(10) NOT NULL default '0',
  `chatmsgs` int(10) NOT NULL default '0',
  `shouts` int(10) NOT NULL default '0',
  `body_background` varchar(7) NOT NULL default '#FFFFFF',
  `body_text` varchar(7) NOT NULL default '#000000',
  `font_size` varchar(7) NOT NULL default 'medium',
  `border_color` varchar(7) NOT NULL default '#0000FF',
  `div_background` varchar(7) NOT NULL default '#000000',
  `link_color` varchar(7) NOT NULL default '#0000FF',
  `script` varchar(5) NOT NULL default '',
  `quiz_score` varchar(100) NOT NULL default '0/0/0',
  `quiz_easy` char(3) NOT NULL default 'no',
  `quiz_medium` char(3) NOT NULL default 'no',
  `quiz_hard` char(3) NOT NULL default 'no',
  `total_score` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profiles`
--

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int(11) NOT NULL auto_increment,
  `question` varchar(200) NOT NULL default '',
  `answer` varchar(30) NOT NULL default '',
  `difficulty` varchar(12) NOT NULL default '',
  `number` int(11) NOT NULL default '0',
  `answer1` varchar(50) NOT NULL default '',
  `answer2` varchar(50) NOT NULL default '',
  `answer3` varchar(50) NOT NULL default '',
  `answer4` varchar(50) NOT NULL default '',
  `switch` char(3) NOT NULL default 'on',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` VALUES(1, 'what is 500 in roman numerals', 'd', 'easy', 1, 'a', 'g', 'v', 'd', 'on');
INSERT INTO `quiz` VALUES(2, 'how many strings dose a violin have', '4', 'easy', 2, '7', '5', '4', '6', 'on');
INSERT INTO `quiz` VALUES(3, 'what is the 5th planet in solar system called', 'jupiter', 'easy', 3, 'mars', 'moon', 'sun', 'jupiter', 'on');
INSERT INTO `quiz` VALUES(4, 'what was the name of captain cooks famous ship', 'hms endeavour', 'easy', 4, 'msh boat', 'hms ship', 'hms endeavour', 'hsm jet boat', 'on');
INSERT INTO `quiz` VALUES(5, 'in secabble how many letters have a value of 2', 'd n g', 'easy', 5, 'a n t', 's n r', 'd n g', 'p n q', 'on');
INSERT INTO `quiz` VALUES(6, 'what is chiminage?', 'a toll', 'easy', 6, 'a tree', 'a river', 'a bat', 'a toll', 'on');
INSERT INTO `quiz` VALUES(7, 'what animal is affed bye the disease braxy', 'sheep', 'easy', 7, 'bird', 'dog', 'goat', 'sheep', 'on');
INSERT INTO `quiz` VALUES(8, 'what item of clothing is also know as a filibeg?', 'kilt', 'easy', 8, 'top', 'dress', 'kilt', 'pants', 'on');
INSERT INTO `quiz` VALUES(9, 'what do you do with a zloty in poland', 'spend it', 'easy', 9, 'keep it', 'fine it', 'save it', 'spend it', 'on');
INSERT INTO `quiz` VALUES(10, 'what dose the phrase mae clupa mean ?', 'my fault', 'easy', 10, 'iam guilty', 'not me', 'my fault', 'not my doing', 'on');
INSERT INTO `quiz` VALUES(11, 'what sort creature is a scup?', 'a fish', 'med', 1, 'a dog', 'a cat', 'a fish', 'a bird', 'on');
INSERT INTO `quiz` VALUES(12, 'what O is the name given to a pice of music opening a concert?', 'overture', 'med', 2, 'overkill', 'overbeat', 'overtune', 'overture', 'on');
INSERT INTO `quiz` VALUES(13, 'what is the name of a small group of whales or seals?', 'a pod', 'med', 3, 'a school of fish', 'a group of whales', 'a pod', 'a group of seals', 'on');
INSERT INTO `quiz` VALUES(14, 'what in ireland is a loy?', 'a spade', 'med', 4, 'a pick', 'a spoon', 'a spade', 'a meal', 'on');
INSERT INTO `quiz` VALUES(15, 'who ranted about the way iam in a dark hit in 2000?', 'eminem', 'med', 5, 'fitty cents', 'nelly', 'eminem', 'snoop doggie', 'on');
INSERT INTO `quiz` VALUES(16, 'who had hits with alcoholic', 'starsailor', 'med', 6, 'fiffty cents', 'justin timberlake', 'nelly furtardo', 'starsailor', 'on');
INSERT INTO `quiz` VALUES(17, 'can you name the pudlicity shy lead singer of the arctic monkeys?', 'alex turner', 'med', 7, 'justin timberlake', 'amy winehouse', 'damien rice', 'alex turner', 'on');
INSERT INTO `quiz` VALUES(18, 'who released fit but you know it from the album a grand dont come for free?', 'the streets', 'med', 8, 'pearl jam', 'ozzy', 'the streets', 'starsailor', 'on');
INSERT INTO `quiz` VALUES(19, 'what is the name of the largest artery in the human body?', 'aorta', 'med', 9, 'vaines', 'red blood cells', 'aorta', 'white blood cells', 'on');
INSERT INTO `quiz` VALUES(20, 'in which year did the explosion at chernbyl nuclear reactor occur?', '1986', 'med', 10, '1976', '1966', '1956', '1986', 'on');
INSERT INTO `quiz` VALUES(21, 'what was the name of the russian submarine which was flooded and stranded on the sea bed in august?', 'the kursk', 'hard', 1, 'the russian', 'the France', 'the England', 'the kursk', 'on');
INSERT INTO `quiz` VALUES(22, 'who or what was piper alpha?', 'a north sea oil rig', 'hard', 2, 'a sailing ship', 'a oil ship', 'a jetski', 'a north sea oil rig', 'on');
INSERT INTO `quiz` VALUES(23, 'in which year were 8 members of the manchester united football team killed in a air disaster?', '1958', 'hard', 3, '1955', '1960', '1958', '1976', 'on');
INSERT INTO `quiz` VALUES(24, 'in which year was the great fire of london?', '1666', 'hard', 4, '1709', '1810', '1666', '1909', 'on');
INSERT INTO `quiz` VALUES(25, 'what particular gimmick was used in the 1958 film house of wax?', 'it was made in 3d', 'hard', 5, 'it was the wax', 'it was the house', 'it was made in 3d', 'it was never made', 'on');
INSERT INTO `quiz` VALUES(26, 'what name was given to the light winds which blow across the equatot?', 'doldrums', 'hard', 6, 'lightrums', 'doldrums', 'brightrums', 'dolrums', 'on');
INSERT INTO `quiz` VALUES(27, 'what is the alternatvie name of the tree konwen as the mountain ash?', 'rowan', 'hard', 7, 'ashly', 'ashflod', 'rowan', 'ash', 'on');
INSERT INTO `quiz` VALUES(28, 'what is the name of the secince of the study of time', 'chonology', 'hard', 8, 'timespace', 'chonology', 'worldtime', 'time', 'on');
INSERT INTO `quiz` VALUES(29, 'in which year was the lockerbie disaster which destroyed pan am flight 103?', '1988', 'hard', 9, '1974', '1964', '1988', '1990', 'on');
INSERT INTO `quiz` VALUES(30, 'what type of disaster struck the central america in 1998?', 'hurricane mitch', 'hard', 10, 'hurricane paul', 'hurricane nina', 'hurricane mitch', 'hurricane sue', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `quizusers`
--

CREATE TABLE `quizusers` (
  `uid` int(100) NOT NULL default '0',
  `easy_question` char(2) NOT NULL default '0',
  `easy_next` char(2) NOT NULL default '0',
  `med_question` char(2) NOT NULL default '0',
  `med_next` char(2) NOT NULL default '0',
  `hard_question` char(2) NOT NULL default '0',
  `hard_next` char(2) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quizusers`
--

-- --------------------------------------------------------

--
-- Table structure for table `ses`
--

CREATE TABLE `ses` (
  `id` varchar(100) NOT NULL default '',
  `uid` varchar(30) NOT NULL default '',
  `expiretm` int(100) NOT NULL default '0',
  UNIQUE KEY `id` (`id`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ses`
--

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` VALUES(1, 'sesexp', '20');
INSERT INTO `settings` VALUES(2, '', '0');
INSERT INTO `settings` VALUES(3, 'greeting', '');
INSERT INTO `settings` VALUES(4, 'Counter', '0');
INSERT INTO `settings` VALUES(5, 'antiflood', '5');
INSERT INTO `settings` VALUES(6, 'registration', '1');
INSERT INTO `settings` VALUES(7, 'forumview', '0');
INSERT INTO `settings` VALUES(8, 'lastbpm', '2008-02-20');
INSERT INTO `settings` VALUES(9, 'sitename', 'sitename');
INSERT INTO `settings` VALUES(10, 'site_email', 'emailaddress');
INSERT INTO `settings` VALUES(11, 'gallery_email', 'emailaddress');
INSERT INTO `settings` VALUES(12, 'timezone', 'timezone');
INSERT INTO `settings` VALUES(13, 'validation', '0');
INSERT INTO `settings` VALUES(14, 'align', 'left');

-- --------------------------------------------------------

--
-- Table structure for table `shouts`
--

CREATE TABLE `shouts` (
  `id` int(100) NOT NULL auto_increment,
  `shout` varchar(100) NOT NULL default '',
  `uid` int(100) NOT NULL default '0',
  `shtime` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shouts`
--

-- --------------------------------------------------------

--
-- Table structure for table `smilies`
--

CREATE TABLE `smilies` (
  `id` int(100) NOT NULL auto_increment,
  `code` varchar(15) NOT NULL default '',
  `path` varchar(200) NOT NULL default '',
  `hidden` char(1) NOT NULL default '0',
  `mood` char(1) NOT NULL default '0',
  `date` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scode` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `smilies`
--

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `color` varchar(20) NOT NULL default '',
  `hex` varchar(7) NOT NULL default '',
  `text` varchar(7) NOT NULL default '#000000',
  PRIMARY KEY  (`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` VALUES('blue', '#0000FF', '#000000');
INSERT INTO `themes` VALUES('black', '#000000', '#FFFFFF');
INSERT INTO `themes` VALUES('brown', '#663300', '#000000');
INSERT INTO `themes` VALUES('gray', '#A9A9A9', '#000000');
INSERT INTO `themes` VALUES('orange', '#FF8C00', '#000000');
INSERT INTO `themes` VALUES('dark red', '#8B0000', '#000000');
INSERT INTO `themes` VALUES('violet', '#9400D3', '#000000');
INSERT INTO `themes` VALUES('pink', '#FF1493', '#000000');
INSERT INTO `themes` VALUES('light blue', '#00BFFF', '#000000');
INSERT INTO `themes` VALUES('light gray', '#DCDCDC', '#000000');
INSERT INTO `themes` VALUES('green', '#008000', '#000000');
INSERT INTO `themes` VALUES('light pink', '#FF69B4', '#000000');
INSERT INTO `themes` VALUES('purple', '#4B0082', '#000000');
INSERT INTO `themes` VALUES('light green', '#7CFC00', '#000000');
INSERT INTO `themes` VALUES('light purple', '#9370D8', '#000000');
INSERT INTO `themes` VALUES('aqua', '#00FA9A', '#000000');
INSERT INTO `themes` VALUES('dark blue', '#000066', '#000000');
INSERT INTO `themes` VALUES('red', '#FF0000', '#000000');
INSERT INTO `themes` VALUES('yellow', '#FFFF00', '#000000');
INSERT INTO `themes` VALUES('white', '#FFFFFF', '#000000');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL auto_increment,
  `regdate` int(100) NOT NULL default '0',
  `username` varchar(12) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `level` char(1) NOT NULL default '0',
  `shield` char(1) NOT NULL default '0',
  `lastact` int(100) NOT NULL default '0',
  `pollid` int(100) NOT NULL default '0',
  `browser` varchar(100) NOT NULL default '',
  `ipaddress` varchar(30) NOT NULL default '',
  `host` varchar(100) NOT NULL default '',
  `validated` char(1) NOT NULL default '0',
  `images` char(1) NOT NULL default '1',
  `automsgs` char(1) NOT NULL default '1',
  `popups` char(1) NOT NULL default '1',
  `hidden` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `wapsite`
--

CREATE TABLE `wapsite` (
  `uid` int(100) NOT NULL default '0',
  `blog_comments` char(1) NOT NULL default '1',
  `guestbook` char(1) NOT NULL default '0',
  `reported` char(1) NOT NULL default '0',
  `mainpage` text NOT NULL,
  `name` varchar(50) NOT NULL default '',
  `surname` varchar(50) NOT NULL default '',
  `nickname` varchar(50) NOT NULL default '',
  `maritalstatus` char(1) NOT NULL default '0',
  `city` varchar(50) NOT NULL default '',
  `height` varchar(50) NOT NULL default '',
  `weight` varchar(50) NOT NULL default '',
  `bodytype` char(1) NOT NULL default '0',
  `origin` char(2) NOT NULL default '0',
  `hair` varchar(50) NOT NULL default '',
  `eyes` char(1) NOT NULL default '0',
  `happy` varchar(255) NOT NULL default '',
  `sad` varchar(255) NOT NULL default '',
  `interests` varchar(255) NOT NULL default '',
  `profession` varchar(50) NOT NULL default '',
  `badhabits` varchar(255) NOT NULL default '',
  `goodhabits` varchar(255) NOT NULL default '',
  `team` varchar(50) NOT NULL default '',
  `band` varchar(50) NOT NULL default '',
  `music` varchar(50) NOT NULL default '',
  `tvshow` varchar(50) NOT NULL default '',
  `food` varchar(50) NOT NULL default '',
  `author` varchar(50) NOT NULL default '',
  `movie` varchar(50) NOT NULL default '',
  `animal` varchar(50) NOT NULL default '',
  `place` varchar(255) NOT NULL default '',
  `thing` varchar(255) NOT NULL default '',
  `aboutme` text NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wapsite`
--
