<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////DELETE INBOXES/////////////////////////

addonline(getuid_sid($sid),"Deleting Inboxes","inbox.php?mode=$mode$chatlink$pass");
echo head_tag(getnick_sid($sid)."@Delete Inboxes",1,getnick_sid($sid));
$title="<b>Delete Inboxes</b>";
$main="<p align=".align().">";
$inbox=mysql_fetch_array(mysql_query("SELECT byid, toid, reported, archive, fwd FROM inbox WHERE id='".$id."'"));
if((getuid_sid($sid)==$inbox[1])||(getuid_sid($sid)==$inbox[4])){
if($inbox[2]=="1"){$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>This Inbox Is Reported";}
else if($inbox[3]=="1"){$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>This Inbox Is Archived";}
else if($id!="all"){
$del=mysql_query("DELETE FROM inbox WHERE id='".$id."' AND ((toid='".getuid_sid($sid)."') OR (fwd='".getuid_sid($sid)."'))");
if($del){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Inbox Deleted Successfully";}
else{$main.="<img src=\"../images/notok.gif\" alt=\"x\"/><br/>Can't Delete Inbox At The Moment";}
}
}else if($id=="all"){
$del=mysql_query("DELETE FROM inbox WHERE ((toid='".getuid_sid($sid)."') OR (fwd='".getuid_sid($sid)."')) AND archive='0' AND reported='0' AND unread='0'");
if($del){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>All Inboxes Deleted Successfully";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Can't Delete Inboxes At The Moment";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>What The Hell You Trying To Do ???";}
if($rid!=""){$main.="<br/><a href=\"../chat/chat.php?sid=$sid$chatlink\">Back to $rname</a>";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>