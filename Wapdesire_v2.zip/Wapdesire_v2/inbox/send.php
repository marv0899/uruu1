<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SEND INBOX/////////////////////////

if($send==1)
{
addonline(getuid_sid($sid),"Sending Inbox","");
echo head_tag(getnick_sid($sid)."@Send Inbox",1,getnick_sid($sid));
$title="<b>Send Inbox</b>";
$main="<p align=".align().">";
$lastinbox=mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM inbox WHERE byid='".getuid_sid($sid)."'"));
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$who."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
if(($lastinbox[0]+antiflood())>time()){
$rema=$pmfl-$tm;
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
Flood control: ".(($lastinbox[0]+antiflood())-time())." Seconds
</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}if((ignored(getuid_sid($sid),$who,0)==2)||(ignored(getuid_sid($sid),getuid_nick($fwd),0)==2)){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
Failed Sending inbox To ".getnick_uid($who)." they hav u on ignore...
</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}else if(blocked_site($message,getuid_sid($sid))){
$bantime=time()+(30*24*60*60);
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
<b>Can't Send Inbox to ".getnick_uid($who)."</b><br/>
You just sent a link to one of the crapiest sites on earth<br/>
<br/>
as a result of your stupid action:<br/>
1. you are banned<br/>
2. you have lost all your points<br/>
3. if u are caught registering another username u will b permanently deleted!
</p>";
mysql_query("INSERT INTO logs SET action='autoban', details='<b>".getnick_uid(1)."</b> auto banned ".getnick_sid($sid)." for spamming inbox', date='".time()."'"); 
mysql_query("INSERT INTO banned SET uid='".getuid_sid($sid)."', penalty='3', byid='1', remaining='".$bantime."', reason='Banned: Automatic Ban for spamming for a crap site'");
mysql_query("UPDATE users SET points='0', shield='0' WHERE id='".getuid_sid($sid)."'");
mysql_query("INSERT INTO inbox SET text='[b](forwarded spam via inbox)[/b][br/]".$message."', byid='".getuid_sid($sid)."', toid='1', reported='1', timesent='".time()."'");
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit();
}else if(($id!=0)&&(isuser(getuid_nick($fwd)))){
$inbox=mysql_fetch_array(mysql_query("SELECT text, byid, toid, timesent FROM inbox WHERE id='".$id."'"));
mysql_query("INSERT INTO inbox SET text='".$inbox[0]."', byid='".$inbox[1]."', toid='".$inbox[2]."', fwd='".getuid_nick($fwd)."', timesent='".$inbox[3]."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Inbox Forwarded To $fwd Successfully
</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}
if($message!=""){
if(isspam($message))$spam=" reported='1',";
else $spam="";
$res=mysql_query("INSERT INTO inbox SET text='".$message."', byid='".getuid_sid($sid)."', toid='".$who."',$spam timesent='".time()."'");
}if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Inbox sent to <span style=\"color:$color;\">".getnick_uid($who)."</span>
</p>";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Can't Send Inbox to ".getnick_uid($who)."
</p>";
}
$link=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$opt="?";
if(strpos($link[0],"?")==true){$opt="&amp;";}
if(!is_file($link[0])){$link[0]="../$link[0]";}
$main.="<p align=".align()."><a href=\"$link[0]".$opt."sid=$sid$chatlink\">Ok!</a></p>";
if($rid!=""){$main.="<p align=".align().">
<a href=\"../chat/chat.php?sid=$sid$chatlink\">Back To $rname</a>
</p>";}
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Sending Inbox","");
echo head_tag(getnick_sid($sid)."@Send Inbox",1,getnick_sid($sid));
$title="<b>Send Inbox</b>";
$main="<p align=".align().">";
if(!isuser($who))$who=getuid_nick($who);
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$who."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
if(!isuser($who)){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>User Does Not exist</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}
$main.="</p>";
$main="<div class=".align().">
<form action=\"send.php?send=1&amp;sid=$sid$chatlink\" method=\"post\">
<b>To:</b> <span style=\"color:$color;\">".getnick_uid($who)."</span><br/>
<b>Message:</b><br/><input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"hidden\" name=\"who\" value=\"$who\"/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>