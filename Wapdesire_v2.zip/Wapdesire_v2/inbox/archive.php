<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ARCHIVE/////////////////////////

if($id!="")
{
addonline(getuid_sid($sid),"Inbox Archive","");
echo head_tag(getnick_sid($sid)."@Inbox Archive",1,getnick_sid($sid));
$title="<b>Inbox Archive</b>";
$main="<p align=".align().">";
$inbox=mysql_fetch_array(mysql_query("SELECT toid, archive, fwd FROM inbox WHERE id='".$id."'"));
if((getuid_sid($sid)==$inbox[0])||($inbox[2]==getuid_sid($sid))){
if($inbox[1]=="1"){
if(mysql_query("UPDATE inbox SET archive='0' WHERE id='".$id."'")){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Inbox Unarchived Successfully";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Can't Unarchive Inbox At The Moment";
}
}
else if($inbox[1]=="0"){
if(mysql_query("UPDATE inbox SET archive='1' WHERE id='".$id."'")){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Inbox Archived Successfully";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Can't Archive Inbox At The Moment";
}
}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>This Inbox Ain't Yours";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Inbox Archive","archive.php");
echo head_tag(getnick_sid($sid)."@Inbox Archive",1,getnick_sid($sid));
$title="<b>Inbox Archive</b>";
$main="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE ((toid='".getuid_sid($sid)."') OR (fwd!='0')) AND archive='1'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items[0]>0){
$sql="SELECT id, byid, unread, archive, fwd, toid FROM inbox 
WHERE ((toid='".getuid_sid($sid)."') OR (fwd!='0')) AND archive='1'
ORDER BY !unread,id DESC LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
$main.=mysql_error();
while($item=mysql_fetch_array($items)){
$iml="<img src=\"../images/spm.gif\" alt=\"*\"/>";
if($item[4]==getuid_sid($sid)){
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[5]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$main.="<a href=\"./read.php?id=$item[0]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml ".getnick_uid($item[5])."</a><br/>";
}else{
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[1]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$main.="<a href=\"./read.php?id=$item[0]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml ".getnick_uid($item[1])."</a><br/>";
}
}
if($page>1){
$main.="<br/><a href=\"archive.php?page=".($page-1)."&amp;sid=$sid$chatlink\">&lt;- Prev</a> ";
}if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"archive.php?page=".($page+1)."&amp;sid=$sid$chatlink\">Next -&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>";
if($num_pages>2){$main.=getjumper("archive","","",$sid);}
}else{
$main.="You have no Archived Messages</p>";
}
if($location=="chat"){$main.="<p align=".align().">$fourkey<a $key4 href=\"../chat/chat.php?sid=$sid$chatlink\">Back To $rname</a></p>";}
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users a INNER JOIN inbox b ON a.id = b.toid WHERE b.byid='".getuid_sid($sid)."'"));
$L1="$fivekey<a $key5 href=\"./outbox.php?sid=$sid$chatlink\">Outbox($count[0])</a>";
$L2="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>