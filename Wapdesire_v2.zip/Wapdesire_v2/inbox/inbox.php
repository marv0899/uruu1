<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

addonline(getuid_sid($sid),"Inbox","inbox.php$chatlink2$pass");
echo head_tag(getnick_sid($sid)."@Inbox",1,getnick_sid($sid));
$title="<b>Inbox</b>";
$main="<div class=".align().">
<form action=\"./send.php?sid=$sid$chatlink\" method=\"post\">
<b>To:</b><input name=\"who\" format=\"*x\" size=\"12\" maxlength=\"12\"/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>";
$main.="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE ((toid='".getuid_sid($sid)."' AND fwd='0') OR (fwd='".getuid_sid($sid)."')) AND archive='0'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items[0]>0){
$sql="SELECT id, byid, fwd, unread, archive, toid FROM inbox 
WHERE ((toid='".getuid_sid($sid)."' AND fwd='0') 
OR (fwd='".getuid_sid($sid)."')) AND archive='0'
ORDER BY !unread,id DESC LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
$main.=mysql_error();
while($item=mysql_fetch_array($items)){
if(($item[2]==getuid_sid($sid))&&($item[3]=="1")){$iml="<img src=\"../images/fpm.gif\" alt=\"+\"/>";}
else if(($item[2]==getuid_sid($sid))&&($item[3]=="0")){$iml="<img src=\"../images/ofpm.gif\" alt=\"-\"/>";}
else if($item[3]=="1"){$iml="<img src=\"../images/npm.gif\" alt=\"+\"/>";}
else if($item[4]=="1"){$iml="<img src=\"../images/spm.gif\" alt=\"*\"/>";}
else if($item[3]=="0"){$iml="<img src=\"../images/opm.gif\" alt=\"-\"/>";}
if($item[2]==getuid_sid($sid)){
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[5]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$main.="<a href=\"./read.php?id=$item[0]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml ".getnick_uid($item[5])."</a><br/>";
}else{
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[1]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$main.="<a href=\"./read.php?id=$item[0]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml ".getnick_uid($item[1])."</a><br/>";
}
}
if($page>1){
$main.="<br/><a href=\"inbox.php?page=".($page-1)."&amp;sid=$sid$chatlink\">&lt;- Prev</a> ";
}if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"inbox.php?page=".($page+1)."&amp;sid=$sid$chatlink\">Next -&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>";
if($num_pages>2){$main.=getjumper("inbox","","",$sid);}
}else{
$main.="You have no Inbox Messages</p>";
}
if($rid!=""){$main.="<p align=".align().">$twokey<a $key2 href=\"../chat/chat.php?sid=$sid$chatlink\">Back To $rname</a></p>";}
$L1="$threekey<a $key3 href=\"./inbox.php?time=".date('dmHis')."&amp;sid=$sid$chatlink\">Refresh</a>";
$L2="$fourkey<a $key4 href=\"./delete.php?id=all&amp;sid=$sid$chatlink\">Delete All</a>";
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users a INNER JOIN inbox b ON a.id = b.byid WHERE b.byid='".getuid_sid($sid)."'"));
$L3="$fivekey<a $key5 href=\"./outbox.php?sid=$sid$chatlink\">Outbox($count[0])</a>";
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users a INNER JOIN inbox b ON a.id = b.byid WHERE ((b.toid='".getuid_sid($sid)."') OR (b.fwd='".getuid_sid($sid)."')) AND b.archive='1'"));
$L4="$sixkey<a $key6 href=\"./archive.php?sid=$sid$chatlink\">Archive($count[0])</a>";
$L5="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L6="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L7="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L8="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,$L7,$L8,$main);
echo foot_tag();
?>