<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////READ INBOX/////////////////////////

addonline(getuid_sid($sid),"Sending Inbox","");
echo head_tag(getnick_sid($sid)."@Send Inbox",1,getnick_sid($sid));
$title="<b>Read Inbox</b>";
$main.="<p align=".align().">";
$readinbox=mysql_fetch_array(mysql_query("SELECT text, byid, timesent, toid, reported, fwd FROM inbox WHERE id='".$id."'"));
if((getuid_sid($sid)==$readinbox[3])&&($readinbox[5]==0)||(getuid_sid($sid)==$readinbox[5])){$chread = mysql_query("UPDATE inbox SET unread='0' WHERE id='".$id."'");}
if(($readinbox[3]==getuid_sid($sid))||($readinbox[1]==getuid_sid($sid))||($readinbox[5]==getuid_sid($sid))){
if((getuid_sid($sid)==$readinbox[3])&&(!isuser($readinbox[5]))){
if(isonline($readinbox[1])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
$ptxt="Inbox By: ";
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$readinbox[1]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$bylnk="<a href=\"../profile.php?who=$readinbox[1]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml".getnick_uid($readinbox[1])."</a>";
}else if((getuid_sid($sid)==$readinbox[1])&&(!isuser($readinbox[5]))){
if(isonline($readinbox[3])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
$ptxt="Inbox To: ";
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$readinbox[3]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$bylnk="<a href=\"../profile.php?who=$readinbox[3]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml".getnick_uid($readinbox[3])."</a>";
}else if(getuid_sid($sid)==$readinbox[5]){
if(isonline($readinbox[1])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$readinbox[1]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$bylnk="Inbox By: <a href=\"../profile.php?who=$readinbox[1]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml".getnick_uid($readinbox[1])."</a>";
if(isonline($readinbox[3])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$readinbox[3]."'"));
if($sex[0]=="M"){$color="#0000FF";}
else if($sex[0]=="F"){$color="#FF0066";}
$tolnk=" To: <a href=\"../profile.php?who=$readinbox[3]&amp;sid=$sid$chatlink\" style=\"color:$color;\">$iml".getnick_uid($readinbox[3])."</a>";
}
$main.="$ptxt$bylnk$tolnk<br/>";
$tmdt=date("H:i - D jS M y", $readinbox[2]);
$main.="$tmdt<br/><br/>";
$pmtext=getbbcode($readinbox[0],$sid,1);
$pmtext=str_replace("/faqs","<a href=\"./lists.php?action=faqs&amp;sid=$sid$chatlink\">".sitename()." F.A.Qs</a>", $pmtext);
$pmtext=str_replace("/reader",getnick_uid($readinbox[3]), $pmtext);
$main.=$pmtext;
$main.="</p>";
}
$main.="<div class=".align()."><form action=\"./send.php?send=1&amp;sid=$sid$chatlink\" method=\"post\">
<b>Reply:</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>";
if($readinbox[5]!=0){$main.="<input type=\"hidden\" name=\"who\" value=\"$readinbox[3]\"/>";}
else{$main.="<input type=\"hidden\" name=\"who\" value=\"$readinbox[1]\"/>";}
$main.="<input type=\"submit\" value=\"Send\"/></form></div>";
$archive=mysql_fetch_array(mysql_query("SELECT archive FROM inbox WHERE id='".$id."'"));
$main.="<p align=".align().">
<a href=\"./delete.php?id=$id&amp;sid=$sid$chatlink\">Delete</a><br/>
<a href=\"./forward.php?id=$id&amp;sid=$sid$chatlink\">Forward</a><br/>";
if($archive[0]=="0"){
$main.="<a href=\"./archive.php?id=$id&amp;sid=$sid$chatlink\">Archive</a><br/>";
}else if($archive[0]=="1"){
$main.="<a href=\"./archive.php?id=$id&amp;sid=$sid$chatlink\">Unarchive</a><br/>";
}
$main.="<a href=\"./report.php?id=$id&amp;sid=$sid$chatlink\">Report</a>";
if($rid!=""){$main.="<br/><a href=\"../chat/chat.php?sid=$sid$chatlink\">Back to $rname</a>";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox.php?sid=$sid$chatlink\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>