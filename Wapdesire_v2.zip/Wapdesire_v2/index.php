<?php
define('WCS',true);
include('./core/main.inc');
header_type();
addvisitor();
blocked_ip(ip(),0);
blocked_network(network(ip(),"isp"),0);
blocked_browser($_SERVER["HTTP_USER_AGENT"],0);
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}

/////////////////////////INDEX PAGE/////////////////////////

echo head_tag(sitename(),0,0);
$title="<img src=\"./phpThumb/phpThumb.php?src=../images/$logo\" alt=\"".sitename()."\"/><br/>
".date("g:ia",strtotime("-0 hours"))."<br/>".date("l jS F",strtotime("-0 hours"));
$main="<p align=".align().">
<b>Welcome to $sitename, This is the place for all your pleasures.<br/>
So kick back relax and enjoy this great chat/forum community ;o)</b>
</p>
<div class=".align().">
<form action=\"./login.php?username=$username&amp;password=$password\" method=\"get\">
<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/><br/>
<b>Username:</b><br/>
<input type=\"text\" name=\"username\" title=\"username\" maxlength=\"12\" size=\"12\"/><br/>
<b>Password:</b><br/>
<input type=\"password\" name=\"password\" title=\"password\" maxlength=\"10\" size=\"10\"/><br/>
<input type=\"submit\" value=\"Login\"/><br/>
<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/>
</form>
</div>
<p align=".align().">
-&gt; <a href=\"./register.php\">Register</a><br/>
-&gt; <a href=\"./terms.php\">Terms Of Use</a>
</p>
<p align=".align().">
<b>Online Members:</b> ".getnumonline($sid)."<br/>
<b>Browser:</b> ".browser()."<br/>
<b>Ip:</b> ".ip()."<br/>
<b>Network:</b> ".flag(ip()).network(ip(),"isp")." ".network(ip(),"country")."
</p>";
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>
