<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////EDIT TOPIC/POST/////////////////////////

if($topic==1)
{
addonline(getuid_sid($sid),"Forum Options","");
echo head_tag(getnick_sid($sid)."@Edit Topic",1,getnick_sid($sid));
$title="<b>Edit Topic</b>";
$main="<p align=".align().">\n";
$tname=mysql_fetch_array(mysql_query("SELECT fid FROM forumtopics WHERE id='".$thread."'"));
if(mod_tools("fid",$tname[0],"topic_".$thread,getuid_sid($sid),1)){
$res=mysql_query("UPDATE forumtopics SET text='".$ttext."' WHERE id='".$thread."'");
if($res){
//mysql_query("INSERT INTO ibwf_mlog SET action='topics', details='<b>".getnick_uid(getuid_sid($sid))."</b> Edited the text Of the thread ".mysql_escape_string(gettname($tid))." at the forum ".getfname($fid)."', actdt='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Topic Message Edited\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Database Error\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="<br/>\n";
$main.="<br/>$fivekey<a $key5 href=\"viewtopic.php?thread=$thread&amp;sid=$sid\">View Topic</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
}

else if($post==1)
{
addonline(getuid_sid($sid),"Forum Options","");
echo head_tag(getnick_sid($sid)."@Edit Post",1,getnick_sid($sid));
$title="<b>Edit Post</b>";
$main="<p align=".align().">\n";
$thread=mysql_fetch_array(mysql_query("SELECT thread FROM forumposts WHERE id='".$pid."'"));
$tname=mysql_fetch_array(mysql_query("SELECT fid FROM forumtopics WHERE id='".$thread[0]."'"));
if(mod_tools("fid",$tname[0],"post_".$thread[0],getuid_sid($sid),1)){
$res=mysql_query("UPDATE forumposts SET text='".$ptext."' WHERE id='".$pid."'");
if($res){
$tname=mysql_fetch_array(mysql_query("SELECT name FROM forumtopics WHERE id='".$tid."'"));
//mysql_query("INSERT INTO ibwf_mlog SET action='posts', details='<b>".getnick_uid(getuid_sid($sid))."</b> Edited Post Number $pid Of the thread ".mysql_escape_string($tname[0])." at the forum ".getfname($fid)."', actdt='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Post Edited\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Database Error\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="<br/>
<br/>$fivekey<a $key5 href=\"viewtopic.php?thread=$thread[0]&amp;sid=$sid\">View Topic</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
}
?>