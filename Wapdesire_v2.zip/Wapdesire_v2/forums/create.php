<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CREATE TOPIC/////////////////////////

if($create==1)
{
addonline(getuid_sid($sid),"Creating Forum Topic","");
echo head_tag(getnick_sid($sid)."@Creating Forum Topic",1,getnick_sid($sid));
$title="<b>Creating Forum Topic</b>";
$main="<p align=".align().">\n";
if(!canaccess(getuid_sid($sid),$fid)){
addonline(getuid_sid($sid),"In The Forbidden Zone","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
<b>Error!!!<br/>Permission Denied...</b><br/>
You Can't View The Contents Of This Forum
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$texst=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE name LIKE '".$topic."' AND fid='".$fid."'"));
if($texst[0]==0){
$res=false;
$ltopic=mysql_fetch_array(mysql_query("SELECT date FROM forumtopics WHERE uid='".getuid_sid($sid)."' ORDER BY date DESC LIMIT 1"));
global $topic_af;
$antiflood=time()-$ltopic[0];
if($antiflood>$topic_af){
if((trim($title)!="")||(trim($tpctxt)!="")){
if(!blocked_site($topic,getuid_sid($sid))&&!blocked_site($text,getuid_sid($sid))){
$res=mysql_query("INSERT INTO forumtopics SET name='".$topic."', fid='".$fid."', uid='".getuid_sid($sid)."', text='".$text."', date='".time()."', lastpost='".time()."'");
}else{
$bantime=time()+(30*24*60*60);
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
Can't Post Topic<br/>
<br/>
You just tried creating a topic with a link to one of the crapiest sites on earth<br/>
The members of these sites spam here a lot, so go to that site and stay there if you don't like it here<br/>
as a result of your stupid action:<br/>
1. you have lost your sheild<br/>
2. you have lost all your plusses<br/>
3. You are BANNED!
</p>\n";
mysql_query("INSERT INTO logs SET action='autoban', details='<b>".getnick_uid(1)."</b> auto banned ".getnick_sid($sid)." for spamming forums', date='".time()."'");
mysql_query("INSERT INTO banned SET uid='".getuid_sid($sid)."', penalty='1', byid='1', remaining='".$bantime."', reason='Banned: Automatic Ban for spamming for a crap site'");
mysql_query("UPDATE profiles SET points='0' WHERE uid='".getuid_sid($sid)."'");
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
}
if($res){
if((isspam($text))||(isspam($topic))){
mysql_query("UPDATE forumtopics SET reported='1' WHERE name='".$topic."' AND text='".$text."'");
}
$usts=mysql_fetch_array(mysql_query("SELECT forumposts, points FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$ups=$usts[0]+1;
$upl=$usts[1]+1;
mysql_query("UPDATE profiles SET forumposts='".$ups."', points='".$upl."' WHERE uid='".getuid_sid($sid)."'");
$thread=mysql_fetch_array(mysql_query("SELECT id FROM forumtopics WHERE name='".$topic."' AND fid='".$fid."'"));
$clubid=mysql_fetch_array(mysql_query("SELECT clubid FROM forums WHERE id='".$fid."'"));
$pts=mysql_fetch_array(mysql_query("SELECT points FROM clubs WHERE id='".$clubid[0]."'"));
if($clubid[0]!=0){mysql_query("UPDATE clubs SET points='".($pts[0]+1)."' WHERE id='".$clubid[0]."'");}
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Topic <b>$topic</b> Created Successfully<br/>
<br/><a href=\"viewtopic.php?thread=$thread[0]&amp;sid=$sid\">View Topic</a>\n";
}
else{$main.="<img src=\"../images/error.gif\" alt=\"X\"/><br/>Error Creating New Thread\n";}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"X\"/><br/>Antiflood Control: ".($topic_af-$antiflood)."\n";
}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"X\"/><br/>Topic Name already Exist\n";}
$fname=mysql_fetch_array(mysql_query("SELECT name FROM forums WHERE id='".$fid."'"));
$main.="<br/><br/>$fivekey<a $key5 href=\"./viewforum.php?fid=$fid&amp;sid=$sid\">$fname[0] Forum</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Creating Forum Topic","");
echo head_tag(getnick_sid($sid)."@Create Forum Topic",1,getnick_sid($sid));
$title="<b>Create Forum Topic</b>";
if(!canaccess(getuid_sid($sid),$fid)){
addonline(getuid_sid($sid),"In The Forbidden Zone","");
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"x\"/><br/>
<b>Error!!!<br/>Permission Denied...</b><br/>
You Can't View The Contents Of This Forum
</p>\n";
$L1="<a href=\"./forums.php?sid=$sid\">Forums</a>";
$L2="<a href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,0,0,0,0,0,0,$main);
echo foot_tag();
exit();
}
$main="<div class=".align().">
<form action=\"create.php?create=1&amp;sid=$sid\" method=\"post\">
<b>Title:</b><br/>
<input name=\"topic\" maxlength=\"30\"/><br/>
<b>Text:</b><br/><input name=\"text\" maxlength=\"500\"/><br/>
<input type=\"hidden\" name=\"fid\" value=\"$fid\"/>
<input type=\"submit\" value=\"Create\"/>
</form>
</div>\n";
$fname=mysql_fetch_array(mysql_query("SELECT name FROM forums WHERE id='".$fid."'"));
$main.="<p align=".align().">\n$fivekey<a $key5 href=\"./viewforum.php?fid=$fid&amp;sid=$sid\">$fname[0] Forum</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>