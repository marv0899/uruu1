<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW TOPIC/////////////////////////

$tinfo=mysql_fetch_array(mysql_query("SELECT name, text, uid, date, views, fid, poll from forumtopics WHERE id='".$thread."'"));
addonline(getuid_sid($sid),"Viewing $tinfo[0] Topic","forums/viewtopic.php?thread=$thread");
echo head_tag(getnick_sid($sid)."@View Topic",1,getnick_sid($sid));
$title="<b>Viewing ".getbbcode($tinfo[0],$sid,1)." Topic</b><br/>";
if($count_popup[0]>0){
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main="<div class=".align().">
<b>Popup Message<br/>
From $usersex<span style=\"color:$color;\">".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"../popups.php?send=1&amp;who=$pminfo[2]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>\n";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$main.="<p align=".align().">
<a href=\"./$location[0]&amp;sid=$sid\">Skip Msg</a>
</p>
<p align=".align().">\n";
}else{
$main="<p align=".align().">\n";
}
if(!canaccess(getuid_sid($sid),$tinfo[5])){
addonline(getuid_sid($sid),"In The Forbidden Zone","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/><b>Error!!!<br/>Permission Denied...</b><br/>
You Can't View The Contents Of This Forum<br/>";
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE thread='".$thread."'"));
$num_items=$noi[0]+1;
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page==""||$page<1)$page=1;
if($go=="last")$page=$num_pages;
$posts_per_page=5;
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$posts_per_page;
$main.="$onekey<a $key1 href=\"reply.php?thread=$thread&amp;sid=$sid\">Post reply</a><br/>\n";
$lastlink="<a href=\"viewtopic.php?thread=$thread&amp;go=last&amp;sid=$sid\">Last Page</a>\n";
$firstlink="<a href=\"viewtopic.php?thread=$thread&amp;page=1&amp;sid=$sid\">First Page</a> \n";
$golink="";
if($page>1){$golink=$firstlink;}
if($page<$num_pages){$golink .= $lastlink;}
if($golink!=""){$main.="$golink<br/>";}
$vws=$tinfo[4]+1;
$rpls=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE thread='".$thread."'"));
$main.="Replies: $rpls[0] - Views: $vws<br/>\n";
if($page==1){
$posts_per_page=4;
mysql_query("UPDATE forumtopics SET views='".$vws."' WHERE id='".$thread."'");
$ttext=mysql_fetch_array(mysql_query("SELECT uid, text, date, poll FROM forumtopics WHERE id='".$thread."'"));
if(isonline($ttext[0])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
if($go==$thread){$fli="<img src=\"../images/flag.gif\" alt=\"!\"/>";}
else{$fli="";}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$ttext[0]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>\n";$color=" style=\"color:#0000FF;\"";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>\n";$color=" style=\"color:#FF0066;\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1)."\n";}
$main.="<br/>
<a href=\"../profile.php?who=$ttext[0]&amp;sid=$sid\"$color>
$iml
".getnick_uid($ttext[0])."</a><br/>
".status($ttext[0],0)."
<br/><small>".date("H:i - D jS M y",$ttext[2])."</small><br/>
$fli".getbbcode($ttext[1],$sid,1)." 
<a href=\"./options.php?topic=1&amp;thread=$thread&amp;sid=$sid\">*</a><br/>\n";
if($ttext[3]>0){$main.="<a href=\"./index.php?action=viewtpl&amp;sid=$sid&amp;who=$thread\">POLL</a><br/>";}
}
if($page>1){$limit_start--;}
$sql="
SELECT id, text, uid, date, quote 
FROM forumposts WHERE thread='".$thread."' 
ORDER BY date LIMIT $limit_start, $posts_per_page
";
$posts=mysql_query($sql);
while($post=mysql_fetch_array($posts)){
if(isonline($post[2])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
if($post[4]>0){
$qtl="<i><a href=\"./viewtopic.php?thread=$thread&amp;sid=$sid&amp;pst=\">(quote:p=blaze,d=16-04-2006)</a></i>";
}
if($go==$post[0]){$fli="<img src=\"../images/flag.gif\" alt=\"!\"/>";}
else{$fli="";}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$post[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>\n";$color=" style=\"color:#0000FF;\"";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>\n";$color=" style=\"color:#FF0066;\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1)."\n";}
$main.="<br/>
<a href=\"../profile.php?who=$post[2]&amp;sid=$sid\"$color>
$iml
".getnick_uid($post[2])."</a><br/>
".status($post[2],0)."
<br/><small>".date("H:i - D jS M y",$post[3])."</small><br/>
$fli".getbbcode($post[1],$sid,1)." 
<a href=\"./options.php?post=1&amp;pid=$post[0]&amp;page=$page&amp;fid=$tinfo[5]&amp;sid=$sid\">*</a><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./viewtopic.php?page=".($page-1)."&amp;thread=$thread&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./viewtopic.php?page=".($page+1)."&amp;thread=$thread&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("viewtopic","thread",$thread,$sid);}
$main.="<p align=".align().">\n$onekey<a $key1 href=\"reply.php?thread=$thread&amp;sid=$sid\">Post reply</a><br/>\n";
$fname=mysql_fetch_array(mysql_query("SELECT clubid, name FROM forums WHERE id='".$tinfo[5]."'"));
$main.="<br/><a href=\"./viewforum.php?fid=$tinfo[5]&amp;sid=$sid\">$fname[1] Forum</a>\n";
if($fname[0]>0){
$clubname=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$fname[0]."'"));
$main.="<br/>$fivekey<a $key5 href=\"../clubs/view.php?id=$fname[0]&amp;sid=$sid\">$clubname[0] Club</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>