<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////FORUM OPTIONS/////////////////////////

if($topic==1)
{
addonline(getuid_sid($sid),"Forum Options","");
$nick=getnick_sid($sid);
echo head_tag($nick."@Forum Options",1,$nick);
$title="<b>Forum Options</b>";
$main="<p align=".align().">\n";
addonline(getuid_sid($sid),"Topic Options","");
$tinfo=mysql_fetch_array(mysql_query("SELECT name, fid, uid, text, pinned, closed FROM forumtopics WHERE id='".$thread."'"));
$trid=$tinfo[2];
$ttext=htmlspecialchars($tinfo[3]);
$tname=htmlspecialchars($tinfo[0]);
$main.="Topic ID: <b>$thread</b><br/>\n";
$trnick=getnick_uid($trid);
$main.="<a href=\"../inbox/send.php?who=$trid&amp;sid=$sid\">&#187;Send Inbox To $trnick</a><br/>
<a href=\"../profile.php?who=$trid&amp;sid=$sid\">&#187;View $trnick's Profile</a>\n";
//echo "<a href=\"index.php?action=post&amp;sid=$sid&amp;thread=$thread&amp;qut=$pid\">&#187;Quote</a><br/>";
/*
$plid=mysql_fetch_array(mysql_query("SELECT poll FROM forumtopics WHERE id='".$thread."'"));
if($plid[0]==0){
if(isowner(getuid_sid($sid))){
$main.="<a href=\"index.php?action=pltpc&amp;sid=$sid&amp;thread=$thread\">&#187;Add Poll</a><br/>";
}
}else{
if(isowner(getuid_sid($sid))){
$main.="<a href=\"genproc.php?action=dltpl&amp;sid=$sid&amp;thread=$thread\">&#187;Delete Poll</a><br/>";
}
}
*/
//$main.="<a href=\"genproc.php?action=rtpc&amp;sid=$sid&amp;thread=$thread\">&#187;Report</a>";
$main.="</p>\n";
if(mod_tools("fid",$tinfo[1],"topic_".$thread,getuid_sid($sid),1)){
$main.="<div class=".align().">
<form action=\"rename.php?thread=$thread&amp;sid=$sid\" method=\"post\">
<b>Title:</b><br/>
<input name=\"tname\" value=\"$tname\" maxlength=\"25\"/><br/>
<input type=\"submit\" value=\"Rename\">
</form>
</div>
<div class=".align().">
<form action=\"./edit.php?topic=1&amp;sid=$sid&amp;thread=$thread\" method=\"post\">
<b>Text:</b><br/>
<input name=\"ttext\" value=\"$ttext\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Edit\">
</form>
</div>
<p align=".align().">
<a href=\"./delete.php?topic=1&amp;thread=$thread&amp;sid=$sid\">&#187;Delete</a><br/>\n";
}
if(mod_tools("fid",$tinfo[1],"topic_".$thread,getuid_sid($sid),0)){
if($tinfo[5]=='1'){$ctxt="Open";$cact="0";}
else{$ctxt="Close";$cact="1";}
$main.="<a href=\"./close.php?sid=$sid&amp;thread=$thread&amp;tdo=$cact\">&#187;$ctxt</a><br/>\n";
if($tinfo[4]=='1'){$ptxt="Unpin";$pact="0";}
else{$ptxt="Pin";$pact="1";}
$main.="<a href=\"./pin.php?sid=$sid&amp;thread=$thread&amp;tdo=$pact\">&#187;$ptxt</a>
</p>\n";
}
//echo "<a href=\"index.php?action=post&amp;sid=$sid&amp;thread=$thread&amp;qut=$pid\">&#187;Quote</a><br/>";
$forums=mysql_query("SELECT id, name FROM forums WHERE clubid='0'");
if(mod_tools("fid",$tinfo[1],"topic_".$thread,getuid_sid($sid),0)){
$main.="<div class=".align().">
<form action=\"move.php?thread=$thread&amp;sid=$sid\" method=\"post\">
<b>Move to:</b><br/>
<select name=\"mtf\">\n";
while($forum=mysql_fetch_array($forums)){
$main.="<option value=\"$forum[0]\">$forum[1]</option>\n";
}
$main.="</select><br/>
<input type=\"submit\" value=\"Move\"/>
</form>
</div>\n";
}
$main.="<p align=".align().">\n$fivekey<a $key5 href=\"viewtopic.php?thread=$thread&amp;sid=$sid\">Back to topic</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
}

else if($post==1)
{
$pinfo= mysql_fetch_array(mysql_query("SELECT uid, thread, text FROM forumposts WHERE id='".$pid."'"));
$tinfo=mysql_fetch_array(mysql_query("SELECT fid FROM forumtopics WHERE id='".$pinfo[1]."'"));
$trid=$pinfo[0];
$tid=$pinfo[1];
$ptext=htmlspecialchars($pinfo[2]);
addonline(getuid_sid($sid),"Forum Options","");
echo head_tag(getnick_sid($sid)."@Forum Options",1,getnick_sid($sid));
$title="<b>Post Options</b>";
$main="<p align=".align().">\n";
$trnick=getnick_uid($trid);
$main.="<a href=\"../inbox/send.php?who=$trid&amp;sid=$sid\">&#187;Send PM to $trnick</a><br/>
<a href=\"../profile.php?who=$trid&amp;sid=$sid\">&#187;View $trnick's Profile</a>\n";
//echo "<a href=\"index.php?action=post&amp;sid=$sid&amp;tid=$tid&amp;qut=$pid\">&#187;Quote</a><br/>";
//$main.="<a href=\"genproc.php?action=rpost&amp;sid=$sid&amp;pid=$pid\">&#187;Report</a>";
$main.="</p>\n";
if(mod_tools("fid",$tinfo[0],"post_".$pinfo[1],getuid_sid($sid),1)){
$main.="<div class=".align().">
<form action=\"./edit.php?post=1&amp;pid=$pid&amp;sid=$sid\" method=\"post\">
<b>Text:</b><br/> 
<input name=\"ptext\" value=\"$ptext\" maxlength=\"500\"/>
<br/><input type=\"submit\" value=\"Edit\">
</form>
</div>
<p align=".align().">\n";
$main.="<a href=\"./delete.php?post=1&amp;pid=$pid&amp;sid=$sid\">&#187;Delete</a><br/><br/>\n";
}
$main.="$fivekey<a $key5 href=\"viewtopic.php?page=$page&amp;thread=$tid&amp;sid=$sid\">Back to topic</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
}
?>