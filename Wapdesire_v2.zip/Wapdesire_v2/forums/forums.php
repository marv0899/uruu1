<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////FORUMS/////////////////////////

addonline(getuid_sid($sid),"Forums","forums/forums.php");
echo head_tag(getnick_sid($sid)."@Forums",1,getnick_sid($sid));
if($count_popup[0]>0){
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main="<div class=".align().">
<b>Popup Message<br/>
From $usersex<span style=\"color:$color;\">".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"../popups.php?send=1&amp;who=$pminfo[2]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>\n";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$main.="<p align=".align().">
<a href=\"./$location[0]?sid=$sid\">Skip Msg</a>\n</p>\n";
}
if(forumview()==0)
{
$title="<b>Forums</b><br/>Forum Categories";
$fcats=mysql_query("SELECT id, name FROM forumcats ORDER BY position, id");
$iml="\n<img src=\"../images/f.gif\" alt=\"\"/>";
while($fcat=mysql_fetch_array($fcats)){
$main.="<p align=".align().">\n<b>$fcat[1]</b>";
$forums=mysql_query("SELECT id, name FROM forums WHERE catid='".$fcat[0]."' AND clubid='0' ORDER BY position, id, name");
while($forum=mysql_fetch_array($forums)){
$notp=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$forum[0]."'"));
$nops=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread = b.id WHERE b.fid='".$forum[0]."'"));
$main.="<br/>\n<a href=\"./viewforum.php?fid=$forum[0]&amp;sid=$sid\">$iml$forum[1] $notp[0]/$nops[0]</a>";
$lpt=mysql_fetch_array(mysql_query("SELECT id, name FROM forumtopics WHERE fid='".$forum[0]."' ORDER BY lastpost DESC LIMIT 0,1"));
$nops=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE thread='".$lpt[0]."'"));
if($nops[0]==0){
$pinfo=mysql_fetch_array(mysql_query("SELECT uid FROM forumtopics WHERE id='".$lpt[0]."'"));
$tluid=$pinfo[0];
}else{
$pinfo=mysql_fetch_array(mysql_query("SELECT uid FROM forumposts WHERE thread='".$lpt[0]."' ORDER BY date DESC LIMIT 0, 1"));
}
if($pinfo[0]>0){
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$pinfo[0]."'"));
if($sex[0]=="M"){$color=" style=\"color:#0000FF;\"";}
else if($sex[0]=="F"){$color=" style=\"color:#FF0066;\"";}
else{$color="";}
$main.="<br/>\nLast Post: <a href=\"./viewtopic.php?thread=$lpt[0]&amp;go=last&amp;sid=$sid\">$lpt[1]</a>(<a href=\"../profile.php?who=$pinfo[0]&amp;sid=$sid\"$color>".getnick_uid($pinfo[0])."</a>)";
}
}
$main.="\n</p>\n";
}
}else if((forumview()==2)||(forumview()==1)){
$fcats=mysql_fetch_array(mysql_query("SELECT name from forumcats WHERE id='".$cat."' AND name!='Forums'"));
$title="<b>Forums</b>";
if($fcats[0]!=""){$title.="<br/>($fcats[0])";}
else{$title.="";}
$main="<p align=".align().">\n";
if(forumview()==2){$catid="catid='".$cat."' AND";}
$forums=mysql_query("SELECT id, name FROM forums WHERE $catid clubid='0' ORDER BY position, id, name");
while($forum=mysql_fetch_array($forums)){
$topics=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$forum[0]."'"));
$posts=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread = b.id WHERE b.fid='".$forum[0]."'"));
$iml="<img src=\"../images/f.gif\" alt=\"*\"/>";
$main.="<a href=\"./viewforum.php?fid=$forum[0]&amp;sid=$sid\">$iml$forum[1] $topics[0]/$posts[0]</a><br/>\n";
$lpt=mysql_fetch_array(mysql_query("SELECT id, name FROM forumtopics WHERE fid='".$forum[0]."' ORDER BY lastpost DESC LIMIT 0,1"));
$nops=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE thread='".$lpt[0]."'"));
if($nops[0]==0){
$pinfo=mysql_fetch_array(mysql_query("SELECT uid FROM forumtopics WHERE id='".$lpt[0]."'"));
$tluid=$pinfo[0];
}else{
$pinfo=mysql_fetch_array(mysql_query("SELECT uid FROM forumposts WHERE thread='".$lpt[0]."' ORDER BY date DESC LIMIT 0, 1"));
}
if($pinfo[0]>0){
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$pinfo[0]."'"));
if($sex[0]=="M"){$color=" style=\"color:#0000FF;\"";}
else if($sex[0]=="F"){$color=" style=\"color:#FF0066;\"";}
else{$color="";}
$main.="Last Post: <a href=\"./viewtopic.php?thread=$lpt[0]&amp;go=last&amp;sid=$sid\">$lpt[1]</a>(<a href=\"../profile.php?who=$pinfo[0]&amp;sid=$sid\"$color>".getnick_uid($pinfo[0])."</a>)<br/>\n";
}
}
}
$L1="$sevenkey<a $key7 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$eightkey<a $key8 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$ninekey<a $key9 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,0,0,0,0,$main);
echo foot_tag();
?>