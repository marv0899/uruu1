<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CLOSE TOPIC/////////////////////////

addonline(getuid_sid($sid),"Forum Options","");
echo head_tag(getnick_sid($sid)."@Delete Topic",1,getnick_sid($sid));
$title="<b>Delete Topic</b>";
$main="<p align=".align().">";
$tname=mysql_fetch_array(mysql_query("SELECT fid FROM forumtopics WHERE id='".$thread."'"));
if(mod_tools("fid",$tname[0],"topic_".$thread,getuid_sid($sid),0)){
$res=mysql_query("UPDATE forumtopics SET closed='".$tdo."' WHERE id='".$thread."'");
if($res){
if($tdo==1){$msg="Closed";}
else{$msg="Opened";}
//mysql_query("INSERT INTO ibwf_mlog SET action='topics', details='<b>".getnick_uid(getuid_sid($sid))."</b> Closed The thread ".mysql_escape_string(gettname($tid))." at the forum ".getfname($fid)."', actdt='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/>Topic $msg\n";
$tpci=mysql_fetch_array(mysql_query("SELECT name, uid FROM forumtopics WHERE id='".$thread."'"));
$tname=htmlspecialchars($tpci[0]);
$msg="your thread [topic=$tid]$tname"."[/topic] is $msg"."[br/][small][i]p.s: this is an automatic pm[/i][/small]";
autopm($msg, $tpci[1]);
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/>Database Error\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="<br/>
<br/>$fivekey<a $key5 href=\"./viewtopic.php?thread=$thread[0]&amp;sid=$sid\">View Topic</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>