<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW FORUM/////////////////////////

$forum=mysql_fetch_array(mysql_query("SELECT name FROM forums WHERE id='".$fid."'"));
addonline(getuid_sid($sid),"Viewing ".$forum[0]." Forum","forums/viewforum.php?fid=$fid");
$nick=getnick_sid($sid);
echo head_tag($nick."@Forums",1,$nick);
$title="<b>Viewing $forum[0] Forum</b>";
if($count_popup[0]>0){
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main="<div class=".align().">
<b>Popup Message<br/>
From $usersex<span style=\"color:$color;\">".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"../popups.php?send=1&amp;who=$pminfo[2]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>\n";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$main.="<p align=".align().">
<a href=\"./$location[0]&amp;sid=$sid\">Skip Msg</a>
</p>
<p align=".align().">\n";
}else{
$main="<p align=".align().">\n";
}
if(!canaccess(getuid_sid($sid),$fid)){
addonline(getuid_sid($sid),"In The Forbidden Zone","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/><b>Error!!!<br/>Permission Denied...</b><br/>
You Can't View The Contents Of This Forum\n
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}
$forumname=mysql_fetch_array(mysql_query("SELECT name from forums WHERE id='".$fid."'"));
/*
$norf=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM rss WHERE fid='".$fid."'"));
if($norf[0]>0){
echo "<a href=\"rwrss.php?action=showfrss&amp;fid=$fid&amp;sid=$sid\"><img src=\"../images/rss.gif\" alt=\"rss\"/>$forumname[0] Extras</a><br/>";
}
*/
$main.="$onekey<a $key1 href=\"./create.php?fid=$fid&amp;sid=$sid\">New Topic</a><br/>\n<br/>\n";
if($page==""||$page<=0)$page=1;
if($page==1){
$topics=mysql_query("SELECT id, name, closed, views, poll FROM forumtopics WHERE fid='".$fid."' AND pinned='1' ORDER BY lastpost DESC, name, id LIMIT 0,5");
while($topic=mysql_fetch_array($topics)){
$iml="<img src=\"../images/normal.gif\" alt=\"*\"/>";
$iml="*";
$atxt="";
if($topic[2]=='1'){$atxt="(X)";}
if($topic[4]>0){$pltx="(P)";}
else{$pltx="";}
$tnm=htmlspecialchars($topic[1]);
$nop=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE thread='".$topic[0]."'"));
$main.="<a href=\"./viewtopic.php?thread=$topic[0]&amp;sid=$sid\">$iml $pltx$tnm $nop[0] $atxt</a><br/>\n";
}
if($topic[4]>0){$main.="<br/>\n";}
}
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$fid."' AND pinned='0'"));
$num_items=$noi[0];
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($limit_start<0)$limit_start=0;
$topics=mysql_query("SELECT id, name, closed, views, moved, poll FROM forumtopics WHERE fid='".$fid."' AND pinned='0' ORDER BY lastpost DESC, name, id LIMIT $limit_start, $items_per_page");
$pinned=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$fid."' AND pinned='1'"));
if(mysql_num_rows($topics)>0){
while($topic=mysql_fetch_array($topics)){
$nop=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE thread='".$topic[0]."'"));
$iml="<img src=\"../images/normal.gif\" alt=\"*\"/>";
if($nop[0]>24){$iml="<img src=\"../images/hot.gif\" alt=\"*\"/>";}
if($topic[4]=='1'){$iml="<img src=\"../images/moved.gif\" alt=\"*\"/>";}
if($topic[2]=='1'){$iml="<img src=\"../images/closed.gif\" alt=\"*\"/>";}
if($topic[5]>0){$iml="<img src=\"../images/poll.gif\" alt=\"*\"/>";}
$atxt="";
if($topic[2]=='1'){$atxt="(X)";}
$tnm=htmlspecialchars($topic[1]);
$main.="<a href=\"viewtopic.php?thread=$topic[0]&amp;sid=$sid\">$iml $tnm $nop[0]$atxt</a><br/>\n";
}
}
else if($pinned[0]==0){$main.="No Topics Here!<br/>\n";}
if($page>1){
$main.="<br/><a href=\"./viewforum.php?page=".($page-1)."&amp;fid=$fid&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./viewforum.php?page=".($page+1)."&amp;fid=$fid&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("viewforum","fid","$fid",$sid);}

$main.="<p align=".align().">\n$onekey<a $key1 href=\"./create.php?fid=$fid&amp;sid=$sid\">New Topic</a>\n";
$clubid=mysql_fetch_array(mysql_query("SELECT clubid FROM forums WHERE id='".$fid."'"));
if($clubid[0]>0){
$clubname=mysql_fetch_array(mysql_query("SELECT name FROM clubs WHERE id='".$clubid[0]."'"));
$main.="<br/>$fivekey<a $key5 href=\"../clubs/view.php?id=$clubid[0]&amp;sid=$sid\">$clubname[0] Club</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>