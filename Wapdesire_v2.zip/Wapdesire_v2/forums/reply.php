<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(forumbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo forumbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////REPLY TOPIC/////////////////////////

if($reply==1)
{
addonline(getuid_sid($sid),"Posting Forum Reply","");
echo head_tag(getnick_sid($sid)."@Posting Forum Reply",1,getnick_sid($sid));
$title="<b>Posting Forum Reply</b>";
$main="<p align=".align().">";
$tfid=mysql_fetch_array(mysql_query("SELECT fid FROM forumtopics WHERE id='".$thread."'"));
if(!canaccess(getuid_sid($sid),$tfid[0])){
addonline(getuid_sid($sid),"In The Forbidden Zone","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/>
<br/>$thread<br/>
<b>Error!!!<br/>Permission Denied...</b><br/>
You Can't View The Contents Of This Forum
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$res=false;
$closed=mysql_fetch_array(mysql_query("SELECT closed FROM forumtopics WHERE id='".$thread."'"));
if($closed[0]!='1'){
$anti_flood=mysql_fetch_array(mysql_query("SELECT value FROM settings WHERE id='5'"));
$lpost=mysql_fetch_array(mysql_query("SELECT date FROM forumposts WHERE uid='".getuid_sid($sid)."' ORDER BY date DESC LIMIT 1"));
global $post_af;
$antiflood=time()-$lpost[0];
if($antiflood>$anti_flood[0]){
if(trim($text)!=""){
if(!blocked_site($text,getuid_sid($sid))){
$res=mysql_query("INSERT INTO forumposts SET text='".$text."', thread='".$thread."', uid='".getuid_sid($sid)."', date='".time()."', quote='".$qut."'");
}else{
$bantime=time()+(30*24*60*60);
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
Can't Post Reply<br/>
<br/>
You just tried posting a reply with a link to one of the crapiest sites on earth<br/>
The members of these sites spam here a lot, so go to that site and stay there if you don't like it here<br/>
as a result of your stupid action:<br/>
1. you have lost your sheild<br/>
2. you have lost all your plusses<br/>
3. You are BANNED!
</p>\n";
mysql_query("INSERT INTO logs SET action='autoban', details='<b>".getnick_uid(1)."</b> auto banned ".getnick_sid($sid)." for spamming forums', date='".time()."'");
mysql_query("INSERT INTO banned SET uid='".getuid_sid($sid)."', penalty='1', byid='1', remaining='".$bantime."', reason='Banned: Automatic Ban for spamming for a crap site'");
mysql_query("UPDATE profiles SET points='0', WHERE uid='".getuid_sid($sid)."'");
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
}
if($res){
if(isspam($text)){
mysql_query("UPDATE forumposts SET reported='1' WHERE thread='".$thread."' AND text='".$text."'");
}
$usts=mysql_fetch_array(mysql_query("SELECT forumposts, points FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$res2=mysql_fetch_array(mysql_query("SELECT name, uid, fid FROM forumtopics WHERE id='".$thread."'"));
$clubid=mysql_fetch_array(mysql_query("SELECT clubid FROM forums WHERE id='".$res2[2]."'"));
$pts=mysql_fetch_array(mysql_query("SELECT points FROM clubs WHERE id='".$clubid[0]."'"));
if($clubid[0]!=0){mysql_query("UPDATE clubs SET points='".($pts[0]+1)."' WHERE id='".$clubid[0]."'");}
$tname=htmlspecialchars($res2[0]);
if(($res2[1]!=getuid_sid($sid))&&(automsgs($res2[1]))){
$msg="Your Topic [topic=$thread]$tname"."[/topic] has been Replied to by ".getnick_sid($sid)." [br/][small][i]p.s: this is an automated pm[/i][/small]";
autopm($msg,$res2[1]);
}
mysql_query("UPDATE profiles SET forumposts='".($usts[0]+1)."', points='".($usts[1]+1)."' WHERE uid='".getuid_sid($sid)."'");
mysql_query("UPDATE forumtopics SET lastpost='".time()."' WHERE id='".$thread."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Message Posted Successfully<br/>
<br/><a href=\"./viewtopic.php?thread=$thread&amp;go=last&amp;sid=$sid\">View Topic</a>\n";
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Posting Message\n";}
}else{
$af=$anti_flood[0]-$antiflood;
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Antiflood Control: $af Seconds\n";
}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Topic is closed for posting\n";}
$fname=mysql_fetch_array(mysql_query("SELECT name FROM forums WHERE id='".$tfid[0]."'"));
$main.="<br/>\n<br/>$fivekey<a $key5 href=\"./viewforum.php?fid=$tfid[0]&amp;sid=$sid\">$fname[0] Forum</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Posting Forum Reply","forums.php?action=$action&amp;thread=$thread");
echo head_tag(getnick_sid($sid)."@Post Forum Reply",1,getnick_sid($sid));
$title="<b>Post Forum Reply</b>";
$tfid=mysql_fetch_array(mysql_query("SELECT fid FROM forumtopics WHERE id='".$thread."'"));
if(!canaccess(getuid_sid($sid), $tfid[0])){
addonline(getuid_sid($sid),"In The Forbidden Zone","");
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"x\"/><br/>
<b>Error!!!<br/>Permission Denied...</b><br/>
You Can't View The Contents Of This Forum
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$main="<div class=".align().">
<form action=\"./reply.php?reply=1&amp;sid=$sid\" method=\"post\">
<b>Text:</b><br/>
<input name=\"text\" maxlength=\"500\"/>
<input type=\"hidden\" name=\"thread\" value=\"$thread\"/>
<input type=\"hidden\" name=\"qut\" value=\"$qut\"/>
<br/><input type=\"submit\" value=\"Post\"/>
</form>
</div>
<p align=".align().">
<a href=\"./viewtopic.php?thread=$thread&amp;sid=$sid\">Back to topic</a><br/>";
$fname=mysql_fetch_array(mysql_query("SELECT name FROM forums WHERE id='".$tfid[0]."'"));
$main.="<br/>$fivekey<a $key5 href=\"forums.php?action=viewforum&amp;fid=$tfid[0]&amp;sid=$sid\">$fname[0] Forum</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>