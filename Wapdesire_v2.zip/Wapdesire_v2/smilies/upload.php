<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////////UPLOAD/////////////////////////////

addonline(getuid_sid($sid),"Upload Files","");
echo head_tag(getnick_sid($sid)."@Upload Files",1,getnick_sid($sid));
$title="<u><i><b>Upload Files</b></i></u><br/>";	
$main="<p align=".align().">\n";
$size_bytes=2097512;
$main.="Max <b>".round($size_bytes/1048576,1)."</b> Mb
</p>
<div class=".align().">
<form method=\"post\" enctype=\"multipart/form-data\" action=\"./upload.php?upload=yes&amp;sid=$sid\">
<b>Code:</b><br/>
<input name=\"code\" maxlength=\"100\" value=\"\"/><br/>
<b>Site Image:</b><br/>
<select name=\"mood\">
<option value=\"0\">No</option>
<option value=\"1\">Yes</option>
</select><br/>
<b>Hidden:</b><br/>
<select name=\"hidden\">
<option value=\"0\">No</option>
<option value=\"1\">Yes</option>
</select><br/>
<b>Smiley:</b><br/>
<input type=\"file\" name=\"filetoupload\"/><br>
<input type=\"submit\" name=\"uploadform\" value=\"Upload\"/>
</form>
</div>
<p align=".align().">\n";
$extlimit="yes";
$limitedext=array(".jpg",".jpeg",".gif");
$ext=strtolower(strrchr($_FILES['filetoupload'][name],'.'));
$file_type=$_FILES['filetoupload']['type'];
$file_name=$_FILES['filetoupload']['name'];
$file_size=$_FILES['filetoupload']['size'];
$file_tmp=$_FILES['filetoupload']['tmp_name'];
if($upload=="yes"){
if(!is_uploaded_file($_FILES['filetoupload']['tmp_name'])){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>No file selected!<br/>\n";
}
else if($extlimit=="yes" && !in_array($ext,$limitedext)){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Invalid file type!<br/>\n";
}
else if($file_size>$size_bytes){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Exceeded File size limit! Maximum <b>$kb</b> Kb.<br/>\n";
}
else if(file_exists("./$file_name")){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Filename already exists!<br/>\n";
}
else if($file_size){
$file_name=str_replace(" ","",$file_name);
mysql_query("INSERT INTO smilies SET code='".$code."', path='smilies/".$file_name."', hidden='".$hidden."', mood='".$mood."', date='".time()."'"); 
move_uploaded_file($file_tmp, "./".$file_name);
$main.="<img src=\"./$file_name\" alt=\"$file_name\"/><br/>
successfully uploaded!<br/>\n";
}
else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Unknown error! Pls try again...<br/>\n";
}
}
$main.="$fivekey<a $key5 href=\"../admin/tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>