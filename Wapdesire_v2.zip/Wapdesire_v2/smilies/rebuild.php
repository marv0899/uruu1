<?php
define('WCS',true);
include('../core/main.inc');
if(!($dp=opendir("./")))die("Cannot open ./");
$file_array=array();
while($file=readdir($dp)){
if(substr($file,0,1)!='.' and $file!="index.php" and $file!="image.php" and $file!="smilies.php" and $file!="upload.php" and $file!="rebuild.php"){
$file_array[]=$file;
}
}
sort($file_array);
$first_record=$page*count($file_array);
$last_record=$first_record+count($file_array);
while(list($fileIndexValue,$file_name)=each($file_array)){
if(($fileIndexValue>=$first_record)AND($fileIndexValue<$last_record)){
$code=explode(".",$file_name);
mysql_query("INSERT INTO smilies SET code='(".$code[0].")', path='smilies/".$file_name."', mood='1', hidden='0', date='".time()."'");
echo mysql_error();
echo $file_name."<br/>\n";
}
}
?>