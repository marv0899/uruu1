<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SETTINGS/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Site Image","");
echo head_tag(getnick_sid($sid)."@Site Image",1,getnick_sid($sid));
$title="<b>Site Image</b>";
$main="<p align=".align().">";
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM smilies WHERE mood='1' AND id='".$id."'"));
$mood=mysql_fetch_array(mysql_query("SELECT code FROM smilies WHERE id='".$id."'"));
$res=mysql_query("UPDATE profiles SET image='".$mood[0]."' WHERE uid='".getuid_sid($sid)."'");
if(($res)&&($count[0]!=0)){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Site Mood Changed\n";}
else if($id==0){
mysql_query("UPDATE profiles SET image='' WHERE uid='".getuid_sid($sid)."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Site Mood Cleared\n";
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Database Error!\n";}
$main.="<br/>\n";
if($rid!=""){$main.="<br/><a href=\"../chat/chat.php?sid=$sid$chatlink\">Back To $rname</a>\n";}
$main.="<br/>$fivekey<a $key5 href=\"../settings/settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Settings","");
echo head_tag(getnick_sid($sid)."@Settings",1,getnick_sid($sid));
$title="<b>Settings</b>";
$main="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM smilies WHERE mood='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if(use_tools(getuid_sid($sid))){
$sql="SELECT id, code, path, hidden FROM smilies WHERE mood='1' ORDER BY code LIMIT $limit_start, $items_per_page";
}else{
$sql="SELECT id, code, path, hidden FROM smilies WHERE mood='1' AND hidden='0' ORDER BY code LIMIT $limit_start, $items_per_page";
}
$items=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
if(use_tools(getuid_sid($sid))&&$item[3]==1){
$hidden="** ";
}else{
$hidden="";
}
$main.=$hidden."<a href=\"image.php?update=1&amp;id=$item[0]&amp;sid=$sid$chatlink\">$item[1]</a> 
&#187;<img src=\"../$item[2]\" alt=\"$item[1]\"/><br/>\n";
}
$main.="<a href=\"./image.php?update=1&amp;id=0&amp;sid=$sid$chatlink\">Disable Site Image</a><br/><br/>\n";
if($page>1){
$main.="<br/><a href=\"./image.php?page=".($page-1)."&amp;sid=$sid$chatlink\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./image.php?page=".($page+1)."&amp;sid=$sid$chatlink\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("image","","",$sid);}
}else{
$main.="No Site Images Atm...\n</p>\n";
}
$main.="<p align=".align().">\n";
if($rid!=""){$main.="<a href=\"../chat/chat.php?sid=$sid$chatlink\">Back To $rname</a><br/>\n";}
$main.="$fivekey<a $key5 href=\"../settings/settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>