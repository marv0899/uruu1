<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SMILEYS/////////////////////////

if($id!=""&&$delete!=1)
{
addonline(getuid_sid($sid),"Smiley Options","");
echo head_tag(getnick_sid($sid)."@Smiley Options",1,getnick_sid($sid));
$title="<b>Smiley Options</b>";
$main="<p align=".align().">";
$res=mysql_query("UPDATE users SET images='".$id."' WHERE id='".getuid_sid($sid)."'");
if(($res)&&($id==1)){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Smileys Are Now Enabled\n";}
else if(($res)&&($id==0)){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Smileys Are Now Disabled\n";}
else{$main.="<img src=\"../images/error.gif\" alt=\"o\"/><br/>Database error!\n";}
$main.="<br/>
<br/>$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Deleting Smiley","");
echo head_tag(getnick_sid($sid)."@Deleting Smiley",1,getnick_sid($sid));
$title="<b>Deleting Smiley</b>";
$main="<p align=".align().">";
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
$smiley=mysql_fetch_array(mysql_query("SELECT path FROM smilies WHERE id='".$id."'"));
$smiley=explode("smilies/",$smiley[0]);
if($level>4){
$res=mysql_query("DELETE FROM smilies WHERE id='".$id."'");
if($res && unlink("$smiley[1]")){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/><br/>$smiley[1] Was Deleted Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Error Deleting $smiley[1]\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
if($rid!=""){$main.="<br/><a href=\"../chat/chat.php?sid=$sid$chatlink\">Back To $rname</a>\n";}
$main.="<br/>$fivekey<a $key5 href=\"./smilies.php?sid=$sid$chatlink\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Smilies List","");
echo head_tag(getnick_sid($sid)."@Smilies List",1,getnick_sid($sid));
$title="<b>Smilies List</b>";
if($newest==1){$title="<b>Newest Smilies</b>";}
$main="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM smilies WHERE hidden='0'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$order="ORDER BY code";
if(use_tools(getuid_sid($sid))){
$sql="SELECT * FROM smilies $order LIMIT $limit_start, $items_per_page";
}else{
$sql="SELECT * FROM smilies WHERE hidden='0' $order LIMIT $limit_start, $items_per_page";
}
$items=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
if(use_tools(getuid_sid($sid))&&$item[hidden]==1){
$hidden="** ";
}else{
$hidden="";
}
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
$main.=$hidden.$item["code"]."\n&#187;<img src=\"../$item[path]\" alt=\"$item[code]\"/>";
if($level[0]>4){
$main.="<a href=\"./smilies.php?delete=1&amp;id=$item[id]&amp;sid=$sid$chatlink\"><img src=\"../images/error.gif\" alt=\"[Delete]\"/></a>";
}
$main.="<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./smilies.php?page=".($page-1)."&amp;sid=$sid$chatlink\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./smilies.php?page=".($page+1)."&amp;sid=$sid$chatlink\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("smilies","rid","$rid",$sid);}
}else{
$main.="No Smileys Atm...\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>