<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////FIND FRIENDS/////////////////////////

if($find==1)
{
addonline(getuid_sid($sid),"Find Friends","");
echo head_tag(getnick_sid($sid)."@Find Friends",1,getnick_sid($sid));
$title="<b>Find Friends</b>";
$main="<p align=".align().">";
if($name!=""){$part1="a.username LIKE '%".$name."%'";$and="AND";}
if($sex!="B"){$part2="$and b.sex = '".$sex."'";$and="AND";}
else if($sex=="B"){$part2="$and b.sex != ''";$and="AND";}
if($location!=""){$part3="$and b.location LIKE '%".$location."%'";$and="AND";}
if($age!=1){
if($age==2){
$min=date('Y-m-d',strtotime('-14 years'));
$max=date('Y-m-d',strtotime('-19 years'));
}
else if($age==3){
$min=date('Y-m-d',strtotime('-19 years'));
$max=date('Y-m-d',strtotime('-26 years'));
}
else if($age==4){
$min=date('Y-m-d',strtotime('-26 years'));
$max=date('Y-m-d',strtotime('-35 years'));
}
else if($age==5){
$min=date('Y-m-d',strtotime('-35 years'));
$max=date('Y-m-d',strtotime('-50 years'));
}
else if($age==6){
$min=date('Y-m-d',strtotime('-50 years'));
$max=date('Y-m-d',strtotime('-101 years'));
}
$part4="$and b.birthday < '".$min."' AND b.birthday > '".$max."'";
}
if($page==""||$page<1)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE $part1$part2$part3$part4"));
$num_items=$noi[0];
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT a.id, a.username, b.sex, b.birthday, b.location FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE $part1$part2$part3$part4 ORDER BY a.username LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
if($item[2]=="M"){$usersex="<img src=\"images/male.gif\" alt=\"(M)\"/>";}
else if($item[2]=="F"){$usersex="<img src=\"images/female.gif\" alt=\"(F)\"/>";}
else{$usersex="";}
$main.="$usersex<a href=\"./profile.php?who=$item[0]&amp;sid=$sid\">$item[1](".getage($item[3])."/$item[2]/".getbbcode($item[4],$sid,1).")</a><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"findfriends.php?find=1&amp;page=".($page-1)."&amp;sid=$sid&amp;name=$name&amp;age=$age&amp;sex=$sex&amp;location=$location\">&#139;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"findfriends.php?find=1&amp;page=".($page+1)."&amp;sid=$sid&amp;name=$name&amp;age=$age&amp;sex=$sex&amp;location=$location\">Next-&#155;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
}else{
$main.="Results Turned Up Nothing<br/>
<br/>
$fivekey<a $key5 href=\"./findfriends.php?sid=$sid\">Back</a>
</p>\n";
}
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Find Friends","");
$nick=getnick_sid($sid);
echo head_tag($nick."@Find Friends",1,$nick);
$title="<b>Find Friends</b>";
$main="<div class=".align().">
<form action=\"./findfriends.php?find=1&amp;sid=$sid\" method=\"post\">
<b>Username:</b><br/>
<input name=\"name\" maxlength=\"12\"/><br/>
<b>Age:</b><br/>
<select name=\"age\">
<option value=\"1\">All</option>
<option value=\"2\">14-18</option>
<option value=\"3\">19-25</option>
<option value=\"4\">26-34</option>
<option value=\"5\">35-49</option>
<option value=\"6\">50+</option>
</select><br/>
<b>Sex:</b><br/>
<select name=\"sex\">
<option value=\"B\">Both</option>
<option value=\"M\">Male</option>
<option value=\"F\">Female</option>
</select><br/>
<b>Location:</b><br/>
<input name=\"location\" maxlength=\"50\"/><br/>
<input type=\"submit\" value=\"Search\"/>
</form>
</div>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>