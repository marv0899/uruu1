<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////EDIT CATEGORY/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Updating Gallery","");
echo head_tag(getnick_sid($sid)."@Updating Gallery",1,getnick_sid($sid));
$title="<b>Updating Gallery</b>";
$main="<p align=".align().">\n";
if(gallery_tools(getuid_sid($sid))){
$res=mysql_query("UPDATE gallery_categories SET name='".$name."' WHERE id='".$id."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>$name Was Updated Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Error Updating Category\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Updating Gallery","");
echo head_tag(getnick_sid($sid)."@Deleting Category",1,getnick_sid($sid));
$title="<b>Deleting Category</b>";
$main="<p align=".align().">\n";
if(gallery_tools(getuid_sid($sid))){
$res=mysql_query("DELETE FROM gallery_categories WHERE id='".$id."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Category Was Deleted Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Error Deleting Category\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Updating Gallery","");
echo head_tag(getnick_sid($sid)."@Edit Category",1,getnick_sid($sid));
$title="<b><i>Edit Category</i></b>";
if(gallery_tools(getuid_sid($sid))){
$category=mysql_fetch_array(mysql_query("SELECT id, name, active FROM gallery_categories WHERE id='".$id."'"));
$main="<div class=".align().">
<form action=\"./edit.php?update=1&amp;id=$id&amp;sid=$sid\" method=\"post\">
<b>Name:</b><br/>
<input name=\"name\" maxlength=\"100\" value=\"$category[1]\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>
<p align=".align().">
<a href=\"./edit.php?delete=1&amp;id=$id&amp;sid=$sid\">Delete Category $category[1]</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!
</p>\n";
exit;
}
$main.="<p align=".align().">
$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>