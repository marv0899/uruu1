<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////////UPLOAD/////////////////////////////

addonline(getuid_sid($sid),"Upload Pics","");
echo head_tag(getnick_sid($sid)."@Upload Pics",1,getnick_sid($sid));
$title="<u><i><b>Upload Pics</b></i></u><br/>";	
$main="<p align=".align().">
Here you can upload your pics.<br/>
If ur browser dnt support uploading u can email your pics to:<br/>
<b>".email(gallery)."</b><br/>\n";
$size_bytes=1048576;
$main.="Max <b>".round($size_bytes/1048576,1)."</b> Mb
</p>
<div class=".align().">
<form method=\"post\" enctype=\"multipart/form-data\" action=\"./upload.php?upload=yes&amp;sid=$sid\">
<b>Category:</b><br/>
<select name=\"cat\">\n";
$items=mysql_query("SELECT id, name FROM gallery_categories");
while($item=mysql_fetch_array($items)){
$main.="<option value=\"".$item[0]."\">$item[1]</option>\n";
}
$main.="</select><br/>
<b>File:</b><br/>
<input type=\"file\" name=\"filetoupload\"/><br/>\n";
if(gallery_tools(getuid_sid($sid))){
$main.="<b>Username:</b><br/>
<small>(leave blank to use your own username.)</small><br/>
<input type=\"text\" name=\"username\" maxlength=\"12\" size=\"12\"/><br/>\n";
}
$main.="<input type=\"submit\" name=\"uploadform\" value=\"Upload\"/>
</form>
</div>
<p align=".align().">\n";
$extlimit="yes";
$limitedext=array(".jpg",".jpeg",".gif",".png");
$ext=strtolower(strrchr($_FILES['filetoupload'][name],'.'));
$file_type=$_FILES['filetoupload']['type'];
$file_name=$_FILES['filetoupload']['name'];
$file_size=$_FILES['filetoupload']['size'];
$file_tmp=$_FILES['filetoupload']['tmp_name'];
if($upload=="yes"){
if(!is_uploaded_file($_FILES['filetoupload']['tmp_name'])){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>No file selected!<br/>\n";
}
else if($extlimit=="yes" && !in_array($ext,$limitedext)){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Invalid file type!<br/>\n";
}
else if($file_size>$size_bytes){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Exceeded File size limit! Maximum <b>$kb</b> Kb.<br/>\n";
}
else if(file_exists("./$file_name")){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Filename already exists!<br/>\n";
}
else if(file_exists("./".getnick_sid($sid)."(5)".$ext)){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/><b>Error!!!</b><br/>5 pics hav already been uploaded...<br/>\n";
}
else if($file_size){
$file_name2=str_replace(" ","",$file_name);
if(isuser(getuid_nick($username))){$uid=getuid_nick($username);}
else{$uid=getuid_sid($sid);}
$pic=getnick_uid($uid)."(1)";
if(file_exists("./".getnick_uid($uid)."(1)$ext")){$pic=getnick_uid($uid)."(2)";}
if(file_exists("./".getnick_uid($uid)."(2)$ext")){$pic=getnick_uid($uid)."(3)";}
if(file_exists("./".getnick_uid($uid)."(3)$ext")){$pic=getnick_uid($uid)."(4)";}
if(file_exists("./".getnick_uid($uid)."(4)$ext")){$pic=getnick_uid($uid)."(5)";}
mysql_query("INSERT INTO gallery_files SET uid='".$uid."', filename='".$pic.$ext."', path='http://".$_SERVER['SERVER_NAME']."/gallery/".$pic.$ext."', category='".$cat."', date='".time()."'"); 
move_uploaded_file($file_tmp, "./$pic$ext");
$main.="$file_name2<br/>
successfully uploaded!<br/>\n";
}
else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Unknown error! Pls try again...<br/>\n";
}
}
$main.="$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Home</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>