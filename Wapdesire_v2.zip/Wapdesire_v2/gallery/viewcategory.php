<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW CATEGORY/////////////////////////

addonline(getuid_sid($sid),"Gallery","");
echo head_tag(getnick_sid($sid)."@Gallery",1,getnick_sid($sid));
$title="<b><i>Gallery</i></b>";
$main="<p align=".align().">
Welcome To $sitename Gallery<br/>\n";
$active=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM gallery_categories WHERE id='".$id."' AND active='0'"));
if($active[0]==1){
$main.="<p align=".align().">This Category Is Currently Disabled.</p>\n";
$main.="<p align=".align().">$fivekey<a $key5 href=\"./downloads.php?sid=$sid\">Back</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM gallery_files WHERE category='".$id."'"));
if($num_items[0]==0)$num_items[0]=0;
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items[0]==0)$limit_start=0;
$sql="SELECT id, uid, filename, path, hits FROM gallery_files WHERE category='".$id."' ORDER BY filename LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items))
{
$file=explode("gallery/",$item[3]);
if(filesize($file[1])>1048575){
$size=round(filesize($file[1])/1048576,1)." Mb";
}else if(filesize($file[1])>1023){
$size=round(filesize($file[1])/1024,1)." Kb";
}else{
$size=filesize($file[1])." Bytes";
}
$filename=explode(".",$item[2]);
$nick=explode("(",$item[2]);
$main.="<img src=\"../phpThumb/phpThumb.php?src=../gallery/$item[2]&amp;w=150&amp;f=".getext($file[1])."&amp;sia=".getnick_uid($item[1])."\" alt=\"$item[2]\"/>
<br/><a href=\"./get.php?id=$item[0]&amp;sid=$sid\">$filename[0].".getext($file[1])."</a> $size\n";
if(gallery_tools(getuid_sid($sid))||getnick_sid($sid)==$nick[0]){
$main.=" <a href=\"./delete.php?id=$item[0]&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[delete]\"/></a>";
}
$main.="<br/>
<small>$item[4] Downloads<br/></small><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./viewcategory.php?id=$id&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./viewcategory.php?id=$id&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("viewcategory","id","$id",$sid);}
}else{
$main.="<br/>There Are No Gallery Pics Atm...
</p>\n";
}
$main.="<p align=".align().">$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>