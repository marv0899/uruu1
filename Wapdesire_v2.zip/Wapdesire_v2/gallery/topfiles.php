<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////TOP PICS/////////////////////////

addonline(getuid_sid($sid),"Top Pics","");
echo head_tag(getnick_sid($sid)."@Top Pics",1,getnick_sid($sid));
$title="<b><i>Top Pics</i></b>";
$main="<p align=".align().">
Welcome To $sitename Gallery<br/>
Here Are The Top 20 Downloaded Pics<br/>\n";
$active=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM gallery_files WHERE hits>'0'"));
if($active[0]==0){
$main.="<p align=".align().">No Pics Hav Been Downloaded Yet.</p>\n";
$main.="<p align=".align().">$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$sql="SELECT id, filename, path, hits FROM gallery_files WHERE hits>'0' ORDER BY hits DESC LIMIT 20";
$items=mysql_query($sql);
$main.=mysql_error();
while($item=mysql_fetch_array($items))
{
$file=explode("gallery/",$item[2]);
if(filesize($file[1])>1048575){
$size=round(filesize($file[1])/1048576,1)." Mb";
}else if(filesize($file[1])>1023){
$size=round(filesize($file[1])/1024,1)." Kb";
}else{
$size=filesize($file[1])." Bytes";
}
$main.="<br/><a href=\"./get.php?id=$item[0]&amp;sid=$sid\">$item[1]</a> $size<br/>
<small>$item[3] Downloads</small><br/>\n";
}
$main.="<p align=".align().">$fivekey<a $key5 href=\"./gallery.php?sid=$sid\">Back</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>