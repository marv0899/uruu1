<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VALIDATE LIST/TOOL/////////////////////////

if($validate==1)
{
addonline(getuid_sid($sid),"Validating User","");
echo head_tag(getnick_sid($sid)."@Validating User",1,getnick_sid($sid));
$title="<b>Validate User</b>";
$main="<p align=".align().">\n";
if(validate(getuid_sid($sid))){
$res=mysql_query("Update users SET validated='1' WHERE id='".$who."'");
if($res){
mysql_query("INSERT INTO logs SET action='validated', details='<b>".getnick_uid(getuid_sid($sid))."</b> validated ".getnick_uid(($who))."', date='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>".getnick_uid($who)." validated successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error validating ".getnick_uid($who)."\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="<br/>
<br/><a href=\"../profile.php?who=$who&amp;sid=$sid\">".getnick_uid($who)." Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Validation List","");
echo head_tag(getnick_sid($sid)."@Validation List",1,getnick_sid($sid));
$title="<b>Users Awaiting Validation</b>";
$main="<p align=".align().">\n";
if(validate(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE validated='0'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page= $num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT a.id, a.username, b.birthday, b.sex, b.location 
FROM users a INNER JOIN profiles b ON a.id = b.uid 
WHERE validated='0' ORDER BY a.regdate DESC 
LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
if($item[3]=='M'){$usex="Male";}
else if($item[3]=='F'){$usex="Female";}
else{$usex="Argh! No Profile!";}
if($item[3]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";}
else if($item[3]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";}
else{$usersex="";}
$main.="$usersex<a href=\"../profile.php?who=$item[0]&amp;sid=$sid\">$item[1](".getage($item[2])."/$usex/".getbbcode($item[4],$sid,1).")</a><br/>\n";
}
}
if($page>1){
$main.="<br/><a href=\"./validate.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./validate.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("validate","","",$sid);}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>