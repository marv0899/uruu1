<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////LOGS/////////////////////////

if($logs==1)
{
addonline(getuid_sid($sid),"Viewing Logs","");
echo head_tag(getnick_sid($sid)."@Logs",1,getnick_sid($sid));
$title="<b>Logs</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs WHERE action='".$act."'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT date, details FROM logs WHERE action='".$act."' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$query=mysql_query($sql);
if($noi[0]>0){
while($array=mysql_fetch_array($query)){
$main.=$array[1]."(".date("H:i - D jS M y", $array[0]).")<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"logs.php?logs=1&amp;page=".($page-1)."&amp;act=$act&amp;sid=$sid\">&#171;-Prev</a> ";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"logs.php?logs=1&amp;page=".($page+1)."&amp;act=$act&amp;sid=$sid\">Next-&#187;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
}else{
$main.="No Logs Atm...\n</p>\n";
}
if($num_pages>2){$main.=getjumper("logs","logs",1,$sid);}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><b>Permission Denied!</b>\n</p>\n";
}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Viewing Logs","");
echo head_tag(getnick_sid($sid)."@Reports/Logs",1,getnick_sid($sid));
$title="<b>Reports/Logs</b>";
$main="<p align=".align().">";
if(use_tools(getuid_sid($sid))){
$main.="<b>Reports</b><br/>";
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE reported='1'"));
$count=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?inbox=1&amp;sid=$sid\">Inbox Messages $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM popups WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?popup=1&amp;sid=$sid\">Popup Messages $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?post=1&amp;sid=$sid\">Posts $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?topic=1&amp;sid=$sid\">Topics $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?blog=1&amp;sid=$sid\">Blogs $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?wapsite=1&amp;sid=$sid\">Wapsites $row[0]</a><br/>\n";
}
if($count==0){$main.="No Reports Atm...<br/>\n";}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs"));
if($row[0]>0){
$main.="<br/><b>Logs</b><br/>\n";
$query=mysql_query("SELECT DISTINCT (action)FROM logs ORDER BY date DESC");
while($array=mysql_fetch_array($query)){
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs WHERE action='".$array[0]."'"));
$main.="<a href=\"./logs.php?logs=1&amp;act=$array[0]&amp;sid=$sid\">$array[0] $row[0]</a><br/>\n";
}
}else{
$main.="<br/>No Logs Atm...\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>