<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ADD GROUP/////////////////////////

if($add==1){
addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
if(editusers(getuid_sid($sid))){
if($type==Forum){
$typeid=fid;
$id=$fid;
$other=rid;
}else if($type==Chatroom){
$typeid=rid;
$id=$rid;
$other=fid;
}else if($type==Club){
$typeid=clubid;
$id=$clubid;
$other=$typeid;
$fid=mysql_fetch_array(mysql_query("SELECT id FROM forums WHERE clubid='".$id."'"));
$rid=mysql_fetch_array(mysql_query("SELECT id FROM chatrooms WHERE clubid='".$id."'"));
}
$count_other=mysql_query("SELECT * FROM modtools WHERE $other='".$id."' AND uid='".$who."'");
if(!empty($id)){
if(mysql_num_rows($count_other)>0){
if($type==Club){
$res=mysql_query("UPDATE modtools SET fid='".$fid[0]."', rid='".$rid[0]."' WHERE $other='".$id."' AND uid='".$who."'");
}else{
$res=mysql_query("UPDATE modtools SET $typeid='".$id."' WHERE $other='".$id."' AND uid='".$who."'");
}
}else{
if($type==Club){
$res=mysql_query("INSERT INTO modtools SET uid='".$who."', fid='".$fid[0]."', rid='".$rid[0]."', $typeid='".$id."'");
}else{
$res=mysql_query("INSERT INTO modtools SET uid='".$who."', $typeid='".$id."'");
}
}
if($res){
echo mysql_error();
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>$type Added Successfully<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Adding $type<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Adding $type<br/>\n";
}
$main.="<br/>
$fivekey<a $key5 href=\"./modtools.php?who=$who&amp;type=$type&amp;sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?sid=$sid\">Back</a>
</p>\n";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
if(editusers(getuid_sid($sid))){
if($type==Forum){
$typeid=fid;
$other=rid;
}else if($type==Chatroom){
$typeid=rid;
$other=fid;
}
if(!empty($id)){
$count_other=mysql_fetch_array(mysql_query("SELECT * FROM modtools WHERE id='".$id."'"));
if($count_other[$other]!=0&&$type!=Club){
$res=mysql_query("UPDATE modtools SET $typeid='0' WHERE id='".$id."'");
}else{
$res=mysql_query("DELETE FROM modtools WHERE id='".$id."'");
}
if($res){
echo mysql_error();
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>$type Removed Successfully<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Removing $type<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Removing $type<br/>\n";
}
$main.="<br/>
$fivekey<a $key5 href=\"./modtools.php?who=$who&amp;type=$type&amp;sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?sid=$sid\">Back</a>
</p>\n";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
if(editusers(getuid_sid($sid))){
if(!isuser($who)){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error User Does Not Exist!<br/>
<br/>
$fivekey<a $key5 href=\"./moderate.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
$main.="<b>$type(s) To Moderate</b>
</p>\n";
if($type==Forum)$typeid=fid;
else if($type==Chatroom)$typeid=rid;
else if($type==Club)$typeid=clubid;
$modtools2=mysql_query("SELECT $typeid FROM modtools WHERE uid='".$who."'");
while($modtools=mysql_fetch_array($modtools2)){$item[]=$modtools[0];}
if($type==Forum)$query=mysql_query("SELECT * FROM forums ORDER BY  name, id");
else if($type==Chatroom)$query=mysql_query("SELECT * FROM chatrooms ORDER BY  name, id");
else if($type==Club)$query=mysql_query("SELECT * FROM clubs ORDER BY  name, id");
if(mysql_num_rows($query)>0){
$main.="<div class=".align().">
<form action=\"./modtools.php?add=1&amp;sid=$sid\" method=\"post\">\n";
$main.="<b>".$type."s:</b><br/>
<select name=\"$typeid\">\n";
while($array=mysql_fetch_array($query)){
if(empty($item))$item[0]=0;
if(!in_array($array[id],$item)&&$array[clubid]==0){
$main.="<option value=\"$array[id]\">$array[name]</option>\n";
}
}
$main.="</select><br/>
<input type=\"hidden\" name=\"type\" value=\"$type\"/>
<input type=\"hidden\" name=\"who\" value=\"$who\"/>
<input type=\"submit\" value=\"Add $type\">
</form>
</div>\n";
}else{
$main.="<p align=".align().">
<b>No ".$type."s To Moderate</b>
</p>\n";
}
$other="";
if($type!=Club)$other=" AND clubid='0'";
$query=mysql_query("SELECT * FROM modtools WHERE uid='".$who."' AND $typeid>'0'$other");
$main.="<p align=".align().">\n";
if(mysql_num_rows($query)>0){
$main.="<b>Moderated ".$type."s:</b><br/>\n";
while($array=mysql_fetch_array($query)){
if($type==Forum)$row=mysql_fetch_array(mysql_query("SELECT * FROM forums WHERE id='".$array[fid]."' AND clubid='0'"));
else if($type==Chatroom)$row=mysql_fetch_array(mysql_query("SELECT * FROM chatrooms WHERE id='".$array[rid]."' AND clubid='0'"));
else if($type==Club)$row=mysql_fetch_array(mysql_query("SELECT * FROM clubs WHERE id='".$array[clubid]."'"));
$main.=$row[name]."
<a href=\"./modtools.php?delete=1&amp;id=$array[id]&amp;who=$who&amp;type=$type&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[x]\"/></a><br/>\n";
}
}else{
$main.="No ".$type."s Added Yet!!!<br/>\n";
}
$main.="<br/>
$fivekey<a $key5 href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>