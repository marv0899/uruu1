<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////EDIT CHATROOM/////////////////////////

addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
if($level[0]>=4){
$chatroom=mysql_fetch_array(mysql_query("SELECT * FROM chatrooms WHERE id='".$id."'"));
if($chatroom[censored]==0){$cnsrd=" selected=\"selected\"";}else{$cnsrd="";}
if($chatroom[freaky]==1){$freaky1=" selected=\"selected\"";}else{$freaky1="";}
if($chatroom[freaky]==2){$freaky2=" selected=\"selected\"";}else{$freaky2="";}
$main.="<b>Edit Chatroom</b>
</p>
<div class=".align().">
<form action=\"./addroom.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Chatroom:</b><br/>
<input name=\"name\" maxlength=\"30\" value=\"$chatroom[name]\"/><br/>
<b>Password:</b><br/>
<input name=\"password\" maxlength=\"10\" size=\"10\" value=\"$chatroom[password]\"/><br/>
<b>Censored:</b>
<select name=\"censored\">
<option value=\"1\">Yes</option>
<option value=\"0\"$cnsrd>No</option>
</select><br/>
<b>Fun:</b>
<select name=\"fun\">
<option value=\"0\">No</option>
<option value=\"1\"$freaky1>Reverse</option>
<option value=\"2\"$freaky2>Chat Bot</option>
</select><br/>
<input type=\"hidden\" name=\"id\" value=\"$id\"/>
<input type=\"submit\" value=\"Edit Chatroom\">
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>