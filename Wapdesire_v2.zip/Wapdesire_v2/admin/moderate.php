<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MODERATE USER/////////////////////////

if($edit==1)
{
addonline(getuid_sid($sid),"Editing User","");
echo head_tag(getnick_sid($sid)."@Edit User",1,getnick_sid($sid));
$title="<b>Edit ".getnick_uid($who)."</b>";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main="<p align=".align().">
<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Edit ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(editusers(getuid_sid($sid))){
$main="<p align=".align().">
<b>Edit Tools:</b><br/>
<br/>
<a href=\"./edituser.php?profile=1&amp;who=$who&amp;sid=$sid\">Profile</a><br/>
<a href=\"./edituser.php?admintools=1&amp;who=$who&amp;sid=$sid\">Admin Tools</a><br/>\n";
if($trgtperm[0]>0&&$trgtperm[0]!=3){
$main.="<a href=\"./modtools.php?type=Forum&amp;who=$who&amp;sid=$sid\">Mod Forums</a><br/>\n";
}
if($trgtperm[0]>=3){
$main.="<a href=\"./modtools.php?type=Chatroom&amp;who=$who&amp;sid=$sid\">Mod Chatrooms</a><br/>\n";
}
if(club_tools($who)){
$main.="<a href=\"./modtools.php?type=Club&amp;who=$who&amp;sid=$sid\">Mod Clubs</a><br/>\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">\n<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$main.="<br/>
<a href=\"./moderate.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Moderating User","");
echo head_tag(getnick_sid($sid)."@Moderate User",1,getnick_sid($sid));
$title="<b>Moderating ".getnick_uid($who)."</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
$noi=mysql_fetch_array(mysql_query("SELECT count(*) FROM users WHERE validated='0' AND id='".$who."'"));
if($noi[0]==1){
$main.="<a href=\"./validate.php?validate=1&amp;who=$who&amp;sid=$sid\">Validate</a><br/>\n";
}
if(boot(getuid_sid($sid))){
$main.="<a href=\"./boot.php?who=$who&amp;sid=$sid\">Boot</a><br/>\n";
}else{
$main.="Boot<br/>\n";
}
if(ban(getuid_sid($sid),$who)){
$main.="<a href=\"./ban.php?who=$who&amp;sid=$sid\">Ban</a><br/>\n";
}else if(!banned($who)){
$main.="Ban<br/>\n";
}
if(unban(getuid_sid($sid),$who)){
$main.="<a href=\"./unban.php?who=$who&amp;sid=$sid\">Unban</a><br/>\n";
}else if(banned($who)){
$main.="Unban<br/>\n";
}
/*
if(!isshield($who)){
$main.="<a href=\"ownrproc.php?action=shld&amp;sid=$sid&amp;who=$who\">Shield</a><br/>\n";
}else{
$main.="<a href=\"ownrproc.php?action=ushld&amp;sid=$sid&amp;who=$who\">Unshield</a><br/>\n";
}
*/
if(delete_user(getuid_sid($sid))){
$main.="<a href=\"./delete.php?who=$who&amp;sid=$sid\">Delete</a><br/>\n";
}else{
$main.="Delete<br/>\n";
}
if(editusers(getuid_sid($sid))){
$main.="<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Edit User</a></p>\n";
}else{
$main.="Edit User</p>\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><b>Permission Denied!</b>\n</p>\n";
}
$main.="<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>