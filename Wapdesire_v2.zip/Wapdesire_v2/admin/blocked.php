<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////BLOCK TOOLS/////////////////////////

if($block==1)
{
addonline(getuid_sid($sid),"Blocking ".$type."s","");
echo head_tag(getnick_sid($sid)."@Blocking ".$type."s",1,getnick_sid($sid));
$title="<b>Blocking ".$type."s</b>";
$main="<p align=".align().">\n";
if(ipban(getuid_sid($sid),getuid_sid($sid))){
if($save==1){
if($type=="site"){$arpt=", autoreport='".$autoreport."'";}
else{$arpt="";}
$res=mysql_query("INSERT INTO blocked SET $type='".$body."'$arpt");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Blocked Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Cannot Block\n";
}
$main.="<br/>
<br/><a href=\"./blocked.php?type=$type&amp;sid=$sid\">Back</a>
</p>\n";
}else{
$main="<div class=".align().">
<form action=\"./blocked.php?block=1&amp;save=1&amp;sid=$sid\" method=\"post\">
<b>$type:</b><br/>
<input name=\"body\" maxlength=\"100\"/><br/>\n";
if($type=="site"){
$main.="<b>Option:</b><br/>
<select name=\"autoreport\">
<option value=\"0\">Auto Ban Only</option>
<option value=\"1\">Auto Report Only</option>
<option value=\"2\">Auto Ban &amp; Report</option>
</select><br/>\n";
}
$main.="<input type=\"hidden\" name=\"type\" value=\"$type\"/>
<input type=\"submit\" value=\"Block\"/>
</form>
</div>\n";
$main.="<p align=".align().">
<a href=\"./blocked.php?type=$type&amp;sid=$sid\">Back</a>
</p>\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Deleting Blocked ".$type."s","");
echo head_tag(getnick_sid($sid)."@Deleting Blocked ".$type."s",1,getnick_sid($sid));
$title="<b>Deleting Blocked ".$type."s</b>";
$main="<p align=".align().">\n";
if(ipban(getuid_sid($sid),getuid_sid($sid))){
$res=mysql_query("DELETE FROM blocked WHERE id='".$id."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Deleted Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Cannot Delete\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="<br/>
<br/><a href=\"./blocked.php?type=$type&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Blocked ".$type."s","");
echo head_tag(getnick_sid($sid)."@Blocked ".$type."s",1,getnick_sid($sid));
$title="<b>Blocked ".$type."s</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
$sql="SELECT * FROM blocked WHERE $type!='NULL' AND (autoreport='0' OR autoreport='2') ORDER BY $type ASC";
$query=mysql_query($sql);
if($type!="site")$msg="Blocked";
else$msg="Auto Banned";
if(mysql_num_rows($query)>0){
$main.="<b>$msg ".$type."s</b><br/>\n";
while($row=mysql_fetch_array($query)){
$main.="<br/>
$row[$type]\n";
if(ipban(getuid_sid($sid),getuid_sid($sid))){
$main.="<a href=\"./blocked.php?delete=1&amp;type=$type&amp;id=$row[id]&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[Delete]\"/></a>\n";
}
}
}else{
$main.="No $msg ".$type."s\n";
}
if($type=="site"){
$main.="</p>
<p align=".align().">\n";
$sql="SELECT * FROM blocked WHERE $type!='NULL' AND autoreport>'0' ORDER BY $type ASC";
$query=mysql_query($sql);
if(mysql_num_rows($query)>0){
$main.="<b>Auto Reported ".$type."s</b><br/>\n";
while($row=mysql_fetch_array($query)){
$main.="<br/>
$row[$type]\n";
if(ipban(getuid_sid($sid),getuid_sid($sid))){
$main.="<a href=\"./blocked.php?delete=1&amp;type=$type&amp;id=$row[id]&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[Delete]\"/></a>\n";
}
}
}else{
$main.="No Auto Reported ".$type."s\n";
}
}
$main.="<br/>
<br/>
<a href=\"./blocked.php?block=1&amp;type=$type&amp;sid=$sid\">Block $type</a><br/>
<a href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>