<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////BANNED LIST/////////////////////////

addonline(getuid_sid($sid),"Banned List","");
echo head_tag(getnick_sid($sid)."@Banned List",1,getnick_sid($sid));
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM banned WHERE penalty>='0'"));
$title="<b>$num_items[0] Banned Users</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page= $num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT uid, byid, penalty, reason, remaining 
FROM banned WHERE penalty>='0' ORDER BY 
remaining LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[0]."'"));
if($sex[0]=="M"){$color="#0000FF";}else if($sex[0]=="F"){$color="#FF0066";}
$sex2=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[1]."'"));
if($sex2[0]=="M"){$color2="#0000FF";}else if($sex2[0]=="F"){$color2="#FF0066";}
if($item[2]==0){$bt="Shoutbox-Banned";}
else if($item[2]==1){$bt="Forum-Banned";}
else if($item[2]==2){$bt="Chat-Banned";}
else if($item[2]==3){$bt="Site-Banned";}
else if($item[2]==4){$bt="Ip-Banned";}
$main.="<a href=\"../profile.php?who=$item[1]&amp;sid=$sid\" style=\"color:$color2\">".getnick_uid($item[1])."</a>
$bt 
<a href=\"../profile.php?who=$item[0]&amp;sid=$sid\" style=\"color:$color\">".getnick_uid($item[0])."</a><br/>
".getbbcode($item[3],$sid,1)."<br/>
<small>".time_msg($item[4]-time(),0)."</small><br/>\n";
}
}
if($page>1){
$main.="<br/><a href=\"./banned.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./banned.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("banned","","",$sid);}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>