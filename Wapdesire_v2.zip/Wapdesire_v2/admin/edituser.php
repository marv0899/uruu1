<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////EDIT USER/////////////////////////

if($edit==1)
{
addonline(getuid_sid($sid),"Editing User","");
echo head_tag(getnick_sid($sid)."@Editing User",1,getnick_sid($sid));
$title="<b>Editing User</b>";
$main="<p align=".align().">\n";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main.="<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Delete ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(editusers(getuid_sid($sid))){
if($type==admintools){
$res="true";
$res2="true";
}else{
$res=mysql_query("UPDATE profiles SET picture='".$propic."', email='".$email."', birthday='".$ubday."', location='".$location."', moreinfo='".$moreinfo."', sex='".$sex."', status='".$status."' WHERE uid='".$who."'");
$res2=mysql_query("UPDATE users SET username='".$name."', level='".$level."' WHERE id='".$who."'");
}
if($type==admintools){
$count_who=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM admintools WHERE uid='".$who."'"));
if($count_who[0]==1){
$res3=mysql_query("UPDATE admintools SET tools='".$tools."', boot='".$boot."', ban='".$ban."', 
unban='".$unban."', ipban='".$ipban."', del='".$delete."', validate='".$validate."', delshout='".$delshout."', 
userinfo='".$userinfo."', settings='".$settings."', ghosts='".$ghosts."', chat_tools='".$chat_tools."', 
forum_tools='".$forum_tools."', club_tools='".$club_tools."', quiz_tools='".$quiz_tools."', game_tools='".$game_tools."', 
download_tools='".$download_tools."', editusers='".$editusers."', link_tools='".$link_tools."', 
gallery_tools='".$gallery_tools."' WHERE uid='".$who."'");
}else{
$res3=mysql_query("INSERT INTO admintools SET uid='".$who."', tools='".$tools."', boot='".$boot."', ban='".$ban."', 
unban='".$unban."', ipban='".$ipban."', del='".$delete."', validate='".$validate."', delshout='".$delshout."', 
userinfo='".$userinfo."', settings='".$settings."', ghosts='".$ghosts."', chat_tools='".$chat_tools."', 
forum_tools='".$forum_tools."', club_tools='".$club_tools."', quiz_tools='".$quiz_tools."', 
game_tools='".$game_tools."', download_tools='".$download_tools."', editusers='".$editusers."', 
link_tools='".$link_tools."', gallery_tools='".$gallery_tools."'");
}
}else{
$res3="true";
}
if($res&&$res2&&$res3){
mysql_query("INSERT INTO logs SET action='edited', details='<b>".getnick_uid(getuid_sid($sid))."</b> edited ".getnick_uid($who)."', date='".time()."'");
if($type==admintools&&$tools==0){mysql_query("DELETE FROM admintools WHERE uid='".$who."'");}
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>".getnick_uid($who)." Was Edited Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error updating ".getnick_uid($who)."\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>
<p align=".align().">
<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($profile==1)
{
addonline(getuid_sid($sid),"Editing User","");
echo head_tag(getnick_sid($sid)."@Edit User",1,getnick_sid($sid));
$title="<b>Edit ".getnick_uid($who)."</b>";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main="<p align=".align().">
<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Edit ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(editusers(getuid_sid($sid))){
$name=mysql_fetch_array(mysql_query("SELECT username FROM users WHERE id='".$who."'"));
$lvl=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
$avat=mysql_fetch_array(mysql_query("SELECT picture FROM profiles WHERE uid='".$who."'"));
$email=mysql_fetch_array(mysql_query("SELECT email FROM profiles WHERE uid='".$who."'"));
$bdy=mysql_fetch_array(mysql_query("SELECT birthday FROM profiles WHERE uid='".$who."'"));
$uloc=mysql_fetch_array(mysql_query("SELECT location FROM profiles WHERE uid='".$who."'"));
$usig=mysql_fetch_array(mysql_query("SELECT moreinfo FROM profiles WHERE uid='".$who."'"));
$sx=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$who."'"));
$status=mysql_fetch_array(mysql_query("SELECT status FROM profiles WHERE uid='".$who."'"));
if($sx[0]=="F"){$selected=" selected=\"selected\"";}else{$selected="";}
if($lvl[0]==1){$mod=" selected=\"selected\"";}else{$mod="";}
if($lvl[0]==2){$fadmn=" selected=\"selected\"";}else{$fadmn="";}
if($lvl[0]==3){$cadmn=" selected=\"selected\"";}else{$cadmn="";}
if($lvl[0]==4){$hadmn=" selected=\"selected\"";}else{$hadmn="";}
if($lvl[0]==5){$ownr=" selected=\"selected\"";}else{$ownr="";}
$main="<div class=".align().">
<form action=\"./edituser.php?edit=1&amp;sid=$sid\" method=\"post\">
Username: <input name=\"name\" maxlength=\"100\" value=\"$name[0]\"/><br/>
Profile Pic: <input name=\"propic\" maxlength=\"100\" value=\"$avat[0]\"/><br/>
E-Mail: <input name=\"email\" maxlength=\"100\" value=\"$email[0]\"/><br/>
Birthday(YYYY-MM-DD): <input name=\"ubday\" maxlength=\"50\" value=\"$bdy[0]\"/><br/>
Location: <input name=\"location\" maxlength=\"50\" value=\"".htmlspecialchars($uloc[0])."\"/><br/>
Info: <input name=\"moreinfo\" maxlength=\"100\" value=\"$usig[0]\"/><br/>
Sex: <select name=\"sex\">
<option value=\"M\">Male</option>
<option value=\"F\"$selected>Female</option>
</select><br/>
Level: <select name=\"level\">
<option value=\"0\">Member</option>
<option value=\"1\"$mod>Moderator</option>
<option value=\"2\"$fadmn>Forum Administrator</option>
<option value=\"3\"$cadmn>Chat Administrator</option>
<option value=\"4\"$hadmn>Head Administrator</option>
<option value=\"5\"$ownr>Owner</option>
</select><br/>
Status: <input name=\"status\" maxlength=\"50\" value=\"$status[0]\"/><br/>
<input type=\"hidden\" name=\"who\" value=\"$who\"/>
<input type=\"hidden\" name=\"type\" value=\"profile\"/>
<input type=\"submit\" value=\"Update\"/>
</form>
</div>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">\n<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$main.="<p align=".align().">
<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($admintools==1)
{
addonline(getuid_sid($sid),"Editing User","");
echo head_tag(getnick_sid($sid)."@Edit User",1,getnick_sid($sid));
$title="<b>Edit ".getnick_uid($who)."</b>";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main="<p align=".align().">
<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Edit ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(editusers(getuid_sid($sid))){
$count_who=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM admintools WHERE uid='".$who."'"));
$tools=mysql_fetch_array(mysql_query("SELECT tools, boot, ban, unban, ipban, del, validate, delshout, 
userinfo, settings, ghosts, chat_tools, forum_tools, club_tools, quiz_tools, game_tools, gallery_tools, editusers, download_tools, link_tools FROM admintools WHERE uid='".$who."'"));
if($sx[0]=="F"){$selected=" selected=\"selected\"";}else{$selected="";}
if($tools[0]==1){$usetools=" selected=\"selected\"";}else{$usetools="";}
if($tools[1]==1){$boot=" selected=\"selected\"";}else{$boot="";}
if($tools[2]==1){$ban=" selected=\"selected\"";}else{$ban="";}
if($tools[3]==1){$unban=" selected=\"selected\"";}else{$unban="";}
if($tools[4]==1){$ipban=" selected=\"selected\"";}else{$ipban="";}
if($tools[5]==1){$delete=" selected=\"selected\"";}else{$delete="";}
if($tools[6]==1){$validate=" selected=\"selected\"";}else{$validate="";}
if($tools[7]==1){$delshout=" selected=\"selected\"";}else{$delshout="";}
if($tools[8]==1){$userinfo=" selected=\"selected\"";}else{$userinfo="";}
if($tools[9]==1){$settings=" selected=\"selected\"";}else{$settings="";}
if($tools[10]==1){$ghosts=" selected=\"selected\"";}else{$ghost="";}
if($tools[11]==1){$chat=" selected=\"selected\"";}else{$chat="";}
if($tools[12]==1){$forum=" selected=\"selected\"";}else{$forum="";}
if($tools[13]==1){$club=" selected=\"selected\"";}else{$club="";}
if($tools[14]==1){$quiz=" selected=\"selected\"";}else{$quiz="";}
if($tools[15]==1){$game=" selected=\"selected\"";}else{$game="";}
if($tools[16]==1){$gallery=" selected=\"selected\"";}else{$gallery="";}
if($tools[17]==1){$editusers=" selected=\"selected\"";}else{$editusers="";}
if($tools[18]==1){$download=" selected=\"selected\"";}else{$download="";}
if($tools[19]==1){$links=" selected=\"selected\"";}else{$links="";}
$main="<div class=".align().">
<form action=\"./edituser.php?edit=1&amp;sid=$sid\" method=\"post\">
Tools: <select name=\"tools\">
<option value=\"0\">No</option>
<option value=\"1\"$usetools>Yes</option>
</select><br/>
Boot: <select name=\"boot\">
<option value=\"0\">No</option>
<option value=\"1\"$boot>Yes</option>
</select><br/>
Ban: <select name=\"ban\">
<option value=\"0\">No</option>
<option value=\"1\"$ban>Yes</option>
</select><br/>
Unban: <select name=\"unban\">
<option value=\"0\">No</option>
<option value=\"1\"$unban>Yes</option>
</select><br/>
Ipban: <select name=\"ipban\">
<option value=\"0\">No</option>
<option value=\"1\"$ipban>Yes</option>
</select><br/>
Delete: <select name=\"delete\">
<option value=\"0\">No</option>
<option value=\"1\"$delete>Yes</option>
</select><br/>
Validate: <select name=\"validate\">
<option value=\"0\">No</option>
<option value=\"1\"$validate>Yes</option>
</select><br/>
Chat Tools: <select name=\"chat_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$chat>Yes</option>
</select><br/>
Forum Tools: <select name=\"forum_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$forum>Yes</option>
</select><br/>
Club Tools: <select name=\"club_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$club>Yes</option>
</select><br/>
Game Tools: <select name=\"game_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$game>Yes</option>
</select><br/>
Download Tools: <select name=\"download_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$download>Yes</option>
</select><br/>
Gallery Tools: <select name=\"gallery_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$gallery>Yes</option>
</select><br/>
Quiz Tools: <select name=\"quiz_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$quiz>Yes</option>
</select><br/>
Link Tools: <select name=\"link_tools\">
<option value=\"0\">No</option>
<option value=\"1\"$links>Yes</option>
</select><br/>
Delete Shout: <select name=\"delshout\">
<option value=\"0\">No</option>
<option value=\"1\"$delshout>Yes</option>
</select><br/>
User Info: <select name=\"userinfo\">
<option value=\"0\">No</option>
<option value=\"1\"$userinfo>Yes</option>
</select><br/>
Site Settings: <select name=\"settings\">
<option value=\"0\">No</option>
<option value=\"1\"$settings>Yes</option>
</select><br/>
Ghost Users: <select name=\"ghosts\">
<option value=\"0\">No</option>
<option value=\"1\"$ghosts>Yes</option>
</select><br/>
Edit User: <select name=\"editusers\">
<option value=\"0\">No</option>
<option value=\"1\"$editusers>Yes</option>
</select><br/>
<input type=\"hidden\" name=\"who\" value=\"$who\"/>
<input type=\"hidden\" name=\"type\" value=\"admintools\"/>
<input type=\"submit\" value=\"Update\"/>
</form>
</div>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">\n<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$main.="<p align=".align().">
<a href=\"./moderate.php?edit=1&amp;who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}


?>