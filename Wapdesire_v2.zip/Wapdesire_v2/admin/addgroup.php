<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ADD GROUP/////////////////////////

if($save==1){
addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
if($level[0]>=4){
if(empty($id)){
$res=mysql_query("INSERT INTO groups SET name='".$name."', minage='".$minage."', maxage='".$maxage."', level='".$level."', points='".$points."', rid='".$rid."', fid='".$fid."'");
}else{
$res=mysql_query("UPDATE groups SET name='".$name."', minage='".$minage."', maxage='".$maxage."', level='".$level."', points='".$points."', rid='".$rid."', fid='".$fid."' WHERE id='".$id."'");
}
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Group Saved Successfully<br/>\n";
}else{
$main.="<img src=\"../images/notok.gif\" alt=\"[x]\"/>Error Saving Group<br/>\n";
}
$main.="<br/>
$fivekey<a $key5 href=\"./groups.php?sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
if($level[0]>=4){
$main.="<b>Add Group</b>
</p>
<div class=".align().">
<form action=\"./addgroup.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Group:</b><br/>
<input name=\"name\" maxlength=\"30\" value=\"$group[name]\"/><br/>
<b>Min Age:</b><br/>
<input name=\"minage\" maxlength=\"10\" size=\"10\" value=\"$group[minage]\"/><br/>
<b>Max Age:</b><br/>
<input name=\"maxage\" maxlength=\"10\" size=\"10\" value=\"$group[maxage]\"/><br/>
<b>Level:</b><br/>
<select name=\"level\">
<option value=\"0\">Members</option>
<option value=\"1\">Moderators</option>
<option value=\"2\">Forum Admins</option>
<option value=\"3\">Chat Admins</option>
<option value=\"4\">Head Admins</option>
<option value=\"5\">Owners</option>
</select><br/>
<b>Points:</b><br/>
<input name=\"points\" style=\"-wap-input-format: '*N'\" maxlength=\"10\" size=\"10\" value=\"$group[points]\"/><br/>\n";
$forums=mysql_query("SELECT id, name FROM forums ORDER BY  name, id");
$chatrooms=mysql_query("SELECT id, name FROM chatrooms ORDER BY  name, id");
$main.="<b>Forum:</b><br/>
<select name=\"fid\">\n";
while($forum=mysql_fetch_array($forums)){
$main.="<option value=\"$forum[0]\">$forum[1]</option>\n";
}
$main.="</select><br/>\n";
$chatrooms=mysql_query("SELECT id, name FROM chatrooms ORDER BY  name, id");
$main.="<b>Chatroom:</b><br/>
<select name=\"rid\">\n";
while($chatroom=mysql_fetch_array($chatrooms)){
$main.="<option value=\"$chatroom[0]\">$chatroom[1]</option>\n";
}
$main.="</select><br/>
<input type=\"submit\" value=\"Add Group\">
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./groups.php?sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>