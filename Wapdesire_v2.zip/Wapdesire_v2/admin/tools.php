<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////TOOLS/////////////////////////

addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($type==tools){
$noi=mysql_fetch_array(mysql_query("SELECT count(*) FROM banned WHERE penalty>'0'"));
$main.="<a href=\"./banned.php?sid=$sid\">$noi[0] Banned</a>";
$noi=mysql_fetch_array(mysql_query("SELECT count(*) FROM users WHERE validated='0'"));
if(validate(getuid_sid($sid))){
$main.="<br/>\n<a href=\"./validate.php?sid=$sid\">$noi[0] Awaiting Validation</a>";
}else{
$main.="<br/>
$noi[0] Awaiting Validation</a>";
}
if(site_settings(getuid_sid($sid))){
$main.="<br/>\n<a href=\"./settings.php?sid=$sid\">Site Settings</a>";
}else{
$main.="<br/>
Site Settings</a>";
}
$main.="<br/>\n<a href=\"./blocked.php?type=site&amp;sid=$sid\">Blocked Sites</a><br/>
<a href=\"./blocked.php?type=browser&amp;sid=$sid\">Blocked Browsers</a><br/>
<a href=\"./blocked.php?type=ipaddress&amp;sid=$sid\">Blocked Ip-Addresses</a><br/>
<a href=\"./blocked.php?type=network&amp;sid=$sid\">Blocked Networks</a>";
if($level[0]>=4){
$main.="<br/>\n<a href=\"./forums.php?sid=$sid\">Forums</a>";
}else{
$main.="<br/>
Forums</a>";
}
if($level[0]>=4){
$main.="<br/>\n<a href=\"./chat.php?sid=$sid\">Chat</a>";
}else{
$main.="<br/>
Chat</a>";
}
if($level[0]>=4){
$main.="<br/>\n<a href=\"./groups.php?sid=$sid\">Groups</a>";
}else{
$main.="<br/>
Groups</a>";
}
if($level[0]>=4){
$main.="<br/>
<a href=\"../smilies/upload.php?sid=$sid\">Add Smilies</a><br/>
<a href=\"../smilies/smilies.php?sid=$sid\">Smilies List</a><br/>
<a href=\"./delinboxes.php?sid=$sid\">Delete Inboxes</a><br/>
<a href=\"./delpopups.php?sid=$sid\">Delete Popups</a><br/>
<a href=\"./dellogs.php?sid=$sid\">Delete Logs</a>";
}else{
$main.="<br/>
Add Smilies<br/>
<a href=\"../smilies/smilies.php?sid=$sid\">Smilies List</a><br/>
Delete Inboxes<br/>
Delete Popups<br/>
Delete Logs";
}
$main.="<br/>
<br/>
<a href=\"./tools.php?type=modtools&amp;sid=$sid\">View Forums/Chatrooms To Moderate</a>";
}else if($type==modtools){
$query=mysql_query("SELECT * FROM modtools WHERE uid='".getuid_sid($sid)."' AND fid>'0' AND clubid='0'");
if(mysql_num_rows($query)>0){
$main.="<b>Forums To Moderate:</b>";
while($array=mysql_fetch_array($query)){
$row=mysql_fetch_array(mysql_query("SELECT * FROM forums WHERE id='".$array[fid]."'"));
$main.="<br/>
".$row[name]."";
}
}else{
$main.="No Forums To Moderate!!!";
}
$query=mysql_query("SELECT * FROM modtools WHERE uid='".getuid_sid($sid)."' AND rid>'0' AND clubid='0'");
if(mysql_num_rows($query)>0){
$main.="\n</p>
<p align=".align().">
<b>Chatrooms To Moderate:</b>";
while($array=mysql_fetch_array($query)){
$row=mysql_fetch_array(mysql_query("SELECT * FROM chatrooms WHERE id='".$array[fid]."'"));
$main.="<br/>
".$row[name]."";
}
}else{
$main.="<br/>
<br/>
No Chatrooms To Moderate!!!";
}
$query=mysql_query("SELECT * FROM modtools WHERE uid='".getuid_sid($sid)."' AND rid>'0' AND clubid>'0'");
if(mysql_num_rows($query)>0){
$main.="\n</p>
<p align=".align().">
<b>Clubs To Moderate:</b>";
while($array=mysql_fetch_array($query)){
$row=mysql_fetch_array(mysql_query("SELECT * FROM clubs WHERE id='".$array[clubid]."'"));
$main.="<br/>
".$row[name]." Club";
}
}else{
$main.="<br/>
<br/>
No Clubs To Moderate!!!";
}
$main.="<br/>
<br/>
<a href=\"./tools.php?type=tools&amp;sid=$sid\">Back To Tools</a>";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>