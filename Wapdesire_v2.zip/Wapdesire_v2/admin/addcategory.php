<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ADD CATEGORY/////////////////////////

if($save==1)
{
addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
if($level[0]>=4){
if(empty($id)){
$res=mysql_query("INSERT INTO forumcats SET name='".$name."', position='".$position."'");
}else{
$res=mysql_query("UPDATE forumcats SET name='".$name."', position='".$position."' WHERE id='".$id."'");
}
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Forum Category Saved successfully<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Forum Category<br/>\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}
$main.="<br/>
$fivekey<a $key5 href=\"./forums.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}

addonline(getuid_sid($sid),"Admin Tools","");
echo head_tag(getnick_sid($sid)."@Admin Tools",1,getnick_sid($sid));
$title="<b>Admin Tools</b>";
$main="<p align=".align().">\n";
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
if($level[0]>=4){
$next_number=mysql_fetch_array(mysql_query("SELECT MAX(position) FROM forumcats"));
$main.="<b>Add Category</b>
</p>
<div class=".align().">
<form action=\"./addcategory.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Name:</b><br/>
<input name=\"name\" maxlength=\"30\"/><br/>
<b>Position:</b><input name=\"position\" style=\"-wap-input-format: '*N'\" size=\"2\" maxlength=\"2\" value=\"".($next_number[0]+1)."\"/><br/>
<input type=\"submit\" value=\"Add Category\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./forums.php?sid=$sid\">Back</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!<br/>
<br/>
$fivekey<a $key5 href=\"./tools.php?type=tools&amp;sid=$sid\">Back</a>
</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
?>