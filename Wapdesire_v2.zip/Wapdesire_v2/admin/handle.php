<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////HANDLING/////////////////////////

addonline(getuid_sid($sid),"Handling $type","");
echo head_tag(getnick_sid($sid)."@Handle $type",1,getnick_sid($sid));
$title="<b>Handle $type</b>";
$main="<p align=".align().">";
if(isowner(getuid_sid($sid))){
if($type==Inbox){
$info=mysql_fetch_array(mysql_query("SELECT byid, toid, text FROM inbox WHERE id='".$id."'"));
$res=mysql_query("UPDATE inbox SET reported='2' WHERE id='".$id."'");
}else if($type==Popup){
$info=mysql_fetch_array(mysql_query("SELECT byid, toid, text FROM popups WHERE id='".$id."'"));
$res=mysql_query("UPDATE popups SET reported='2' WHERE id='".$id."'");
}else if($type==Post){
$info=mysql_fetch_array(mysql_query("SELECT id, text, thread, uid, date FROM forumposts WHERE thread='".$id."'"));
$res=mysql_query("UPDATE forumposts SET reported='2' WHERE thread='".$id."'");
}else if($type==Topic){
$info=mysql_fetch_array(mysql_query("SELECT id, text, uid, date FROM forumtopics WHERE id='".$id."'"));
$res=mysql_query("UPDATE forumtopics SET reported='2' WHERE id='".$id."'");
}else if($type==Blog){
$info=mysql_fetch_array(mysql_query("SELECT id, date, uid, subject, body FROM blogs WHERE id='".$id."'"));
$res=mysql_query("UPDATE blogs SET reported='2' WHERE id='".$id."'");
}else if($type==Wapsite){
$res=mysql_query("UPDATE wapsite SET reported='2' WHERE uid='".$id."'");
}
if($res){
if($type==Inbox){
mysql_query("INSERT INTO logs SET action='inboxes', details='<b>".getnick_uid(getuid_sid($sid))."</b> handled The Inbox ".getnick_uid($info[0])." -&gt; ".getnick_uid($info[1])." - ".$info[2]."', date='".time()."'");
}else if($type==Popup){
mysql_query("INSERT INTO logs SET action='popups', details='<b>".getnick_uid(getuid_sid($sid))."</b> handled The Popup ".getnick_uid($info[0])." -&gt; ".getnick_uid($info[1])." - ".$info[2]."', date='".time()."'");
}else if($type==Post){
mysql_query("INSERT INTO logs SET action='posts', details='<b>".getnick_uid(getuid_sid($sid))."</b> handled The Post ".getnick_uid($info[3])." - ".$info[1]."', date='".time()."'");
}else if($type==Topic){
mysql_query("INSERT INTO logs SET action='topics', details='<b>".getnick_uid(getuid_sid($sid))."</b> handled The Topic ".getnick_uid($info[2])." - ".$info[1]."', date='".time()."'");
}else if($type==Blog){
mysql_query("INSERT INTO logs SET action='blogs', details='<b>".getnick_uid(getuid_sid($sid))."</b> handled The Blog ".getnick_uid($info[2])." - <b>".$info[3]."</b> ".$info[4]."', date='".time()."'");
}else if($type==Wapsite){
mysql_query("INSERT INTO logs SET action='wapsites', details='<b>".getnick_uid(getuid_sid($sid))."</b> handled <b>".getnick_uid($id)."</b> Wapsite', date='".time()."'");
}
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>$type Handled<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Database Error<br/>\n";
}
if($type==Inbox||$type==Popup){
$main.="<br/>
$onekey<a $key1 href=\"../profile.php?who=$info[0]&amp;sid=$sid\">$type Sender's Profile</a><br/>
$twokey<a $key2 href=\"../profile.php?who=$info[1]&amp;sid=$sid\">$type Reporter's Profile</a>\n";
}else if($type==Post){
$main.="<br/>
$onekey<a $key1 href=\"../profile.php?who=$info[3]&amp;sid=$sid\">$type Sender's Profile</a><br/>\n";
}else if($type==Topic){
$main.="<br/>
$onekey<a $key1 href=\"../profile.php?who=$info[2]&amp;sid=$sid\">$type Sender's Profile</a><br/>\n";
}
else if($type==Blog){
$main.="<br/>
$onekey<a $key1 href=\"../profile.php?who=$info[2]&amp;sid=$sid\">$type Sender's Profile</a><br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$fivekey<a $key5 href=\"./reports.php?sid=$sid\">Reports/Logs</a><br/>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>