<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SITE SETTINGS/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Updating Site Settings","");
echo head_tag(getnick_sid($sid)."@Updating Site Settings",1,getnick_sid($sid));
$title="<b>Updating Site Settings</b>";
$main="<p align=".align().">";
if(site_settings(getuid_sid($sid))){
if($registration=="e"){$arv="1";}
else{$arv="0";}
if($validation=="e"){$vldtn="1";}
else{$vldtn="0";}
$res=mysql_query("Update settings SET value='".$sitename2."' WHERE name='sitename'");
$res2=mysql_query("Update settings SET value='".$timezone."' WHERE name='timezone'");
$res3=mysql_query("Update settings SET value='".$sesexp."' WHERE name='sesexp'");
$res4=mysql_query("Update settings SET value='".$antiflood."' WHERE name='antiflood'");
$res5=mysql_query("Update settings SET value='".$greeting."' WHERE name='greeting'");
$res6=mysql_query("Update settings SET value='".$arv."' WHERE name='registration'");
$res7=mysql_query("Update settings SET value='".$forumview."' WHERE name='forumview'");
$res8=mysql_query("Update settings SET value='".$vldtn."' WHERE name='validation'");
$res9=mysql_query("Update settings SET value='".$sitealign."' WHERE name='align'");
$res10=mysql_query("Update settings SET value='".$site_email."' WHERE name='site_email'");
$res11=mysql_query("Update settings SET value='".$gallery_email."' WHERE name='gallery_email'");
if($res&&$res2&&$res3&&$res4&&$res5&&$res6&&$res7&&$res8&&$res9&&$res10&&$res11){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Site Settings Updated Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Updating Site Settings!\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Editing Site Settings","");
echo head_tag(getnick_sid($sid)."@Edit Site Settings",1,getnick_sid($sid));
$title="<b>Edit Site Settings</b>";
if(site_settings(getuid_sid($sid))){
if(registration()){$arv="e";}
else{$arv="d";}
if(validation()){$vldtn="e";}
else{$vldtn="d";}
if(align()==center){$algn2=" selected=\"selected\"";}else{$algn2="";}
if(align()==right){$algn3=" selected=\"selected\"";}else{$algn3="";}
$main="<div class=".align().">
<form action=\"./settings.php?update=1&amp;sid=$sid\" method=\"post\">
<b>Site Name:</b><br/>
<input name=\"sitename2\" value=\"".sitename()."\" maxlength=\"255\"/><br/>
<b>Session Period:</b><br/>
<input name=\"sesexp\" value=\"".getsxtm()."\" style=\"-wap-input-format: '*N'\" maxlength=\"3\" size=\"3\"/><br/>
<b>Antiflood:</b><br/>
<input name=\"antiflood\" value=\"".antiflood()."\" style=\"-wap-input-format: '*N'\" maxlength=\"3\" size=\"3\"/><br/>
<b>Main Page Greeting:</b><br/>
<input name=\"greeting\" value=\"".greeting()."\" maxlength=\"255\"/><br/>\n";
if(!registration()){$selected=" selected=\"selected\"";}
$main.="<b>Registration:</b><br/>
<select name=\"registration\" value=\"$arv\">
<option value=\"e\">Enabled</option>
<option value=\"d\"$selected>Disabled</option>
</select><br/>
<b>Forum View:</b><br/>
<select name=\"forumview\" value=\"".forumview()."\">\n";
if(forumview()==0){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"0\"$selected>Forums Page</option>\n";
if(forumview()==1){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"1\"$selected>Forums</option>\n";
if(forumview()==2){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"2\"$selected>Categories</option>\n";
if(forumview()==3){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"3\"$selected>Drop List</option>
</select><br/>\n";
if(!validation()){$selected=" selected=\"selected\"";}
$main.="<b>Validation:</b><br/>
<select name=\"validation\" value=\"$vldtn\">
<option value=\"e\">Enabled</option>
<option value=\"d\"$selected>Disabled</option>
</select><br/>
<b>Site Alignment:</b><br/>
<select name=\"sitealign\">
<option value=\"left\">Left</option>
<option value=\"center\"$algn2>Centered</option>
<option value=\"right\"$algn3>Right</option>
</select><br/>
<b>Timezone:</b><br/>
<input name=\"timezone\" value=\"".timezone()."\" maxlength=\"255\"/><br/>
<b>Site Email:</b><br/>
<input name=\"site_email\" value=\"".email(site)."\" maxlength=\"255\"/><br/>
<b>Gallery Email:</b><br/>
<input name=\"gallery_email\" value=\"".email(gallery)."\" maxlength=\"255\"/><br/>
<input type=\"submit\" Value=\"Submit\"/>
</form>
</div>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!
</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>