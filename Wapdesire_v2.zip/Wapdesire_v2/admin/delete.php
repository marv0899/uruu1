<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////DELETE USER/////////////////////////

addonline(getuid_sid($sid),"Deleting User","");
echo head_tag(getnick_sid($sid)."@Delete User",1,getnick_sid($sid));
$title="<b>Deleting User</b>";
$main="<p align=".align().">\n";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main.="<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Delete ".getnick_uid($who)."
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(delete_user(getuid_sid($sid))){
mysql_query("INSERT INTO logins SET uid='".getuid_sid($sid)."', username='".getnick_sid($sid)."', password='', ip='".ip()."', host='".subno()."', browser='".$_SERVER['HTTP_USER_AGENT']."', date='".date("g:ia - l jS F Y")."', action='delete'");
mysql_query("INSERT INTO logs SET action='deleted', details='<b>".getnick_uid(getuid_sid($sid))."</b> deleted ".getnick_uid($who)."', date='".time()."'");
$res=mysql_query("INSERT INTO nicks SET name='".getnick_uid($who)."', nicklvl='1'");
$res=mysql_query("DELETE FROM banned WHERE uid='".$who."' OR byid='".$who."'");
$res=mysql_query("DELETE FROM buds WHERE tid='".$who."' OR uid='".$who."'");
$res=mysql_query("DELETE FROM chat WHERE uid='".$who."' OR toid='".$who."'");
$res=mysql_query("DELETE FROM chatonline WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM forumposts WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM forumtopics WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM ignored WHERE uid='".$who."' OR tid='".$who."'");
$res=mysql_query("DELETE FROM inbox WHERE byid='".$who."' OR toid='".$who."' OR fwd='".$who."'");
$res=mysql_query("DELETE FROM online WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM profiles WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM wapsite WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM ses WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM shouts WHERE uid='".$who."'");
$res=mysql_query("DELETE FROM users WHERE id='".$who."'");
$res=mysql_query("DELETE FROM admintools WHERE uid='".$who."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>User Deleted Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Deleting User!\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>