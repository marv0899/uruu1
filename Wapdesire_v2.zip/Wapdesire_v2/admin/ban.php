<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////BAN USER/////////////////////////

if($ban==1)
{
addonline(getuid_sid($sid),"Banning User","");
echo head_tag(getnick_sid($sid)."@Banning User",1,getnick_sid($sid));
$title="<b>Banning User</b>";
$main="<p align=".align().">\n";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main.="<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Ban ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(ban(getuid_sid($sid),$who)){
if(trim($reason)==""){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
You Must Specify A Reason For Banning ".getnick_uid($who)."\n";
}else{
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
if($level>0&&$type=="Shoutbox"){
$res=mysql_query("INSERT INTO banned SET uid='".$who."', penalty='0', byid='".getuid_sid($sid)."', remaining='".($remaining+time())."', reason='".$reason."'");
}else if(ipban(getuid_sid($sid),$who)&&$type=="Ip"){
$brip=mysql_fetch_array(mysql_query("SELECT ipaddress, browser FROM users WHERE id='".$who."'"));
$res=mysql_query("INSERT INTO banned SET uid='".$who."', penalty='4', byid='".getuid_sid($sid)."', remaining='".($remaining+time())."', reason='".$reason."', ipaddress='".$brip[0]."', browser='".$brip[1]."'");
}else if(($level>3||$level==2)&&$type=="Forum"){
$res=mysql_query("INSERT INTO banned SET uid='".$who."', penalty='1', byid='".getuid_sid($sid)."', remaining='".($remaining+time())."', reason='".$reason."'");
}else if($level>2&&$type=="Chat"){
$res=mysql_query("INSERT INTO banned SET uid='".$who."', penalty='2', byid='".getuid_sid($sid)."', remaining='".($remaining+time())."', reason='".$reason."'");
}else if($level>3&&$type=="Site"){
$res=mysql_query("INSERT INTO banned SET uid='".$who."', penalty='3', byid='".getuid_sid($sid)."', remaining='".($remaining+time())."', reason='".$reason."'");
}
if($res){
mysql_query("INSERT INTO logs SET action='$type-Ban', details='<b>".getnick_uid(getuid_sid($sid))."</b> Banned <b>".getnick_uid($who)."</b> For ".time_msg($remaining,0)."', date='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/>".getnick_uid($who)." Banned Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/>Error Banning ".getnick_uid($who)."\n";
}
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>
<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}


addonline(getuid_sid($sid),"Banning User","");
echo head_tag(getnick_sid($sid)."@Ban User",1,getnick_sid($sid));
$title="<b>Ban User</b>";
$main="<p align=".align().">\n";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main.="<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Delete ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(ban(getuid_sid($sid),$who)){
$level=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".getuid_sid($sid)."'"));
$main.="Are You Sure You Want To Ban ".getnick_uid($who)." ?\n</p>\n";
$main.="<div class=".align().">
<form action=\"./ban.php?ban=1&amp;sid=$sid\" method=\"post\">
<b>Reason:</b><br/>
<input name=\"reason\" maxlength=\"100\"/><br/>
<b>Ban Period:</b><br/>
<select name=\"remaining\">
<option value=\"300\">5 Mins</option>
<option value=\"1200\">20 Mins</option>
<option value=\"3600\">1 Hour</option>
<option value=\"43200\">12 Hours</option>
<option value=\"86400\">1 Day</option>
<option value=\"172800\">2 Days</option>
<option value=\"259200\">3 Days</option>
<option value=\"604800\">1 Week</option>
<option value=\"1209600\">2 Weeks</option>
<option value=\"2419200\">1 Month</option>
</select><br/>
<b>Type:</b><br/>
<select name=\"type\">\n";
if($level>0){
$main.="<option value=\"Shoutbox\">Shoutbox-Ban</option>\n";
}
if($level>3||$level==2){
$main.="<option value=\"Forum\">Forum-Ban</option>\n";
}
if($level>3||$level==3){
$main.="<option value=\"Chat\">Chat-Ban</option>\n";
}
if($level>3){
$main.="<option value=\"Site\">Site-Ban</option>\n";
}
if(ipban(getuid_sid($sid),$who)){
$main.="<option value=\"Ip\">Ip-Ban</option>\n";
}
$main.="</select><br/>
<input type=\"hidden\" name=\"who\" value=\"$who\"/>
<input type=\"submit\" value=\"Ban\"/>
</form>
</div>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$main.="<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>