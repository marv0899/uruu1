<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////REPORTS/////////////////////////

if($inbox==1)
{
addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports",1,getnick_sid($sid));
$title="<b>Reports</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE reported ='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, text, byid, toid, timesent FROM inbox WHERE reported='1' ORDER BY timesent DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if($items!=""){
while($item=mysql_fetch_array($items)){
$main.="<a href=\"../profile.php?who=$item[2]&amp;sid=$sid\">".getnick_uid($item[2])."</a>
<img src=\"../images/in.gif\" alt=\"-&gt;\"/>
<a href=\"../profile.php?who=$item[3]&amp;sid=$sid\">".getnick_uid($item[3])."</a><br/>
<small>(".date("d m y - H:i:s", $item[4]).")</small><br/>
".getbbcode($item[1],$sid,1)."<br/>\n";
if(isowner(getuid_sid($sid))){$main.="<a href=\"./handle.php?type=Inbox&amp;id=$item[0]&amp;sid=$sid\">Handle</a><br/>\n";}
}
}else{
$main.="No Reported Inboxes<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./reports.php?inbox=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> \n";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"./reports.php?inbox=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("reports","inbox","1",$sid);}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($popup==1)
{
addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports",1,getnick_sid($sid));
$title="<b>Reports</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM popups WHERE reported ='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, text, byid, toid, timesent FROM popups WHERE reported='1' ORDER BY timesent DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if($items!=""){
while($item=mysql_fetch_array($items)){
$main.="<a href=\"../profile.php?who=$item[2]&amp;sid=$sid\">".getnick_uid($item[2])."</a>
<img src=\"../images/in.gif\" alt=\"-&gt;\"/>
<a href=\"../profile.php?who=$item[3]&amp;sid=$sid\">".getnick_uid($item[3])."</a><br/>
<small>(".date("d m y - H:i:s", $item[4]).")</small><br/>
".getbbcode($item[1],$sid,1)."<br/>\n";
if(isowner(getuid_sid($sid))){$main.="<a href=\"./handle.php?type=Popup&amp;id=$item[0]&amp;sid=$sid\">Handle</a><br/>\n";}
}
}else{
$main.="No Reported Popups<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./reports.php?inbox=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> \n";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"./reports.php?inbox=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("reports","inbox","1",$sid);}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($post==1)
{
addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports",1,getnick_sid($sid));
$title="<b>Reports</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE reported='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, text, thread, uid, date FROM forumposts WHERE reported='1' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if($items!=""){
while($item=mysql_fetch_array($items)){
$topic=mysql_fetch_array(mysql_query("SELECT name FROM forumtopics WHERE id='".$item[2]."'"));
$main.="
<a href=\"../forums/viewtopic.php?tid=$item[2]&amp;sid=$sid\">$topic[0]</a><br/>
(<a href=\"../profile.php?who=$item[3]&amp;sid=$sid\">".getnick_uid($item[3])."</a>)<br/>
<small>(".date("d m y-H:i:s",$item[4]).")</small><br/>
".getbbcode($item[1],$sid,1)."<br/>\n";
if(isowner(getuid_sid($sid))){$main.="<a href=\"./handle.php?type=Post&amp;id=$item[2]&amp;sid=$sid\">Handle</a><br/>\n";}
}
}else{
$main.="No Reported Posts<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./reports.php?post=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> \n";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"./reports.php?post=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("reports","post","1",$sid);}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($topic==1)
{
addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports",1,getnick_sid($sid));
$title="<b>Reports</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE reported='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, text, uid, date, name FROM forumtopics WHERE reported='1' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if($items!=""){
while($item=mysql_fetch_array($items)){
$topic=mysql_fetch_array(mysql_query("SELECT name FROM forumtopics WHERE id='".$item[2]."'"));
$main.="
<a href=\"../forums/viewtopic.php?thread=$item[0]&amp;sid=$sid\">$item[4]</a><br/>
(<a href=\"../profile.php?who=$item[2]&amp;sid=$sid\">".getnick_uid($item[2])."</a>)<br/>
<small>(".date("d m y-H:i:s",$item[3]).")</small><br/>
".getbbcode($item[1],$sid,1)."<br/>\n";
if(isowner(getuid_sid($sid))){$main.="<a href=\"./handle.php?type=Topic&amp;id=$item[0]&amp;sid=$sid\">Handle</a><br/>\n";}
}
}else{
$main.="No Reported Topics<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./reports.php?topic=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> \n";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"./reports.php?topic=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("reports","topic","1",$sid);}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($blog==1)
{
addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports",1,getnick_sid($sid));
$title="<b>Reports</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE reported='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, date, uid, subject, body FROM blogs WHERE reported='1' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if($items!=""){
while($item=mysql_fetch_array($items)){
$main.="<a href=\"../wapsites/blogs.php?read=1&id=$item[0]&who=$item[2]&amp;sid=$sid\">".getbbcode($item[3],$sid,1)."</a><br/>
<small>(<a href=\"../profile.php?who=$item[2]&amp;sid=$sid\">".getnick_uid($item[2])."</a> ".date("l jS F", $item[1]).")</small><br/>\n";
if(isowner(getuid_sid($sid))){$main.="<a href=\"./handle.php?type=Blog&amp;id=$item[0]&amp;sid=$sid\">Handle</a><br/>\n";}
$main.="<br/>\n";
}
}else{
$main.="No Reported Blogs<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./reports.php?blog=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> \n";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"./reports.php?blog=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("reports","blog","1",$sid);}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($wapsite==1)
{
addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports",1,getnick_sid($sid));
$title="<b>Reports</b>";
$main="<p align=".align().">\n";
if(use_tools(getuid_sid($sid))){
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE reported='1'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT * FROM wapsite WHERE reported='1' ORDER BY uid LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
if($items!=""){
while($item=mysql_fetch_array($items)){
$main.="Check <a href=\"../wapsites/profile.php?who=$item[uid]&amp;sid=$sid\">".getnick_uid($item[uid])."</a> Wapsite Profile It May Contain Spam<br/>\n";
if(isowner(getuid_sid($sid))){$main.="<a href=\"./handle.php?type=Wapsite&amp;id=$item[uid]&amp;sid=$sid\">Handle</a><br/>\n";}
$main.="<br/>\n";
}
}else{
$main.="No Reported Wapsites<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./reports.php?wapsite=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> \n";
}
if($page<$num_pages){
if($page==1){$main.="<br/>";}
$main.="<a href=\"./reports.php?wapsite=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("reports","wapsite","1",$sid);}
$main.="<p align=".align().">
<a href=\"./logs.php?sid=$sid\">Reports/Logs</a>
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Viewing Reports","");
echo head_tag(getnick_sid($sid)."@Reports/Logs",1,getnick_sid($sid));
$title="<b>Reports/Logs</b>";
$main="<p align=".align().">";
if(use_tools(getuid_sid($sid))){
$main.="<b>Reports</b><br/>";
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE reported='1'"));
$count=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?inbox=1&amp;sid=$sid\">Inbox Messages $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM popups WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?popup=1&amp;sid=$sid\">Popup Messages $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?post=1&amp;sid=$sid\">Posts $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?topic=1&amp;sid=$sid\">Topics $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?blog=1&amp;sid=$sid\">Blogs $row[0]</a><br/>\n";
}
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE reported='1'"));
$count+=$row[0];
if($row[0]>0){
$main.="<a href=\"./reports.php?wapsite=1&amp;sid=$sid\">Wapsites $row[0]</a><br/>\n";
}
if($count==0){$main.="No Reports Atm...<br/>\n";}
$main.="<br/><b>Logs</b><br/>\n";
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs"));
if($row[0]>0){
$query=mysql_query("SELECT DISTINCT (action)FROM logs ORDER BY date DESC");
while($array=mysql_fetch_array($query)){
$row=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs WHERE action='".$array[0]."'"));
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs"));
if($count!=0){
$main.="<a href=\"./logs.php?logs=1&amp;act=$array[0]&amp;sid=$sid\">$array[0] $row[0]</a><br/>\n";
}else{
$main.="No Logs Atm...\n";
}
}
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>