<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////UNBAN USER/////////////////////////

addonline(getuid_sid($sid),"Unbanning User","");
echo head_tag(getnick_sid($sid)."@Unbanning User",1,getnick_sid($sid));
$title="<b>Unbanning User</b>";
$main="<p align=".align().">\n";
$trgtperm=mysql_fetch_array(mysql_query("SELECT level FROM users WHERE id='".$who."'"));
if($trgtperm[0]>$row_users[level]){ 
$main.="<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>
Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Delete ".getnick_uid($who)."
</p>
<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
exit;
}
if(unban(getuid_sid($sid),$who)){
$res=mysql_query("DELETE FROM banned WHERE uid='".$who."'");
if($res){
mysql_query("INSERT INTO logs SET action='unbanned', details='<b>".getnick_uid(getuid_sid($sid))."</b> Unbanned <b>".getnick_uid($who)."</b>', date='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/>".getnick_uid($who)." Unbanned Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/>Error Banning ".getnick_uid($who)."\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}
$main.="</p>
<p align=".align().">
<a href=\"../profile.php?who=$who&amp;sid=$sid\">Back To Profile</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>