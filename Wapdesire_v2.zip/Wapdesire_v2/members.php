<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MEMBERS LIST/////////////////////////

addonline(getuid_sid($sid),"Members List","search.php?action=$action");
echo head_tag(getnick_sid($sid)."@Member Search",1,getnick_sid($sid));
$title="<b>Members List</b>";
$main="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page= $num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT a.id, a.username, b.birthday, b.sex, b.location 
FROM users a INNER JOIN profiles b ON a.id = b.uid 
ORDER BY a.regdate DESC LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
if($item[3]=='M'){$usersex="<img src=\"images/male.gif\" alt=\"(M)\"/>";$usex="Male";$color="#0000FF";}
else if($item[3]=='F'){$usersex="<img src=\"images/female.gif\" alt=\"(F)\"/>";$usex="Female";$color="#FF0066";}
else{$usex="Argh! No Profile!";$usersex="";}
$main.="$usersex<a href=\"./profile.php?who=$item[0]&amp;sid=$sid\" style=\"color:$color;\">$item[1]</a>(".getage($item[2])."/$usex/".getbbcode($item[4],$sid,1).")<br/>";
}
}
if($page>1){
$main.="<br/><a href=\"members.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"members.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("members","","",$sid);}
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>