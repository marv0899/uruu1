<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////STAFF LIST/////////////////////////

addonline(getuid_sid($sid),"Staff List","");
echo head_tag(getnick_sid($sid)."@Staff List",1,getnick_sid($sid));
$title="<b>Staff List</b>";
$main="<p align=".align().">";
$sql="SELECT a.id, a.username, a.level, a.hidden, b.sex FROM users a INNER JOIN profiles b ON a.id=b.uid WHERE a.level>'0' ORDER BY a.level,a.username";
$query=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($query)>0){
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE level='5'"));
if($count[0]!=0){$main.="<b>Owner(s):</b><br/>";}
while($owners=mysql_fetch_array($query)){
if(!ghosts(getuid_sid($sid))&&($owners[3]==1)){$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
else if(isonline($owners[0])){$style="style=\"font-size:10px;color:#009900\"";$status="online!";}
else{$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
if($owners[4]=="M"){$sex="style=\"color:#0000FF;\"";}
else if($owners[4]=="F"){$sex="style=\"color:#FF0066;\"";}
if($owners[2]==5){
$main.=$onl."&#176;<a href=\"./profile.php?who=$owners[0]&amp;sid=$sid\"$sex>$owners[1]</a>
<span $style>$status</span><br/>";
}
}
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE level='4'"));
$query=mysql_query($sql);
if($count[0]!=0){$main.="<br/><b>Head Admin(s):</b><br/>";}
while($headadmins=mysql_fetch_array($query)){
if(!ghosts(getuid_sid($sid))&&($headadmins[3]==1)){$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
else if(isonline($headadmins[0])){$style="style=\"font-size:10px;color:#009900\"";$status="online!";}
else{$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
if($headadmins[4]=="M"){$sex="style=\"color:#0000FF;\"";}
else if($headadmins[4]=="F"){$sex="style=\"color:#FF0066;\"";}
if($headadmins[2]==4){
$main.=$onl."&#170;<a href=\"./profile.php?who=$headadmins[0]&amp;sid=$sid\"$sex>$headadmins[1]</a>
<span $style>$status</span><br/>";
}
}
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE level='3'"));
$query=mysql_query($sql);
if($count[0]!=0){$main.="<br/><b>Chat Admin(s):</b><br/>";}
while($admins=mysql_fetch_array($query)){
if(!ghosts(getuid_sid($sid))&&($admins[3]==1)){$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
else if(isonline($admins[0])){$style="style=\"font-size:10px;color:#009900\"";$status="online!";}
else{$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
if($admins[4]=="M"){$sex="style=\"color:#0000FF;\"";}
else if($admins[4]=="F"){$sex="style=\"color:#FF0066;\"";}
if($admins[2]==3){
$main.=$onl."&#185;<a href=\"./profile.php?who=$admins[0]&amp;sid=$sid\"$sex>$admins[1]</a>
<span $style>$status</span><br/>";
}
}
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE level='2'"));
$query=mysql_query($sql);
if($count[0]!=0){$main.="<br/><b>Forum Admin(s):</b><br/>";}
while($admins=mysql_fetch_array($query)){
if(!ghosts(getuid_sid($sid))&&($admins[3]==1)){$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
else if(isonline($admins[0])){$style="style=\"font-size:10px;color:#009900\"";$status="online!";}
else{$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
if($admins[4]=="M"){$sex="style=\"color:#0000FF;\"";}
else if($admins[4]=="F"){$sex="style=\"color:#FF0066;\"";}
if($admins[2]==2){
$main.=$onl."&#178;<a href=\"./profile.php?who=$admins[0]&amp;sid=$sid\"$sex>$admins[1]</a>
<span $style>$status</span><br/>";
}
}
$count=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE level='1'"));
$query=mysql_query($sql);
if($count[0]!=0){$main.="<br/><b>Mod(s):</b><br/>";}
while($mods=mysql_fetch_array($query)){
if(!ghosts(getuid_sid($sid))&&($mods[3]==1)){$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
else if(isonline($mods[0])){$style="style=\"font-size:10px;color:#009900\"";$status="online!";}
else{$style="style=\"font-size:10px;color:#FF0000\"";$status="offline!";}
if($mods[4]=="M"){$sex="style=\"color:#0000FF;\"";}
else if($mods[4]=="F"){$sex="style=\"color:#FF0066;\"";}
if($mods[2]==1){
$main.=$onl."&#179;<a href=\"./profile.php?who=$mods[0]&amp;sid=$sid\"$sex>$mods[1]</a>
<span $style>$status</span><br/>";
}
}
}else{$main.="No Admin(s) Atm...<br/>";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>