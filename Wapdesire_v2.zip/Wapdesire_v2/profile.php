<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW PROFILE/////////////////////////

if($usersbyip==1)
{
$nick=getnick_uid($who).htmlspecialchars("'",ENT_QUOTES)."s";
if(getuid_sid($sid)==$who)$nick="My";
addonline(getuid_sid($sid),"Viewing $nick Profile","");
echo head_tag(getnick_sid($sid)."@View Profile",1,getnick_sid($sid));
$title="<b>Users By Ip/Browser</b>";
$main="<p align=".align().">\n";
if(user_info(getuid_sid($sid))){
$main.="This shows a list of usernames that match the same ip and browser<br/>
IT IS ONLY A GUIDE and is not 100% accurate<br/>
<br/>\n";
$whoinfo=mysql_fetch_array(mysql_query("SELECT ipaddress, browser FROM users WHERE id='".$who."'"));
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE ipaddress='".$whoinfo[0]."' AND browser='".$whoinfo[1]."'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT id, username FROM users 
WHERE ipaddress='".$whoinfo[0]."' 
AND browser='".$whoinfo[1]."' 
ORDER BY username LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
$main.=mysql_error();
while($item=mysql_fetch_array($items))
{
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$item[0]."'"));
if($sex[0]=="M"){$usersex="<img src=\"./images/male.gif\" alt=\"(M)\"/>";$color=" style=\"color:#0000FF\"";}
if($sex[0]=="F"){$usersex="<img src=\"./images/female.gif\" alt=\"(F)\"/>";$color=" style=\"color:#FF0066\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main.=$usersex."<a href=\"./profile.php?who=$item[0]&amp;sid=$sid\"$color>".$item[1]."</a><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./profiles.php?usersbyip=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./profiles.php?usersbyip=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("online","","",$sid);}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n</p>\n";
}
$L1="$sixkey<a $key6 href=\"./profile.php?who=$who&amp;sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@View Profile",1,getnick_sid($sid));
if(($who=="")||($who==0)||!isuser($who)){
$main="<p align=".align().">
<img src=\"./images/error.gif\" alt=\"[x]\"/> User Does Not exist
</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$nick=getnick_uid($who).htmlspecialchars("'",ENT_QUOTES)."s";
if(getuid_sid($sid)==$who)$nick="My";
addonline(getuid_sid($sid),"Viewing $nick Profile","profile.php?who=$who");
$info=mysql_fetch_array(mysql_query("SELECT * FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE a.id='".$who."'"));
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
$title="<b>".getnick_uid($who)."</b><br/>".status($who,1)."<br/>".rating($who)."";
$main="<p align=".align().">\n";
if(isowner(getuid_sid($sid))){
$main.="<a href=\"./admin/moderate.php?who=$who&amp;sid=$sid\">*Owner Tools*</a><br/>\n";
}else if(isheadadmin(getuid_sid($sid))){
$main.="<a href=\"./admin/moderate.php?who=$who&amp;sid=$sid\">*Head Admin Tools*</a><br/>\n";
}else if((ismod(getuid_sid($sid)))||(isadmin(getuid_sid($sid)))){
$main.="<a href=\"./admin/moderate.php?who=$who&amp;sid=$sid\">*Admin Tools*</a><br/>\n";
}else if(use_tools(getuid_sid($sid))){
$main.="<a href=\"./admin/moderate.php?who=$who&amp;sid=$sid\">*Hidden Tools*</a><br/>\n";
}
if($info[picture]!=""){
$main.="<img src=\"./phpThumb/phpThumb.php?src=$info[picture]&amp;w=128&amp;f=".getext($info[picture])."&amp;sia=".getnick_uid($who)."\" alt=\"".getnick_sid($who)."\"/><br/>\n";
}
else{$main.="";}
$main.="<b>Id:</b> $who<br/>\n";
if($info[sex]=='M'){$sex="Male";}
else if($info[sex]=='F'){$sex="Female";}
else{$sex="Argh! No Profile!";}
$exp_bday=explode("-",$info[birthday]);
$month=$exp_bday[1];
$day=$exp_bday[2];
$main.="".starsign($day,$month)."<br/>\n";
$main.="<b>Asl:</b> ".flag($info[ipaddress]).getage($info[birthday])."/$sex/".getbbcode($info[location],$sid,1)."<br/>\n";
$main.="<b>Registered:</b> ".date("D jS M y",$info[regdate])."<br/>(".time_msg((time()-$info[regdate]),0).")<br/>
<b>Time Online:</b> ".time_msg($info[time],0)."<br/>
<b>Points:</b> $info[points]<br/>\n";
$main.="<b>A Bit About Me:</b> ".getbbcode($info[moreinfo],$sid,1)."<br/>
<b>Idle:</b> ".time_msg(time()-$info[lastact],0)."<br/>
<b>Browser:</b> $info[browser]<br/>\n";
if(user_info(getuid_sid($sid))){
$main.="<b>Ip Address:</b><br/>\n";
$main.="<small>(".network($info[ipaddress],"isp")." ".network($info[ipaddress],"country").")</small><br/>\n";
}
if(user_info(getuid_sid($sid))){
$main.="<a href=\"./profile.php?usersbyip=1&amp;who=$who&amp;sid=$sid\">[$info[ipaddress]]</a><br/>\n";
}
if(buds(getuid_sid($sid),$who)==0){
$main.="$Skey<a $keyS href=\"./buds/add.php?who=$who&amp;sid=$sid\">Add Buddy</a><br/>\n";
}else if(buds(getuid_sid($sid),$who)==1){
$main.="(Queued Buddy Request)<br/>\n";
}else if(buds(getuid_sid($sid),$who)==2){
$main.="$Skey<a $keyS href=\"./buds/add.php?delete=1&amp;who=$who&amp;sid=$sid\">Del Buddy</a><br/>\n";
}
if(buds(getuid_sid($sid),$who)==2){
$main.="$onekey<a $key1 href=\"./popups.php?who=$who&amp;sid=$sid$chatlink\">Send Popup</a><br/>\n";
}
$main.="$twokey<a $key2 href=\"./inbox/send.php?who=$who&amp;sid=$sid$chatlink\">Send Inbox</a><br/>\n";
if(ignored(getuid_sid($sid),$who,1)==1){
$main.="$threekey<a $key3 href=\"./block.php?add=1&amp;who=$who&amp;sid=$sid\">Block</a><br/>\n";
}else if(ignored(getuid_sid($sid),$who,1)==2){
$main.="$threekey<a $key3 href=\"./block.php?del=1&amp;who=$who&amp;sid=$sid\">Un-Block</a><br/>\n";
}
if($wapsite["mainpage"]!=""){
$main.="$fourkey<a $key4 href=\"./wapsites/wapsite.php?who=$who&amp;sid=$sid\">View Wapsite</a><br/>\n";
}
if($rid!=""){$main.="<br/>$fivekey<a $key5 href=\"./chat/chat.php?sid=$sid$chatlink\">Back to $rname</a>\n";}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>