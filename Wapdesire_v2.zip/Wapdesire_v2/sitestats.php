<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SITE STATS/////////////////////////

if($on2day==1){
addonline(getuid_sid($sid),"Site Stats","");
echo head_tag(getnick_sid($sid)."@Site Stats",1,getnick_sid($sid));
$title="Maximum number of users was online in the last 10 Days";
$main="<p align=".align().">";
$sql="SELECT ddt, dtm, ppl FROM mpot ORDER BY id DESC LIMIT 10";
$items=mysql_query($sql);
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
$main.="$item[0]($item[1]) Members: $item[2]<br/>";
}
}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Site Stats","");
echo head_tag(getnick_sid($sid)."@Site Stats",1,getnick_sid($sid));
$title="<b>Site Stats</b>";
$main="<p align=".align().">";
$norm=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users"));
$main.="Registered Members: <b>$norm[0]</b> ";
$memid=mysql_fetch_array(mysql_query("SELECT id, username FROM users ORDER BY regdate DESC LIMIT 0,1"));
$main.="The Newsest Member is: <b><a href=\"./profile.php?who=$memid[0]&amp;sid=$sid\">$memid[1]</a></b><br/>";
$mols=mysql_fetch_array(mysql_query("SELECT dtm, ppl, ddt FROM mpot WHERE ppl>'0' ORDER BY ppl DESC LIMIT 1"));
$main.="Most Users Online: <b>$mols[1]</b> $mols[0] - $mols[2]<br/>";
$mols=mysql_fetch_array(mysql_query("SELECT ppl, dtm FROM mpot WHERE ddt='".date("l jS F")."'"));
$main.="Most Users Online(<a href=\"./sitestats.php?on2day=1&amp;sid=$sid\"> For today only</a>): <b>$mols[0]</b> Members at $mols[1]<br/>";
$aut=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE lastact>'".(time()-(24*60*60))."'"));
$main.="Active users today <b>$aut[0]</b><br/>";
$notc=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics"));
$nops=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts"));
$main.="Number of Topics: <b>$notc[0]</b> - Number of Posts: <b>$nops[0]</b><br/>";
$nopm=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox"));
$main.="Number of Inboxes: <b>$nopm[0]</b><br/>";
$nopm=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM popups"));
$main.="Number of Popups: <b>$nopm[0]</b><br/>";
$nopm=mysql_fetch_array(mysql_query("SELECT value FROM settings WHERE name='Counter'"));
$main.="Counter: <b>$nopm[0]</b>";
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>