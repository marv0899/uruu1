<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////HANGMAN/////////////////////////

if($edit==1)
{
addonline(getuid_sid($sid),"Editing Hangman","");
echo head_tag(getnick_sid($sid)."@Edit Hangman",1,getnick_sid($sid));
$title="<b><i>Edit Hangman</i></b>";
if(game_tools(getuid_sid($sid))){
if($category!=""||$create==1)
{
$word=mysql_fetch_array(mysql_query("SELECT word1, word2, word3, word4, word5, word6, word7, word8, word9, word10, word11, word12, word13, word14, word15, word16, word17, word18, word19, word20 FROM games WHERE category='".$category."'"));
if($create==1){$word="";}
$main="<div class=".align().">
<form action=\"./hangman.php?save=1&amp;category=$category&amp;sid=$sid\" method=\"post\">
<b>Category:</b><br/><input name=\"cat\" maxlength=\"100\" value=\"$category\"/><br/>
<b>Word1:</b><br/>
<input name=\"word1\" maxlength=\"100\" value=\"$word[0]\"/><br/>
<b>Word2:</b><br/>
<input name=\"word2\" maxlength=\"100\" value=\"$word[1]\"/><br/>
<b>Word3:</b><br/>
<input name=\"word3\" maxlength=\"100\" value=\"$word[2]\"/><br/>
<b>Word4:</b><br/>
<input name=\"word4\" maxlength=\"100\" value=\"$word[3]\"/><br/>
<b>Word5:</b><br/>
<input name=\"word5\" maxlength=\"100\" value=\"$word[4]\"/><br/>
<b>Word6:</b><br/>
<input name=\"word6\" maxlength=\"100\" value=\"$word[5]\"/><br/>
<b>Word7:</b><br/>
<input name=\"word7\" maxlength=\"100\" value=\"$word[6]\"/><br/>
<b>Word8:</b><br/>
<input name=\"word8\" maxlength=\"100\" value=\"$word[7]\"/><br/>
<b>Word9:</b><br/>
<input name=\"word9\" maxlength=\"100\" value=\"$word[8]\"/><br/>
<b>Word10:</b><br/>
<input name=\"word10\" maxlength=\"100\" value=\"$word[9]\"/><br/>
<b>Word11:</b><br/>
<input name=\"word11\" maxlength=\"100\" value=\"$word[10]\"/><br/>
<b>Word12:</b><br/>
<input name=\"word12\" maxlength=\"100\" value=\"$word[11]\"/><br/>
<b>Word13:</b><br/>
<input name=\"word13\" maxlength=\"100\" value=\"$word[12]\"/><br/>
<b>Word14:</b><br/>
<input name=\"word14\" maxlength=\"100\" value=\"$word[13]\"/><br/>
<b>Word15:</b><br/>
<input name=\"word15\" maxlength=\"100\" value=\"$word[14]\"/><br/>
<b>Word16:</b><br/>
<input name=\"word16\" maxlength=\"100\" value=\"$word[15]\"/><br/>
<b>Word17:</b><br/>
<input name=\"word17\" maxlength=\"100\" value=\"$word[16]\"/><br/>
<b>Word18:</b><br/>
<input name=\"word18\" maxlength=\"100\" value=\"$word[17]\"/><br/>
<b>Word19:</b><br/>
<input name=\"word19\" maxlength=\"100\" value=\"$word[18]\"/><br/>
<b>Word20:</b><br/>
<input name=\"word20\" maxlength=\"100\" value=\"$word[19]\"/><br/>\n";
if($create==1){$main.="<input type=\"hidden\" name=\"create\" value=\"1\"/>\n";}
$main.="<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$main.="<p align=".align().">
<a href=\"./hangman.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$main="<p align=".align().">\n";
$cat=mysql_query("SELECT category FROM games WHERE (category!='gtn' AND category!='hangman' AND category!='wordscramble')");
$main.="<img src=\"../images/hang_6.gif\" alt=\"Hangman\"/><br/>
Edit a category:<br/>\n";
while($cat2=mysql_fetch_array($cat))
{
$main.="<a href=\"./hangman.php?edit=1&amp;category=$cat2[0]&amp;sid=$sid\">".$cat2[0]."</a> | 
<a href=\"./hangman.php?delete=1&amp;category=$cat2[0]&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[x]\"/></a><br/>\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="<br/>
<a href=\"./hangman.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save==1)
{
addonline(getuid_sid($sid),"Editing Hangman","");
echo head_tag(getnick_sid($sid)."@Editing Hangman",1,getnick_sid($sid));
$title="<b>Editing Hangman</b>";
$main="<p align=".align().">\n";
if(game_tools(getuid_sid($sid))){
$count_cat=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM games WHERE category='".$category."'"));
if($create!=1){
$res=mysql_query("UPDATE games SET category='".$cat."', word1='".$word1."', word2='".$word2."', 
word3='".$word3."', word4='".$word4."', word5='".$word5."', word6='".$word6."', word7='".$word7."', 
word8='".$word8."', word9='".$word9."', word10='".$word10."', word11='".$word11."', word12='".$word12."', word13='".$word13."', word14='".$word14."', word15='".$word15."', word16='".$word16."', word17='".$word17."', word18='".$word18."', word19='".$word19."', word20='".$word20."' WHERE category='".$category."' AND category!='wordscramble'");
}else{
$res=mysql_query("INSERT INTO games SET category='".$cat."', word1='".$word1."', word2='".$word2."', 
word3='".$word3."', word4='".$word4."', word5='".$word5."', word6='".$word6."', word7='".$word7."', 
word8='".$word8."', word9='".$word9."', word10='".$word10."', word11='".$word11."', 
word12='".$word12."', word13='".$word13."', word14='".$word14."', word15='".$word15."', word16='".$word16."', word17='".$word17."', word18='".$word18."', word19='".$word19."', word20='".$word20."'");
}
if($res){
mysql_query("UPDATE games SET active='0' WHERE category!='wordscramble'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>$category Was Saved Successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Error Saving Category\n";
}
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!\n";
}
$main.="</p>\n";
$L1="$fivekey<a $key5 href=\"./hangman.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Hangman Options","");
echo head_tag(getnick_sid($sid)."@Hangman Options",1,getnick_sid($sid));
$title="<b><i>Hangman Options</i></b>";
if(game_tools(getuid_sid($sid))){
$query="DELETE FROM games WHERE category='".$category."' AND category!='wordscramble'";
mysql_query($query);
$main="<p align=".align().">
<b>done!</b><br/>
<br/>Category $category was deleted.
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!
</p>\n";
}
$L1="$fivekey<a $key5 href=\"./hangman.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

else if($on==1)
{
addonline(getuid_sid($sid),"Hangman Options","");
echo head_tag(getnick_sid($sid)."@Hangman Options",1,getnick_sid($sid));
$title="<b><i>Hangman Options</i></b>";
if(game_tools(getuid_sid($sid))){
$query="UPDATE games SET active='1' WHERE category!='gtn' AND category!='hangman' AND category!='wordscramble'";
mysql_query($query);
$main="<p align=".align().">
<b>done!</b><br/>
<br/>hangman was activated, 
now all other users can participate.
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!
</p>\n";
}
$L1="$fivekey<a $key5 href=\"./hangman.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

else if($off==1)
{
addonline(getuid_sid($sid),"Hangman Options","");
echo head_tag(getnick_sid($sid)."@Hangman Options",1,getnick_sid($sid));
$title="<b><i>Hangman Options</i></b>";
if(game_tools(getuid_sid($sid))){
$query="UPDATE games SET active='0' WHERE category!='gtn' AND category!='hangman' AND category!='wordscramble'";
mysql_query($query);
$main="<p align=".align().">
<b>done!</b><br/>
<br/>hangman was deactivated, 
the link has disappeared from the main menu.
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!
</p>\n";
}
$L1="$fivekey<a $key5 href=\"./hangman.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Playing Hangman","");
echo head_tag(getnick_sid($sid)."@Hangman",1,getnick_sid($sid));
$title="<b><i>Hangman</i></b>";
$main="<p align=".align().">\n";
$cat=mysql_query("SELECT category FROM games WHERE (category!='gtn' AND category!='hangman' AND category!='wordscramble')");
if($category=="")
{
$main.="<img src=\"../images/hang_6.gif\" alt=\"Hangman\"/><br/>
Select a category:<br/>\n";
while($cat2=mysql_fetch_array($cat))
{
$main.="<a href=\"./hangman.php?category=$cat2[0]&amp;sid=$sid\">".$cat2[0]."</a><br/>\n";
}
$main.="<br/>\n";
if(game_tools(getuid_sid($sid))){
$main.="<a href=\"./hangman.php?edit=1&amp;create=1&amp;sid=$sid\">* Add Category *</a><br/>
<a href=\"./hangman.php?edit=1&amp;sid=$sid\">* Edit/Delete *</a><br/>\n";
$active=mysql_fetch_array(mysql_query("SELECT active FROM games WHERE category!='wordscramble' AND category!='gtn'"));
if($active[0]==1){
$main.="<a href=\"./hangman.php?off=1&amp;sid=$sid\">* Turn Off *</a><br/>\n";
}else{
$main.="<a href=\"./hangman.php?on=1&amp;sid=$sid\">* Turn On *</a><br/>\n";
}
}
$main.="<a href=\"./games.php?sid=$sid\">Back</a><br/>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
if($category!="")
{
$active=mysql_fetch_array(mysql_query("SELECT active FROM games WHERE category!='wordscramble' AND category!='gtn'"));
if($active[0]==0)
{
$main.="Hangman Is Currently Turned Off<br/>Please Try Again Soon<br/>Thank u<br/>
<br/>
<a href=\"./hangman.php?sid=$sid\">Back</a>
</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$additional_letters = " -.,;!?%& 0123456789/";
$uid=getuid_sid($sid);
$len_alpha=strlen($alpha);
if(isset($_GET["n"]))$n=$_GET["n"];
if(isset($_GET["letters"]))$letters=$_GET["letters"];
if(!isset($letters))$letters="";
if(isset($PHP_SELF))$self=$PHP_SELF;
else $self=$_SERVER["PHP_SELF"];
$links="";
$max=6;
# error_reporting(0);
$word=mysql_fetch_array(mysql_query("SELECT word1, word2, word3, word4, word5, word6, word7, word8, word9, word10, word11, word12, word13, word14, word15, word16, word17, word18, word19, word20 FROM games WHERE category='".$category."'"));
$words=array(strtoupper($word[0]),strtoupper($word[1]),strtoupper($word[2]),strtoupper($word[3]),strtoupper($word[4]),strtoupper($word[5]),strtoupper($word[6]),strtoupper($word[7]),strtoupper($word[8]),strtoupper($word[9]),strtoupper($word[10]),strtoupper($word[11]),strtoupper($word[12]),strtoupper($word[13]),strtoupper($word[14]),strtoupper($word[15]),strtoupper($word[16]),strtoupper($word[17]),strtoupper($word[18]),strtoupper($word[19]));
srand((double)microtime()*1000000);
$all_letters=$letters.$additional_letters;
$wrong=0;
if(!isset($n)){
$n=mt_rand(0,count($words));
mysql_query("DELETE FROM games WHERE category='hangman' AND uid='".$uid."'");
mysql_query("INSERT INTO games SET category='hangman', uid='".$uid."', word1='".$n."', word2='no'");
}
$word_line="";
$word=trim($words[$n]);
$done=1;
for($x=0;$x<strlen($word);$x++){
if(strstr($all_letters,$word[$x])){
if($word[$x]==" ")$word_line.=" / ";
else $word_line.=$word[$x];
}else{
$word_line.="_ ";
$done=0;
}
}
if(!$done)
{
for($c=0;$c<$len_alpha;$c++)
{
if(strstr($letters,$alpha[$c]))
{
if(strstr($words[$n],$alpha[$c]))
{
$links.="<b>$alpha[$c]</b> ";
}else{
$links.=" $alpha[$c] ";
$wrong++;
$get_wrong=$wrong;
}
}else{
$links.=" <a href=\"$self?category=$category&amp;letters=$alpha[$c]$letters&amp;n=$n&amp;get_w=".(0+$get_wrong)."&amp;sid=$sid\">$alpha[$c]</a> ";
}
}

$nwrong=$wrong;
if($nwrong>6)$nwrong=6;
$main.="<br/><img src=\"../images/hang_$nwrong.gif\" alt=\"Wrong: $wrong out of $max\"/><br/>";
if($wrong>=$max)
{
$n++;
if($n>(count($words)-1))$n=0;
$main.="<br/><br/>$word_line
<br/><br/><big>SORRY, YOU ARE HANGED!!!</big><br/><br/>";
if(strstr($word," "))$term="answer";
else $term="word";
$main.="The $term was \"<b>$word</b>\"<br/><br/>";
$sqlfetch=mysql_query("SELECT points FROM profiles WHERE uid='".$uid."'");
$sqlfet=mysql_fetch_array($sqlfetch);
$gplusnew=$sqlfet[0]-"25";
$sql="UPDATE profiles SET points='".$gplusnew."' WHERE uid='".$uid."'";
$res=mysql_query($sql);
mysql_query("DELETE FROM games WHERE uid='".$uid."' AND category='hangman'");
$main.="You Have Had 25 Points Deducted For Losing.<br/>
<a href=\"$self?category=$category&amp;sid=$sid\">Play again</a><br/>
<a href=\"$self?sid=$sid\">Change category</a>";
}else{
$main.=" Wrong Guesses Left: <b>".($max-$wrong)."</b><br/><br/>
$word_line
<br/><br/>Choose a letter:<br/>
$links";
}
}else{
$played=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM games WHERE uid='".$uid."' AND category='hangman' AND word2='yes'"));
if($played[0]>0){
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/><b>Error!!!</b><br/>
You cannot reload this page to gain more points DO NOT CHEAT!\n";
}else{
$n++;
# get next word
if($n>(count($words)-1))$n=0;
$main.="<br/><br/>\n$word_line
<br/><br/><b>Congratulations!!! You win!!!</b><br/><br/><br/>";
$sqlfetch=mysql_query("SELECT points FROM profiles WHERE uid='".$uid."'");
$sqlfet=mysql_fetch_array($sqlfetch);
if($get_w==0)$points=30;
else if($get_w==1)$points=25;
else if($get_w==2)$points=20;
else if($get_w==3)$points=15;
else if($get_w==4)$points=10;
else if($get_w==5)$points=5;
$gplusnew=$sqlfet[0]+$points;
mysql_query("UPDATE games SET word2='yes' WHERE uid='".$uid."' AND category='hangman'");
$sql="UPDATE profiles SET points='".$gplusnew."' WHERE uid='".$uid."'";
$res=mysql_query($sql);
$main.="You Have Had $points Points Added For Winning.<br/>
<a href=\"$self?category=$category&amp;sid=$sid\">Play again</a><br/>
<a href=\"$self?sid=$sid\">Change category</a>";
}
}
$main.="<br/>
<br/><a href=\"./hangman.php?sid=$sid\">Back</a>
</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
?>