<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////GUESS THE NUMBER/////////////////////////

addonline(getuid_sid($sid),"Playing Guess The Number","");
echo head_tag(getnick_sid($sid)."@Guess The Number",1,getnick_sid($sid));
$title="<b><i>Guess The Number</i></b>";
$main="<p align=".align().">\n";
if($gid==""){
mysql_query("DELETE FROM games WHERE uid='".getuid_sid($sid)."' AND category='gtn'");
mt_srand((double)microtime()*1000000);
$rn=mt_rand(1,100);
mysql_query("INSERT INTO games SET category='gtn', uid='".getuid_sid($sid)."', word1='8', word2='".$rn."'");
$tries=8;
//$gameid=mysql_fetch_array(mysql_query("SELECT category FROM games WHERE uid='".getuid_sid($sid)."'"));
$gid=getuid_sid($sid);
}else{
$ginfo=mysql_fetch_array(mysql_query("SELECT word1, word2 FROM games WHERE uid='".getuid_sid($sid)."' AND category='gtn'"));
$tries=$ginfo[0]-1;
mysql_query("UPDATE games SET word1='".$tries."' WHERE category='gtn' AND uid='".getuid_sid($sid)."'");
$rn=$ginfo[1];
}
if($tries>0){
$main.="<small>
Just try to guess the number before you have no more tries, 
the number is between 1-100
</small>
</p>\n";
$tries=$tries-1;
$gpl=$tries*3;
$main.="<p align=".align().">
Tries:$tries, Points:$gpl<br/><br/>";
if($un==$rn){
$gpl=$gpl+3;
$ugpl=mysql_fetch_array(mysql_query("SELECT points FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$ugpl=$gpl + $ugpl[0];
mysql_query("UPDATE profiles SET points='".$ugpl."' WHERE uid='".getuid_sid($sid)."'");
mysql_query("DELETE FROM games WHERE uid='".getuid_sid($sid)."' AND category='gtn'");
$main.="Congrats! the number was $rn, 
$gpl Points has been added to your Points, 
<a href=\"./gtn.php?sid=$sid\">New Game</a>\n";
}else{
if($un<$rn){
$main.="Try bigger number than $un !\n";
}else{
$main.="Try smaller number than $un !\n";
}
$main.="</p>
<div class=".align().">
<form action=\"./gtn.php?sid=$sid\" method=\"post\">
Your Guess: <input type=\"text\" name=\"un\" style=\"-wap-input-format: '*N'\" size=\"3\" value=\"$un\"/>
<input type=\"hidden\" name=\"gid\" value=\"$gid\"/>
<input type=\"submit\" name=\"try\" value=\"Try\">
</form>
</div>\n";
}
}else{
$main.="GAME OVER, The Number Was $un 
<a href=\"gtn.php?sid=$sid\">New Game</a>\n</p>\n";
}
$main.="<p align=".align().">
<a href=\"./games.php?sid=$sid\">Back</a><br/>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>