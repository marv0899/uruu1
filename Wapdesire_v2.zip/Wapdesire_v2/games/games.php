<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////GAMES/////////////////////////

addonline(getuid_sid($sid),"Games","");
echo head_tag(getnick_sid($sid)."@Games",1,getnick_sid($sid));
$title="<b><i>Games</i></b>";
$main="<p align=".align().">
Welcome To $sitename Games
</p>
<p align=".align().">
<a href=\"./gtn.php?sid=$sid\">Guess The Number</a><br/>
<a href=\"./hangman.php?sid=$sid\">Hang Man</a><br/>
<a href=\"./wordscramble.php?sid=$sid\">Word Scramble</a><br/>
<a href=\"./xogame.php?diff=e&amp;new=new&amp;sid=$sid\">X &amp; O</a><br/>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>