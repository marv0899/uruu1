<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////WORD SCRAMBLE/////////////////////////

addonline(getuid_sid($sid),"Playing Word Scramble","");
echo head_tag(getnick_sid($sid)."@Word Scramble",1,getnick_sid($sid));
$title="<b><i>Word Scramble</i></b>";

$answer=$_POST["answer"];
if(empty($_POST["answer"])){
srand((float)microtime()*10000000);

$input=mysql_fetch_array(mysql_query("SELECT word1, word2, word3, word4, word5, word6, word7, word8, word9, word10, word11, word12, word13, word14, word15, word16, word17, word18, word19, word20 FROM games WHERE category='wordscramble'"));

/*
$input=array(
"dictionary", 
"recognize",
"example",
"entertainment",
"experiment",
"appreciation",
"information",
"pronunciation",
"language",
"government",
"psychic",
"blueberry",
"selection",
"automatic",
"strawberry",
"bakery",
"shopping",
"eggplant",
"chicken",
"organic ",
"angel",
"season",
"market",
"information",
"complete",
"sunset",
"unique",
"customer"
);
*/
$rand_keys=array_rand($input,2);
$word=$input[$rand_keys[0]];
$Sword=str_shuffle($word);
$main="<p align=".align().">
$Sword
</p>
<p align=".align().">
In the text box below type the correct word that is scrambled above.</p>
<div class=".align().">
<form method=\"post\" action=\"./wordscramble.php?sid=$sid\">
<input type=\"text\" name=\"answer\" size=\"20\"/>
<input type=\"hidden\" name=\"correct\" value=\"$word\"/>
<input type=\"submit\" value=\"GO!\" name=\"B1\"/>
</form>
</div>\n";
}else{
$answer=strtolower($answer);
if($answer==$correct)
{
$result="Correct! <b>$answer</b>";
$uid=getuid_sid($sid);
$sqlfetch=mysql_query("SELECT points FROM profiles WHERE uid='".$uid."'");
$sqlfet=mysql_fetch_array($sqlfetch);
$gplusnew=$sqlfet[0]+"25";
$sql="UPDATE profiles SET points='".$gplusnew."' WHERE uid='".$uid."'";
$res=mysql_query($sql);
$main="<p align=".align().">
$result<br/>
You Have Had 25 game Plusses Added For Winning.
</p>
<p align=".align().">
<a href=\"./wordscramble.php?sid=$sid\">Try Another Word?</a>
</p>\n";
}else{
$result="Sorry! The Correct Answer Was <b>$correct</b>.";
$uid=getuid_sid($sid);
$sqlfetch=mysql_query("SELECT points FROM profiles WHERE uid='".$uid."'");
$sqlfet=mysql_fetch_array($sqlfetch);
$gplusnew=$sqlfet[0]-"25";
$sql="UPDATE profiles SET points='".$gplusnew."' WHERE uid='".$uid."'";
$res=mysql_query($sql);
$main="<p align=".align().">
$result<br/>
You Have Had 25 game Plusses Deducted For Losing.
</p>
<p align=".align().">
<a href=\"./wordscramble.php?sid=$sid\">Try Another Word?</a>
</p>\n";
}
}

$main.="<p align=".align().">
<a href=\"./games.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>