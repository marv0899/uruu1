<?php
define('WCS',true);
$ximage="../images/x.gif";
$ximagealt="x";
$oimage="../images/o.gif";
$oimagealt="o";
$qimage="../images/think.gif";
$qimagealt="?";
if(isset($new)||isset($again)){
session_start();
unset($b);
unset($turn);
unset($cdiff);
if($new=="new"){
unset($wins);
unset($losses);
unset($ties);
}
session_destroy();
}
session_start();
if(!isset($turn)){
session_register(turn);
$turn=1;
session_register(b);
session_register(wins);
session_register(losses);
session_register(ties);
session_register(cdiff);
if(!$wins)$wins=0;
if(!$losses)$losses=0;
if(!$ties)$ties=0;
if($diff=="e")$cdiff="Easy";
elseif($diff=="m")$cdiff="Normal";
elseif($diff=="h")$cdiff="Hard";
else $cdiff="Easy";
}

if(!isset($wins)){
session_register(wins);
$wins=0;
}else{
$wins=$wins;
}
global $wins, $losses, $ties;
global $b;
global $gwin;
global $gover;
if(isset($mv))$b[$mv]="x";
checkwin();
checkfull();
if($gover<>1&&$gwin==""&&$mv<>""){
if($cdiff=="Easy"){comprand();}
elseif($cdiff=="Normal"){
compmove();
if($cmv==""){comprand();}
}
elseif($cdiff=="Hard"){
compmove();
if($cmv==""){
if($b[4]=="")$cmv=4;
elseif($b[0]=="")$cmv=0;
elseif($b[2]=="")$cmv=2;
elseif($b[6]=="")$cmv=6;
elseif($b[8]=="")$cmv=8;
if($cmv=="")comprand();
}
}
$b[$cmv]="o";
}
checkwin();
checkfull();
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////GUESS THE NUMBER/////////////////////////

addonline(getuid_sid($sid),"Playing X and O","");
echo head_tag(getnick_sid($sid)."@X and O",1,getnick_sid($sid));
$title="<b><i>X and O</i></b><br/>\nyou are allways X";
$main="<div class=".align().">
<table border=\"1\" cellpadding=\"2\" cellspacing=\"3\">
<tr>\n";
for($i=0;$i<=8;$i++){
if($i==0||$i==3||$i==6)$main.="";
if($b[$i]=="x")$main.="<td width=\"20\">
<img src=\"$ximage\" alt=\"[$ximagealt]\"/>
</td>\n";
elseif($b[$i]=="o")$main.="<td width=\"20\">
<img src=\"$oimage\" alt=\"[$oimagealt]\"/>
</td>\n";
elseif($gwin=="")$main.="<td width=\"20\">
<a href=\"$PHP_SELF?mv=$i&amp;sid=$sid\"><img src=\"$qimage\" alt=\"[$qimagealt]\"/></a>
</td>\n";
else $main.="<td width=\"20\">
<img src=\"$qimage\" alt=\"[$qimagealt]\"/>
</td>\n";
if($i==2||$i==5)$main.="</tr>\n<tr>\n";
}
$main.="</table>
</div>\n";
if($gwin=="O"||$gwin=="X")$main.="<p align=".align().">
<b>$gwin won the game.</b><br/>\n";
elseif($gover==1){
$main.="<p align=".align().">
<b>NULL-play again.</b><br/>\n";
$ties=$ties+1;
}
if($gwin=="X"){
$points=mysql_fetch_array(mysql_query("SELECT points FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$sql="UPDATE profiles SET points='".($points[0]+25)."' WHERE uid='".getuid_sid($sid)."'";
$res=mysql_query($sql);
$main.="You have won 25 points for winning!!!<br/>\n";
$wins=$wins+1;
}
elseif($gwin=="O"){
$points=mysql_fetch_array(mysql_query("SELECT points FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$sql="UPDATE profiles SET points='".($points[0]-25)."' WHERE uid='".getuid_sid($sid)."'";
$res=mysql_query($sql);
$main.="You have lost 25 points for losing!!!<br/>\n";
$losses=$losses+1;
}
$main.="<br/>
<b>Wins:</b>$wins, <b>Losses:</b>$losses, <b>Ties:</b>$ties
</p>\n";
$main.="<div class=".align().">
<form action=\"$PHP_SELF\" method=\"get\">
*choose game:
<select name=\"diff\">
<option value=\"e\">easy</option>
<option value=\"m\">medium</option>
<option value=\"h\">hard</option>
</select>\n";
$main.="<input type=\"hidden\" name=\"new\" value=\"new\"/>\n";
$main.="<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>\n";
$main.="<input type=\"submit\" value=\"go\"/>
</form>
</div>\n";
$main.="<p align=".align().">
----------<br/>\n";
$main.="&lt;- <a href=\"./games.php?sid=$sid\">Back</a>
</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();

## functions:
function checkfull(){
global $b;
global $gover;
$gover=1;
for($ii=0;$ii<=8;$ii++){
if($b[$ii]==""){
$gover=0;
return;
}
}
}

function checkwin()
{
global $b;
global $gwin;
$c=1;
while($c<=2){
if($c==1)$t="o";
else $t="x";
if(($b[0]==$t&&$b[1]==$t&&$b[2]==$t)||($b[3]==$t&&$b[4]==$t&&$b[5]==$t)||($b[6]==$t&&$b[7]==$t&&$b[8]==$t)||
($b[0]==$t&&$b[3]==$t&&$b[6]==$t)||($b[1]==$t&&$b[4]==$t&&$b[7]==$t)||($b[2]==$t&&$b[5]==$t&&$b[8]==$t)||
($b[0]==$t&&$b[4]==$t&&$b[8]==$t)||($b[2]==$t&&$b[4]==$t&&$b[6]==$t)){
$gwin=strtoupper($t);
return;
}
$c++;
}
}

function compmove(){
global $cmv;
global $b;
for($c=0; $c<=1; $c++){
if($c==0)$t="o";
else $t="x";
if($b[0]==$t&&$b[1]==$t&&$b[2]=="")$cmv=2;
if($b[0]==$t&&$b[1]==""&&$b[2]==$t)$cmv=1;
if($b[0]==""&&$b[1]==$t&&$b[2]==$t)$cmv=0;
if($b[3]==$t&&$b[4]==$t&&$b[5]=="")$cmv=5;
if($b[3]==$t&&$b[4]==""&&$b[5]==$t)$cmv=4;		
if($b[3]==""&&$b[4]==$t&&$b[5]==$t)$cmv=3;
if($b[6]==$t&&$b[7]==$t&&$b[8]=="")$cmv=8;
if($b[6]==$t&&$b[7]==""&&$b[8]==$t)$cmv=7;		
if($b[6]==""&&$b[7]==$t&&$b[8]==$t)$cmv=6;
if($b[0]==$t&&$b[3]==$t&&$b[6]=="")$cmv=6;
if($b[0]==$t&&$b[3]==""&&$b[6]==$t)$cmv=3;		
if($b[0]==""&&$b[3]==$t&&$b[6]==$t)$cmv=0;
if($b[1]==$t&&$b[4]==$t&&$b[7]=="")$cmv=7;
if($b[1]==$t&&$b[4]==""&&$b[7]==$t)$cmv=4;		
if($b[1]==""&&$b[4]==$t&&$b[7]==$t)$cmv=1;
if($b[2]==$t&&$b[5]==$t&&$b[8]=="")$cmv=8;
if($b[2]==$t&&$b[5]==""&&$b[8]==$t)$cmv=5;		
if($b[2]==""&&$b[5]==$t&&$b[8]==$t)$cmv=2;
if($b[0]==$t&&$b[4]==$t&&$b[8]=="")$cmv=8;
if($b[0]==$t&&$b[4]==""&&$b[8]==$t)$cmv=4;		
if($b[0]==""&&$b[4]==$t&&$b[8]==$t)$cmv=0;
if($b[2]==$t&&$b[4]==$t&&$b[6]=="")$cmv=6;
if($b[2]==$t&&$b[4]==""&&$b[6]==$t)$cmv=4;		
if($b[2]==""&&$b[4]==$t&&$b[6]==$t)$cmv=2;
if($cmv<>"")break;
}
}

function comprand(){
global $b;
global $cmv;
srand((double)microtime()*1000000);
while(!isset($cmv)){
$test=rand(0,8);
if($b[$test]=="")$cmv=$test;
}	
}
?>