<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SETTINGS/////////////////////////

addonline(getuid_sid($sid),"Settings","");
echo head_tag(getnick_sid($sid)."@Settings",1,getnick_sid($sid));
$title="<b>Settings</b>";
$main="<p align=".align().">
<a href=\"./profile.php?sid=$sid\">Update Profile</a><br/>
<a href=\"./password.php?sid=$sid\">Update Password</a><br/>\n";
if($row_users[hidden]==0){$main.="<a href=\"./ghost.php?id=1&amp;sid=$sid\">Ghost Mode On</a><br/>\n";}
else{$main.="<a href=\"./ghost.php?id=0&amp;sid=$sid\">Ghost Mode Off</a><br/>\n";}
if($row_users[popups]==0){$main.="<a href=\"./popups.php?id=1&amp;sid=$sid\">Enable Popups</a><br/>\n";}
else{$main.="<a href=\"./popups.php?id=0&amp;sid=$sid\">Disable Popups</a><br/>\n";}
if($row_users[automsgs]==0){$main.="<a href=\"./automsgs.php?id=1&amp;sid=$sid\">Enable Auto Msgs</a><br/>\n";}
else{$main.="<a href=\"./automsgs.php?id=0&amp;sid=$sid\">Disable Auto Msgs</a><br/>\n";}
if($row_users[images]==0){$main.="<a href=\"../smilies/smilies.php?id=1&amp;sid=$sid\">Enable Smilies</a><br/>\n";}
else{$main.="<a href=\"../smilies/smilies.php?id=0&amp;sid=$sid\">Disable Smilies</a><br/>\n";}
$main.="<a href=\"../smilies/image.php?sid=$sid\">Change Site Image</a><br/>
<a href=\"./themes.php?sid=$sid\">Adjust Theme</a><br/>
<a href=\"../wapsites/update.php?sid=$sid\">Update Wapsite</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>