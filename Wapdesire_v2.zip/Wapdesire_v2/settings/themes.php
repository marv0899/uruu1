<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////THEMES/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Changing Theme","");
echo head_tag(getnick_sid($sid)."@Changing Theme",1,getnick_sid($sid));
$title="<b>Changing Theme</b>";
$main="<p align=".align().">";
if($body_bg==$body_txt){$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Main Background And Main Text Color Cannot Be Same!";}
else if($body_bg==$link_col){$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Main Background And Link Color Cannot Be Same!";}
else if($body_txt==$link_col){$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Main Text Color And Link Color Cannot Be Same!";}
else if($div_bg==$body_bg){$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Background Color And Top/Bottom Background Color Cannot Be Same!";}
else{
$res=mysql_query("UPDATE profiles SET body_background='".$body_bg."', body_text='".$body_txt."', border_color='".$brdr_col."', div_background='".$div_bg."', link_color='".$link_col."', font_size='".$font."' WHERE uid='".getuid_sid($sid)."'");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Theme Updated";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>".mysql_error()."<br/>Error Cannot Update Theme!";}
}
$main.="<br/>
<br/>$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Themes","");
echo head_tag(getnick_sid($sid)."@Themes",1,getnick_sid($sid));
$title="<b>select your background colour</b>";
$main="<p align=".align().">
Here you can change what colors u want to view the site in<br/>
u can always change things back if you dont like it :o)
</p>\n";
$main.="<div class=".align().">
<form action=\"themes.php?update=1&amp;sid=$sid\" method=\"post\">
<b>Main Background:</b><br/>
<select name=\"body_bg\">";
$query="select * from themes order by color";
$result=mysql_query($query);
while($body_bg=mysql_fetch_array($result)){
$color=$body_bg["color"];
$hex=$body_bg["hex"];
$text=$body_bg["text"];
if($row_profiles["body_background"]==$hex){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"$hex\" style=\"background-color:$hex;color:$text;\"$selected>$color</option>\n";
}
$main.="</select><br/>
<b>Main Text:</b><br/>
<select name=\"body_txt\">";
$query="select * from themes order by color";
$result=mysql_query($query);
while($body_txt=mysql_fetch_array($result)){
$color=$body_txt["color"];
$hex=$body_txt["hex"];
$text=$body_txt["text"];
if($row_profiles["body_text"]==$hex){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"$hex\" style=\"background-color:$hex;color:$text;\"$selected>$color</option>\n";
}
$main.="</select><br/>
<b>Top/Bottom Backgrounds:</b><br/>
<select name=\"div_bg\">";
$query="select * from themes order by color";
$result=mysql_query($query);
while($div_bg=mysql_fetch_array($result)){
$color=$div_bg["color"];
$hex=$div_bg["hex"];
$text=$div_bg["text"];
if($row_profiles["div_background"]==$hex){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"$hex\" style=\"background-color:$hex;color:$text;\"$selected>$color</option>\n";
}
$main.="</select><br/>
<b>Borders:</b><br/>
<select name=\"brdr_col\">";
$query="select * from themes order by color";
$result=mysql_query($query);
while($brdr_col=mysql_fetch_array($result)){
$color=$brdr_col["color"];
$hex=$brdr_col["hex"];
$text=$brdr_col["text"];
if($row_profiles["border_color"]==$hex){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"$hex\" style=\"background-color:$hex;color:$text;\"$selected>$color</option>\n";
}
$main.="</select><br/>
<b>Links:</b><br/>
<select name=\"link_col\">";
$query="select * from themes order by color";
$result=mysql_query($query);
while($link_col=mysql_fetch_array($result)){
$color=$link_col["color"];
$hex=$link_col["hex"];
$text=$link_col["text"];
if($row_profiles["link_color"]==$hex){$selected=" selected=\"selected\"";}else{$selected="";}
$main.="<option value=\"$hex\" style=\"background-color:$hex;color:$text;\"$selected>$color</option>\n";
}
if($row_profiles["font_size"]==medium){$font1=" selected=\"selected\"";}
else if($row_profiles["font_size"]==large){$font2=" selected=\"selected\"";}
$main.="</select><br/>
<b>Font Size:</b><br/>
<select name=\"font\">
<option value=\"small\" style=\"font-size: small;\">Small</option>
<option value=\"medium\" style=\"font-size: medium;\"$font1>Medium</option>
<option value=\"large\" style=\"font-size: large;\"$font2>Large</option>
</select><br/>
<input type=\"submit\" Value=\"Change\">
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>