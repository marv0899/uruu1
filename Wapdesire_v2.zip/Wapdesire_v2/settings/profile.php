<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////UPDATE PROFILE/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Updating Profile","");
echo head_tag(getnick_sid($sid)."@Update Profile",1,getnick_sid($sid));
$title="<b>Update Profile</b>";
$main="<p align=".align().">";
$res=mysql_query("UPDATE profiles SET picture='".$propic."', email='".$email."', birthday='".$year."-".$month."-".$day."', location='".$location."', moreinfo='".$moreinfo."', sex='".$sex."' WHERE uid='".getuid_sid($sid)."'");
if($email==""){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Email Cannot Be Blank<br/>
<br/>
<a href=\"./profile.php?sid=$sid\">Back</a>\n";
}else if($location==""){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Location Cannot Be Blank<br/>
<br/>
<a href=\"./profile.php?sid=$sid\">Back</a>\n";
}else if($moreinfo==""){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error More About Me Cannot Be Blank<br/>
<br/>
<a href=\"./profile.php?sid=$sid\">Back</a>\n";
}else if($sex==""){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Sex Cannot Be Blank<br/>
<br/>
<a href=\"./profile.php?sid=$sid\">Back</a>\n";
}else if($year==""||$month==""||$day==""){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error Date Of Birth Cannot Be Blank<br/>
<br/>
<a href=\"./profile.php?sid=$sid\">Back</a>\n";
}else if(getage($year."-".$month."-".$day)<15){
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>Error You Must Be 15+<br/>
<br/>
<a href=\"../index.php\">Exit</a>
</p>\n";
mysql_query("DELETE FROM profiles WHERE uid='".getuid_sid($sid)."'");
mysql_query("DELETE FROM users WHERE id='".getuid_sid($sid)."'");
}else if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Your profile was updated successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error updating your profile\n";
}
$main.="<br/>
<br/>$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Updating Profile","");
echo head_tag(getnick_sid($sid)."@Update Profile",1,getnick_sid($sid));
$title="<b>Update Profile</b>";
$avat=mysql_fetch_array(mysql_query("SELECT picture FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$email=mysql_fetch_array(mysql_query("SELECT email FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$bdy=mysql_fetch_array(mysql_query("SELECT birthday FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$uloc=mysql_fetch_array(mysql_query("SELECT location FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$usig=mysql_fetch_array(mysql_query("SELECT moreinfo FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$sx=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".getuid_sid($sid)."'"));
if($sx[0]=="F"){$selected=" selected=\"selected\"";}else{$selected="";}
$day=explode("-",$bdy[0]);$day=$day[2];
$month=explode("-",$bdy[0]);$month=$month[1];
$year=explode("-",$bdy[0]);$year=$year[0];
if($day=="01"){$day1=" selected=\"selected\"";}else{$day1="";}
if($day=="02"){$day2=" selected=\"selected\"";}else{$day2="";}
if($day=="03"){$day3=" selected=\"selected\"";}else{$day3="";}
if($day=="04"){$day4=" selected=\"selected\"";}else{$day4="";}
if($day=="05"){$day5=" selected=\"selected\"";}else{$day5="";}
if($day=="06"){$day6=" selected=\"selected\"";}else{$day6="";}
if($day=="07"){$day7=" selected=\"selected\"";}else{$day7="";}
if($day=="08"){$day8=" selected=\"selected\"";}else{$day8="";}
if($day=="09"){$day9=" selected=\"selected\"";}else{$day9="";}
if($day=="10"){$day10=" selected=\"selected\"";}else{$day10="";}
if($day=="11"){$day11=" selected=\"selected\"";}else{$day11="";}
if($day=="12"){$day12=" selected=\"selected\"";}else{$day12="";}
if($day=="13"){$day13=" selected=\"selected\"";}else{$day13="";}
if($day=="14"){$day14=" selected=\"selected\"";}else{$day14="";}
if($day=="15"){$day15=" selected=\"selected\"";}else{$day15="";}
if($day=="16"){$day16=" selected=\"selected\"";}else{$day16="";}
if($day=="17"){$day17=" selected=\"selected\"";}else{$day17="";}
if($day=="18"){$day18=" selected=\"selected\"";}else{$day18="";}
if($day=="19"){$day19=" selected=\"selected\"";}else{$day19="";}
if($day=="20"){$day20=" selected=\"selected\"";}else{$day20="";}
if($day=="21"){$day21=" selected=\"selected\"";}else{$day21="";}
if($day=="22"){$day22=" selected=\"selected\"";}else{$day22="";}
if($day=="23"){$day23=" selected=\"selected\"";}else{$day23="";}
if($day=="24"){$day24=" selected=\"selected\"";}else{$day24="";}
if($day=="25"){$day25=" selected=\"selected\"";}else{$day25="";}
if($day=="26"){$day26=" selected=\"selected\"";}else{$day26="";}
if($day=="27"){$day27=" selected=\"selected\"";}else{$day27="";}
if($day=="28"){$day28=" selected=\"selected\"";}else{$day28="";}
if($day=="29"){$day29=" selected=\"selected\"";}else{$day29="";}
if($day=="30"){$day30=" selected=\"selected\"";}else{$day30="";}
if($day=="31"){$day31=" selected=\"selected\"";}else{$day31="";}
if($month=="01"){$month1=" selected=\"selected\"";}else{$month1="";}
if($month=="02"){$month2=" selected=\"selected\"";}else{$month2="";}
if($month=="03"){$month3=" selected=\"selected\"";}else{$month3="";}
if($month=="04"){$month4=" selected=\"selected\"";}else{$month4="";}
if($month=="05"){$month5=" selected=\"selected\"";}else{$month5="";}
if($month=="06"){$month6=" selected=\"selected\"";}else{$month6="";}
if($month=="07"){$month7=" selected=\"selected\"";}else{$month7="";}
if($month=="08"){$month8=" selected=\"selected\"";}else{$month8="";}
if($month=="09"){$month9=" selected=\"selected\"";}else{$month9="";}
if($month=="10"){$month10=" selected=\"selected\"";}else{$month10="";}
if($month=="11"){$month11=" selected=\"selected\"";}else{$month11="";}
if($month=="12"){$month12=" selected=\"selected\"";}else{$month12="";}
if($year=="1991"){$year2=" selected=\"selected\"";}else{$year2="";}
if($year=="1990"){$year3=" selected=\"selected\"";}else{$year3="";}
if($year=="1989"){$year4=" selected=\"selected\"";}else{$year4="";}
if($year=="1988"){$year5=" selected=\"selected\"";}else{$year5="";}
if($year=="1987"){$year6=" selected=\"selected\"";}else{$year6="";}
if($year=="1986"){$year7=" selected=\"selected\"";}else{$year7="";}
if($year=="1985"){$year8=" selected=\"selected\"";}else{$year8="";}
if($year=="1984"){$year9=" selected=\"selected\"";}else{$year9="";}
if($year=="1983"){$year10=" selected=\"selected\"";}else{$year10="";}
if($year=="1982"){$year11=" selected=\"selected\"";}else{$year11="";}
if($year=="1981"){$year12=" selected=\"selected\"";}else{$year12="";}
if($year=="1980"){$year13=" selected=\"selected\"";}else{$year13="";}
if($year=="1979"){$year14=" selected=\"selected\"";}else{$year14="";}
if($year=="1978"){$year15=" selected=\"selected\"";}else{$year15="";}
if($year=="1977"){$year16=" selected=\"selected\"";}else{$year16="";}
if($year=="1976"){$year17=" selected=\"selected\"";}else{$year17="";}
if($year=="1975"){$year18=" selected=\"selected\"";}else{$year18="";}
if($year=="1974"){$year19=" selected=\"selected\"";}else{$year19="";}
if($year=="1973"){$year20=" selected=\"selected\"";}else{$year20="";}
if($year=="1972"){$year21=" selected=\"selected\"";}else{$year21="";}
if($year=="1971"){$year22=" selected=\"selected\"";}else{$year22="";}
if($year=="1970"){$year23=" selected=\"selected\"";}else{$year23="";}
if($year=="1969"){$year24=" selected=\"selected\"";}else{$year24="";}
if($year=="1968"){$year25=" selected=\"selected\"";}else{$year25="";}
if($year=="1967"){$year26=" selected=\"selected\"";}else{$year26="";}
if($year=="1966"){$year27=" selected=\"selected\"";}else{$year27="";}
$main="<div class=".align().">
<form action=\"profile.php?update=1&amp;sid=$sid\" method=\"post\">
Profile Pic: <input name=\"propic\" maxlength=\"100\" value=\"$avat[0]\"/><br/>
E-Mail: <input name=\"email\" maxlength=\"100\" value=\"$email[0]\"/><br/>
Date Of Birth: <select name=\"day\">
<option value=\"01\"$day1>1</option>
<option value=\"02\"$day2>2</option>
<option value=\"03\"$day3>3</option>
<option value=\"04\"$day4>4</option>
<option value=\"05\"$day5>5</option>
<option value=\"06\"$day6>6</option>
<option value=\"07\"$day7>7</option>
<option value=\"08\"$day8>8</option>
<option value=\"09\"$day9>9</option>
<option value=\"10\"$day10>10</option>
<option value=\"11\"$day11>11</option>
<option value=\"12\"$day12>12</option>
<option value=\"13\"$day13>13</option>
<option value=\"14\"$day14>14</option>
<option value=\"15\"$day15>15</option>
<option value=\"16\"$day16>16</option>
<option value=\"17\"$day17>17</option>
<option value=\"18\"$day18>18</option>
<option value=\"19\"$day19>19</option>
<option value=\"20\"$day20>20</option>
<option value=\"21\"$day21>21</option>
<option value=\"22\"$day22>22</option>
<option value=\"23\"$day23>23</option>
<option value=\"24\"$day24>24</option>
<option value=\"25\"$day25>25</option>
<option value=\"26\"$day26>26</option>
<option value=\"27\"$day27>27</option>
<option value=\"28\"$day28>28</option>
<option value=\"29\"$day29>29</option>
<option value=\"30\"$day30>30</option>
<option value=\"31\"$day31>31</option>
</select>
<select name=\"month\">
<option value=\"01\"$month1>Jan</option>
<option value=\"02\"$month2>Feb</option>
<option value=\"03\"$month3>Mar</option>
<option value=\"04\"$month4>Apr</option>
<option value=\"05\"$month5>May</option>
<option value=\"06\"$month6>Jun</option>
<option value=\"07\"$month7>Jul</option>
<option value=\"08\"$month8>Aug</option>
<option value=\"09\"$month9>Sep</option>
<option value=\"10\"$month10>Oct</option>
<option value=\"11\"$month11>Nov</option>
<option value=\"12\"$month12>Dec</option>
</select>
<select name=\"year\">
<option value=\"1991\"$year2>1991</option>
<option value=\"1990\"$year3>1990</option>
<option value=\"1989\"$year4>1989</option>
<option value=\"1988\"$year5>1988</option>
<option value=\"1987\"$year6>1987</option>
<option value=\"1986\"$year7>1986</option>
<option value=\"1985\"$year8>1985</option>
<option value=\"1984\"$year9>1984</option>
<option value=\"1983\"$year10>1983</option>
<option value=\"1982\"$year11>1982</option>
<option value=\"1981\"$year12>1981</option>
<option value=\"1980\"$year13>1980</option>
<option value=\"1979\"$year14>1979</option>
<option value=\"1978\"$year15>1978</option>
<option value=\"1977\"$year16>1977</option>
<option value=\"1976\"$year17>1976</option>
<option value=\"1975\"$year18>1975</option>
<option value=\"1974\"$year19>1974</option>
<option value=\"1973\"$year20>1973</option>
<option value=\"1972\"$year21>1972</option>
<option value=\"1971\"$year22>1971</option>
<option value=\"1970\"$year23>1970</option>
<option value=\"1969\"$year24>1969</option>
<option value=\"1968\"$year25>1968</option>
<option value=\"1967\"$year26>1967</option>
<option value=\"1966\"$year27>1966</option>
</select><br/>
Location: <input name=\"location\" maxlength=\"50\" value=\"".htmlspecialchars($uloc[0])."\"/><br/>
Info: <input name=\"moreinfo\" maxlength=\"100\" value=\"$usig[0]\"/><br/>
Sex: <select name=\"sex\">
<option value=\"M\">Male</option>
<option value=\"F\"$selected>Female</option>
</select><br/>
<input type=\"submit\" value=\"Update\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>