<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////PASSWORD/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Updating Password","");
echo head_tag(getnick_sid($sid)."@Updating Password",1,getnick_sid($sid));
$title="<b>Updating Password</b>";
$main="<p align=".align().">";
$password=mysql_fetch_array(mysql_query("SELECT password FROM users WHERE id='".getuid_sid($sid)."'"));
$email=mysql_fetch_array(mysql_query("SELECT email FROM profiles WHERE uid='".getuid_sid($sid)."'"));
if($password[0]==md5($cpwd)){
$res=mysql_query("UPDATE users SET password='".md5($npwd)."' WHERE id='".getuid_sid($sid)."'");
if($res){
mail($email[0], "Password updated for ".sitename(), "\n Username: ".getnick_sid($sid)." \n Password: ".$npwd, "From: ".getnick_uid(1)." <admin@".sitename().">\r\n"."Reply-To: admin@".sitename()."\r\n"."X-Mailer: PHP/".phpversion());
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Your password was updated successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Error updating your password\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Error current password is incorrect\n";
}
$main.="<br/>
<br/>$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Updating Password","");
echo head_tag(getnick_sid($sid)."@Update Password",1,getnick_sid($sid));
$title="<b>Update Password</b>";
$main="<div class=".align().">
<form action=\"./password.php?update=1&amp;sid=$sid\" method=\"post\">
Current Password: <input name=\"cpwd\" maxlength=\"10\"/><br/>
New Password: <input name=\"npwd\" maxlength=\"10\"/><br/>
<input type=\"submit\" value=\"Update\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./settings.php?sid=$sid\">Settings</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>