<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

$score=explode("/",$row_profiles["quiz_score"]);
$score=$score[0]+$score[1]+$score[2];
$images=$row_users["images"];
$quiz_easy=$row_profiles["quiz_easy"];
$quiz_medium=$row_profiles["quiz_medium"];
$quiz_hard=$row_profiles["quiz_hard"];
addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
$title="<b><i>Quiz</i></b><br/>please select level of difficulty";
$main="<p align=".align().">\n";
if($row_quiz["switch"]==on||(quiz_tools(getuid_sid($sid))&&$preview==yes)){
if($quiz_easy=="no")$main.="<a style=\"color: blue;\" href=\"./questions.php?sid=$sid&amp;q=1&amp;dif=easy&amp;start=yes\">easy</a><br/>\n";
else if($quiz_easy=="yes")$main.="<span style=\"color: blue;\"><b>** completed **</b></span><br/>\n";
if($quiz_medium=="no")$main.="<a style=\"color: green;\" href=\"./questions.php?sid=$sid&amp;q=1&amp;dif=med&amp;start=yes\">medium</a><br/>\n";
elseif($quiz_medium=="yes")$main.="<span style=\"color: green;\"><b>** completed **</b></span><br/>\n";
if($quiz_hard=="no")$main.="<a style=\"color: red;\" href=\"./questions.php?sid=$sid&amp;q=1&amp;dif=hard&amp;start=yes\">hard</a><br/>\n";
else if($quiz_hard=="yes")$main.="<span style=\"color: red;\"><b>** completed **</b></span><br/>\n";
if(($quiz_hard=="yes")&&($quiz_easy=="yes")&&($quiz_medium=="yes")){
$main.="<b>you have answered all the questions for this week, please try again next week!</b><br/>\n";
}
$main.="<br/><b>your current score is $score</b>\n";
}else{
$main.="Quiz Is Currently Turned Off Please Come Back Later\n";
}
$main.="</p>\n";
$L1="$fivekey<a $key5 href=\"./quiz.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
?>