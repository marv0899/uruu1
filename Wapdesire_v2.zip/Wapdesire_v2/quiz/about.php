<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
$images=$row_users["images"];
if($images=="1"){$title="<img src=\"../images/quiz.gif\" alt=\"Quiz\"/>";}
else{$title="<b><i>Quiz</i></b>";}
$main="<p align=".align().">
Welcome To $sitename Quiz
</p>
<p align=".align().">
this is a multiple choice quiz, each question has 4 possible answers.<br/><br/>
for each question you get right, you get points, 
the points you get depend on the difficulty level you've selected:<br/>
<span style=\"color: blue;\"><b>easy = 10 points</b></span><br/>
<span style=\"color: green;\"><b>medium = 20 points</b></span><br/>
<span style=\"color: red;\"><b>hard = 30 points</b></span><br/>
but, each time you get a question wrong, you lose the <span style=\"color: blue;\">10</span>, 
<span style=\"color: green;\">20</span> or 
<span style=\"color: red;\">30</span> points depending on the difficulty level you selected, 
and don't think it stops at zero, oh no, if you get your very first question wrong, 
you'll need to get the next one right to return to zero.
</p>";
$L1="<fivekey<a $key5 href=\"./quiz.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
?>