<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

if($save==1)
{
addonline(getuid_sid($sid),"Quiz Options","");
echo head_tag(getnick_sid($sid)."@Quiz Options",1,getnick_sid($sid));
$title="<b><i>Quiz Options</i></b>";
$main="<p align=".align().">\n";
$query="UPDATE quiz SET question='$nquestion' where number=$q AND difficulty='$diff'";
mysql_query($query);
$query="UPDATE quiz SET answer='$nright' where number=$q AND difficulty='$diff'";
mysql_query($query);
$query="UPDATE quiz SET answer1='$na' where number=$q AND difficulty='$diff'";
mysql_query($query);
$query="UPDATE quiz SET answer2='$nb' where number=$q AND difficulty='$diff'";
mysql_query($query);
$query="UPDATE quiz SET answer3='$nc' where number=$q AND difficulty='$diff'";
mysql_query($query);
$query="UPDATE quiz SET answer4='$nd' where number=$q AND difficulty='$diff'";
mysql_query($query);
$next=($q+1);
if($next<=10){
$main.="<b>done!</b><br/>
<br/>question $q was updated<br/>
<b>question:</b><br/>$nquestion<br/>
<b>right answer:</b><br/>$nright<br/>
<br/><b>answer 1:</b><br/>$na<br/>
<b>answer 2:</b><br/>$nb<br/>
<b>answer 3:</b><br/>$nc<br/>
<b>answer 4:</b><br/>$nd<br/>
<br/><a href=\"./edit.php?q=$next&amp;diff=$diff&amp;sid=$sid\">Question $next</a>\n";

}else{
$main.="<b>done!</b><br/>
<br/>that was the last $diff question, 
taking you back to quiz admin..<br/>
<br/><b>question:</b><br/>$nquestion<br/>
<b>right answer:</b><br/>$nright<br/>
<br/><b>answer 1:</b><br/>$na<br/>
<b>answer 2:</b><br/>$nb<br/>
<b>answer 3:</b><br/>$nc<br/>
<b>answer 4:</b><br/>$nd\n";
}
$L1="$fivekey<a $key5 href=\"./admin.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Quiz Options","");
echo head_tag(getnick_sid($sid)."@Quiz Options",1,getnick_sid($sid));
$title="<b><i>Quiz Options</i></b>";
$main="<p align=".align().">\n";
$query="select * FROM quiz WHERE difficulty='$diff' AND number='$q'";
$result=mysql_query($query);
$num_rows=mysql_num_rows($result);
$row=mysql_fetch_array($result);
$question=$row["question"];
$correct=$row["answer"];
$a=$row["answer1"];
$b=$row["answer2"];
$c=$row["answer3"];
$d=$row["answer4"];
$id=$row["id"];
$main.="<b>edit question $q<br/>[difficulty: $diff]</b>
</p>
<div class=".align().">
<form action=\"./edit.php?save=1&amp;q=$q&amp;diff=$diff&amp;sid=$sid\" method=\"post\">
<br/>question:<br/>
<input type=\"text\" name=\"nquestion\" value=\"$question\" maxlength=\"100\"/>
<br/>correct answer:<br/>
<input type=\"text\" name=\"nright\" value=\"$correct\" maxlength=\"100\"/><br/>
<br/>one of the answers below must be the same case and spelling as the correct answer
<br/>answer 1:<br/>
<input type=\"text\" name=\"na\" value=\"$a\" maxlength=\"100\"/><br/>
answer 2:<br/>
<input type=\"text\" name=\"nb\" value=\"$b\" maxlength=\"100\"/><br/>
answer 3:<br/>
<input type=\"text\" name=\"nc\" value=\"$c\" maxlength=\"100\"/><br/>
answer 4:<br/>
<input type=\"text\" name=\"nd\" value=\"$d\" maxlength=\"100\"/><br/>
<input type=\"submit\" value=\"update\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"./admin.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
?>