<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

if($losers==1)
{
addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT count(*) from profiles where total_score<'0'"));
if(!$num_items[0])$num_items[0]=0;
$title="<b>$num_items[0] players failed miserably</b>";
$main="<p align=".align().">\n";
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items[0]==0)$limit_start=0;
$sql="SELECT * FROM profiles WHERE total_score<'0' ORDER BY total_score DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
$main.=mysql_error();
if($num_items[0]!=0){
while($item=mysql_fetch_array($items)){
$main.="<i><b>".getnick_uid($item["uid"])."</b></i><br/>".$item["quiz_score"]."<br/>\n";
}
}
if($page>1){
$main.="<br/><a href=\"./scores.php?losers=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./scores.php?losers=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("scores","","",$sid);}
$L1="$fivekey<a $key5 href=\"./quiz.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT count(*) from profiles where total_score>'0'"));
if(!$num_items[0])$num_items[0]=0;
$title="<b>$num_items[0] players made the leaderboard</b>";
$main="<p align=".align().">\n";
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items[0]==0)$limit_start=0;
$sql="SELECT * FROM profiles WHERE total_score>'0' ORDER BY total_score DESC LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
$main.=mysql_error();
if($num_items[0]!=0){
while($item=mysql_fetch_array($items)){
$main.="<i><b>".getnick_uid($item["uid"])."</b></i><br/>".$item["quiz_score"]."<br/>\n";
}
}
if($page>1){
$main.="<br/><a href=\"./scores.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./scores.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("scores","","",$sid);}
$L1="$fivekey<a $key5 href=\"./quiz.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
?>