<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

if($on==1)
{
addonline(getuid_sid($sid),"Quiz Options","");
echo head_tag(getnick_sid($sid)."@Quiz Options",1,getnick_sid($sid));
$title="<b><i>Quiz Options</i></b>";
$query="UPDATE quiz SET switch='on'";
mysql_query($query);
$main="<p align=".align().">
<b>done!</b><br/>
<br/>the quiz was activated, 
now all other users can participate.
</p>\n";
$L1="$fivekey<a $key5 href=\"./admin.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

else if($off==1)
{
addonline(getuid_sid($sid),"Quiz Options","");
echo head_tag(getnick_sid($sid)."@Quiz Options",1,getnick_sid($sid));
$title="<b><i>Quiz Options</i></b>";
$query="UPDATE quiz SET switch='off'";
mysql_query($query);
$main="<p align=".align().">
<b>done!</b><br/>
<br/>the quiz was deactivated, 
the link has disappeared from the main menu.
</p>\n";
$L1="$fivekey<a $key5 href=\"./admin.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

else if($reset==1) 
{
addonline(getuid_sid($sid),"Quiz Options","");
echo head_tag(getnick_sid($sid)."@Quiz Options",1,getnick_sid($sid));
$title="<b><i>Quiz Options</i></b>";
$query="UPDATE profiles SET quiz_easy='no'";
mysql_query($query);
$query="UPDATE profiles SET quiz_medium='no'";
mysql_query($query);
$query="UPDATE profiles SET quiz_hard='no'";
mysql_query($query);
$query="UPDATE profiles SET quiz_score='0/0/0', total_score='0'";
mysql_query($query);
$query="delete from quizusers where uid!=0";
mysql_query($query);
$main="<p align=".align().">
<b>done!</b><br/>
<br/>all sections will now appear as unplayed for all users.
</p>\n";
$L1="$fivekey<a $key5 href=\"./admin.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Quiz Options","");
echo head_tag(getnick_sid($sid)."@Quiz Options",1,getnick_sid($sid));
$title="<b><i>Quiz Options</i></b>";
$main="<p align=".align().">
Please select the set of questions you wish to edit<br/>
<a href=\"./edit.php?q=1&amp;diff=easy&amp;sid=$sid\" style=\"color:blue;\">easy</a><br/>
<a href=\"./edit.php?q=1&amp;diff=med&amp;sid=$sid\" style=\"color:green;\">medium</a><br/>
<a href=\"./edit.php?q=1&amp;diff=hard&amp;sid=$sid\" style=\"color:red;\">hard</a><br/>
<br/><a href=\"./play.php?preview=yes&amp;sid=$sid\">preview</a><br/>
<i>lastly, you'll want to make sure ALL users can play,<br/>
when a user completes a section, it appears as *complete*, you need to click below, 
after each update, 
before turning the quiz back on.</i><br/>
<br/><a href=\"./admin.php?reset=1&amp;sid=$sid\">Reset Scores</a><br/>\n";
if($row_quiz["switch"]=="on"){
$main.="<br/><b>Quiz is active<br/><a href=\"./admin.php?off=1&amp;sid=$sid\">turn it off?</a></b>\n";
}else{
$main.="<br/><b>Quiz is not active<br/><a href=\"./admin.php?on=1&amp;sid=$sid\">turn it on?</a></b>\n";
}
$main.="</p>\n";
$L1="$fivekey<a $key5 href=\"./quiz.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
?>