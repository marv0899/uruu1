<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
$title="<b><i>Quiz</i></b>";
$main="<p align=".align().">
Welcome To $sitename Quiz
</p>
<p align=".align().">
<a href=\"./play.php?sid=$sid\">Play</a><br/>
<a href=\"./about.php?sid=$sid\">About</a><br/>
<a href=\"./scores.php?sid=$sid\">Top Scorers</a><br/>
<a href=\"./scores.php?losers=1&amp;sid=$sid\">Top Losers</a><br/>";
$count_score=mysql_fetch_array(mysql_query("SELECT count(*) from profiles where total_score<'0'"));
$count_score1=$count_score[0];
$count_score=mysql_fetch_array(mysql_query("SELECT count(*) from profiles where total_score>'0'"));
$count_score2=$count_score[0];
$countup=($count_score1+$count_score2);
$main.="<br/>$countup people have taken part in Quiz";
if(quiz_tools(getuid_sid($sid))){$main.="<br/><a href=\"./admin.php?sid=$sid&amp;update=yes\">Update</a>";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>