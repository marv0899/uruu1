<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
$tmax=$row_ses["tmax"];
$totalscore=explode("/",$row_profiles["quiz_score"]);
$row_quiz=mysql_fetch_array(mysql_query("select * from quiz where id='$quid'"));
$row_quizusers=mysql_fetch_array(mysql_query("select * from quizusers where uid='".getuid_sid($sid)."'"));
$correct = $row_quiz["answer"];
$ga = $row_quiz["answer1"];
$gb = $row_quiz["answer2"];
$gc = $row_quiz["answer3"];
$gd = $row_quiz["answer4"];
if($a=="a")$guess="$ga";
else if($a=="b")$guess="$gb";
else if($a=="c")$guess="$gc";
else if($a=="d")$guess="$gd";
if($row_quizusers[$l."_next"]!=$q){
$title="<b>Cheater!</b>";
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/><b>Error!!!</b><br/>
You cannot reload this page to gain more points DO NOT CHEAT!
</p>\n";
$L1="$fivekey<a $key5 href=\"./play.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}
else if($guess=="$correct"){
mysql_query("update quizusers set ".$l."_question='".$q."', ".$l."_next='".($q+1)."' where uid='".getuid_sid($sid)."'");
if($l=="easy")$plus="10";
else if($l=="med")$plus="20";
else if($l=="hard")$plus="30";
$next=($q+1);
if($l==easy){
$total_score=($totalscore[0]+$plus)."/".$totalscore[1]."/".$totalscore[2];
$total=($totalscore[0]+$plus)+$totalscore[1]+$totalscore[2];
}else if($l==med){
$total_score=$totalscore[0]."/".($totalscore[1]+$plus)."/".$totalscore[2];
$total=$totalscore[0]+($totalscore[1]+$plus)+$totalscore[2];
}else if($l==hard){
$total_score=$totalscore[0]."/".$totalscore[1]."/".($totalscore[2]+$plus);
$total=($totalscore[0]+$plus)+$totalscore[1]+($totalscore[2]+$plus);
}
mysql_query("update profiles set quiz_score='".$total_score."', total_score='".$total."' where uid='".getuid_sid($sid)."'");
$title="<b>Correct!</b>";
$main="<p align=".align().">
<i>you got the right answer, $plus points were added to your score.</i><br/>";
if($q<10){
$main.="<br/><a href=\"./questions.php?sid=$sid&amp;q=$next&amp;dif=$l\">go to question $next</a><br/>";
}
else if($q==10){
if($l=="easy"){
mysql_query("update profiles set quiz_easy='yes' where uid='".getuid_sid($sid)."'");
}
else if($l=="med"){
mysql_query("update profiles set quiz_medium='yes' where uid='".getuid_sid($sid)."'");
}
else if($l=="hard"){
mysql_query("update profiles set quiz_hard='yes' where uid='".getuid_sid($sid)."'");
}
$main.="<br/>you've completed this round.<br/>
<a href=\"./play.php?sid=$sid\">select difficulty</a><br/>";
}
$main.="</p>";
$L1="$fivekey<a $key5 href=\"./play.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}
else
{
if($l=="easy")$plus="10";
else if($l=="med")$plus="20";
else if($l=="hard")$plus="30";
if($l==easy){
$total_score=($totalscore[0]-$plus)."/".$totalscore[1]."/".$totalscore[2];
$total=($totalscore[0]-$plus)+$totalscore[1]+$totalscore[2];
}else if($l==med){
$total_score=$totalscore[0]."/".($totalscore[1]-$plus)."/".$totalscore[2];
$total=$totalscore[0]+($totalscore[1]-$plus)+$totalscore[2];
}else if($l==hard){
$total_score=$totalscore[0]."/".$totalscore[1]."/".($totalscore[2]-$plus);
$total=($totalscore[0]+$plus)+$totalscore[1]+($totalscore[2]-$plus);
}
mysql_query("update profiles set quiz_score='".$total_score."', total_score='".$total."' where uid='".getuid_sid($sid)."'");
$title="<b>Wrong!!</b>";
$main="<p align=".align().">
<i>your answer was wrong, $plus points were deducted from your score.</i><br/>
</p>
<p align=".align().">
-&gt; <a href=\"./questions.php?sid=$sid&amp;q=$q&amp;dif=$l\">try question $q again</a><br/>
</p>";
$L1="$fivekey<a $key5 href=\"./play.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
}
?>