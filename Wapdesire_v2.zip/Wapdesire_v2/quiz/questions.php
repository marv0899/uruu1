<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

addonline(getuid_sid($sid),"Quiz","");
echo head_tag(getnick_sid($sid)."@Quiz",1,getnick_sid($sid));
$row_quizusers=mysql_fetch_array(mysql_query("select * from quizusers where uid='".getuid_sid($sid)."'"));
if($row_quizusers[$dif."_question"]!=0){$q=$row_quizusers[$dif."_next"];}
$row_quiz=mysql_fetch_array(mysql_query("SELECT * FROM quiz WHERE difficulty='".$dif."' AND number='".$q."'"));
if($start=yes){
mysql_query("insert into quizusers set easy_question='".$q."', easy_next='".$q."', med_question='".$q."', med_next='".$q."', hard_question='".$q."', hard_next='".$q."', uid='".getuid_sid($sid)."'");
}
$question = $row_quiz["question"];
$a = $row_quiz["answer1"];
$b = $row_quiz["answer2"];
$c = $row_quiz["answer3"];
$d = $row_quiz["answer4"];
$q = $row_quiz["number"];
$quid = $row_quiz["id"];
$l = $row_quiz["difficulty"];
$title="<b>Question $q</b>";
$main="<p align=".align().">
<b>$question</b>
</p>
<p align=".align().">
<i><a href=\"./answer.php?sid=$sid&amp;q=$q&amp;a=a&amp;quid=$quid&amp;l=$l\">$a</a></i><br/>
<i><a href=\"./answer.php?sid=$sid&amp;q=$q&amp;a=b&amp;quid=$quid&amp;l=$l\">$b</a></i><br/>
<i><a href=\"./answer.php?sid=$sid&amp;q=$q&amp;a=c&amp;quid=$quid&amp;l=$l\">$c</a></i><br/>
<i><a href=\"./answer.php?sid=$sid&amp;q=$q&amp;a=d&amp;quid=$quid&amp;l=$l\">$d</a></i>";
$main.="</p>";
$L1="$fivekey<a $key5 href=\"./quiz.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
?>