<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////BLOCK/////////////////////////

addonline(getuid_sid($sid),"Blocking User","");
echo head_tag(getnick_sid($sid)."@Blocking User",1,getnick_sid($sid));
$title="<b>Blocking User</b>";
$main="<p align=".align().">\n";
if($add==1){
if(ignored(getuid_sid($sid),$who,1)==1){
$res=mysql_query("INSERT INTO ignored SET uid='".getuid_sid($sid)."', tid='".$who."'");
if($res){
$main.="<img src=\"./images/ok.gif\" alt=\"[o]\"/>".getnick_uid($who)." Cannot Send You Msgs Now<br/>";
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>Error Updating Database<br/>";
}
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>You Cant Block ".getnick_uid($who)."<br/>";
}
}else if($del==1){
if(ignored(getuid_sid($sid),$who,1)==2){
$res=mysql_query("DELETE FROM ignored WHERE uid='".getuid_sid($sid)."' AND tid='".$who."'");
if($res){
$main.="<img src=\"./images/ok.gif\" alt=\"[o]\"/>".getnick_uid($who)." Can Now Send You Msgs<br/>";
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>Error Updating Database<br/>";
}
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>".getnick_uid($who)." Is Not Blocked By You<br/>";
}
}
$main.="<br/>\n<a href=\"./profile.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>