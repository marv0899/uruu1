<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////GET FILE/////////////////////////

addonline(getuid_sid($sid),"Downloading File","");
echo head_tag(getnick_sid($sid)."@Downloading File",1,getnick_sid($sid));
$title="<b><i>Downloading File</i></b>";
$path=mysql_fetch_array(mysql_query("SELECT path, hits FROM download_files WHERE id='".$id."'"));
$get_path=explode("/downloads/",$path[0]);
$filename=$get_path[1];
$download=$get_path[0]."/downloads/".$filename;
$res=mysql_query("UPDATE download_files SET hits='".($path[1]+1)."' WHERE id='".$id."'");
$main="<p align=".align().">
<meta http-equiv=Refresh content=1;url=".$download.">
If Your Download Does Not Start In 5 seconds Click below
<a href=\"".$download."\">Get File</a>
</p>\n";
$main.="<p align=".align().">
<a href=\"./downloads.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>