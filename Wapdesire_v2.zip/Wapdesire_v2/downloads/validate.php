<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VALIDATE DOWNLOAD/////////////////////////

addonline(getuid_sid($sid),"Validating Download","");
echo head_tag(getnick_sid($sid)."@Validating Download",1,getnick_sid($sid));
$title="<b><i>Validating Download</i></b>";
if(download_tools(getuid_sid($sid))){
$file=mysql_fetch_array(mysql_query("SELECT filename, path FROM download_files WHERE id='".$id."'"));
$filename=explode("downloads/",$file[1]);
$query="UPDATE download_files SET active='1' WHERE id='".$id."'";
mysql_query($query);
mysql_query("INSERT INTO logs SET action='Downloads', details='<b>".getnick_sid($sid)."</b> Validated The File <b>".$file[0].".".getext($filename[1])."</b>', date='".time()."'");
$filename2=str_replace(" ","",$filename[1]);
rename(md5($file[0]).".".getext($filename2),str_replace(" ","",$file[0]).".".getext($filename[1]));
$main="<p align=".align().">
<b>done!</b><br/>
<br/>File $file[0].".getext($filename[1])." was validated.
</p>\n";
}else{
addonline(getuid_sid($sid),"In The Forbidden Zone!","");
$main.="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><br/>Permission Denied!
</p>\n";
}
$main.="<p align=".align().">$fivekey<a $key5 href=\"./downloads.php?sid=$sid\">Back</a></p>\n";
$L1="$fivekey<a $key5 href=\"./hangman.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L6,0,0,0,$main);
echo foot_tag();
exit;
?>