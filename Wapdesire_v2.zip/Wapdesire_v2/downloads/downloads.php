<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////DOWNLOADS/////////////////////////

addonline(getuid_sid($sid),"Downloads","");
echo head_tag(getnick_sid($sid)."@Downloads",1,getnick_sid($sid));
$title="<b><i>Downloads</i></b>";
$main="<p align=".align().">
Welcome To $sitename Downloads
</p>\n";
$main.="<p align=".align().">\n";
$cat=mysql_query("SELECT id, name, description FROM download_categories WHERE name!=''");
$main.="<a href=\"./topfiles.php?sid=$sid\">Top 20 Downloads</a><br/>
<br/>
Select a category:<br/>\n";
while($cat2=mysql_fetch_array($cat))
{
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM download_files WHERE category='".$cat2[0]."'"));
$inactive_files=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM download_files WHERE category='".$cat2[0]."' AND active='0' AND id!='0'"));
if(download_tools(getuid_sid($sid))&&$inactive_files[0]>0){$inactive=" ! $inactive_files[0]";}
else{$inactive="";}
$main.="<a href=\"./viewcategory.php?id=$cat2[0]&amp;sid=$sid\">".$cat2[1]." ".$num_items[0]."</a>$inactive<br/>\n";
if(download_tools(getuid_sid($sid))){
$main.="<a href=\"./edit.php?id=$cat2[0]&amp;sid=$sid\"><small>* Edit/Delete *</small></a><br/>\n";
}
$main.="<small>$cat2[2]</small><br/>\n";
}
$main.="<br/>
<a href=\"./upload.php?sid=$sid\">Add Your Files</a>";
if(download_tools(getuid_sid($sid))){
$main.="<br/>
<a href=\"./create.php?sid=$sid\">* Create Category *</a>";
}
$main.="\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>