<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW CATEGORY/////////////////////////

addonline(getuid_sid($sid),"Downloads","");
echo head_tag(getnick_sid($sid)."@Downloads",1,getnick_sid($sid));
$title="<b><i>Downloads</i></b>";
$main="<p align=".align().">
Welcome To $sitename Downloads<br/>\n";
$active=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM download_categories WHERE id='".$id."' AND active='0'"));
if($active[0]==1){
$main.="<p align=".align().">This Category Is Currently Disabled.</p>\n";
$main.="<p align=".align().">$fivekey<a $key5 href=\"./downloads.php?sid=$sid\">Back</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM download_files WHERE category='".$id."'"));
if($num_items[0]==0)$num_items[0]=0;
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items[0]==0)$limit_start=0;
$sql="SELECT id, filename, description, uid, active, path, hits FROM download_files WHERE category='".$id."' LIMIT $limit_start, $items_per_page";
$items=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items))
{
$file=explode("downloads/",$item[5]);
if($item[4]==1){
if(filesize($file[1])>1048575){
$size=round(filesize($file[1])/1048576,1)." Mb";
}else if(filesize($file[1])>1023){
$size=round(filesize($file[1])/1024,1)." Kb";
}else{
$size=filesize($file[1])." Bytes";
}
$main.="<br/><a href=\"./get.php?id=$item[0]&amp;sid=$sid\">$item[1].".getext($file[1])."</a> $size\n";
if(download_tools(getuid_sid($sid))){
$main.=" <a href=\"./delete.php?id=$item[0]&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[delete]\"/></a>";
}
$main.="<br/>
$item[2]<br/>
<small>$item[6] Downloads<br/>
(Uploaded By: <a href=\"../profile.php?who=$item[3]&amp;sid=$sid\">".getnick_uid($item[3])."</a>)</small><br/>\n";
}else{
//$file=explode("downloads/",$item[5]);
//$file2=explode(".",$file[1]);
//$file3=md5($file2[0]).".".getext($file[1]);
$file3=md5($item[1]).".".getext($file[1]);
if(filesize($file3)>1048575){
$size=round(filesize($file3)/1048576,1)." Mb";
}else if(filesize($file3)>1023){
$size=round(filesize($file3)/1024,1)." Kb";
}else{
$size=filesize($file3)." Bytes";
}
$main.="<br/>$item[1].".getext($file[1])." $size\n";
if(download_tools(getuid_sid($sid))){
$main.="<a href=\"./".md5($item[1]).".".getext($file[1])."\">-&gt;Download</a> ";
$main.=" <a href=\"./delete.php?id=$item[0]&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[delete]\"/></a>";
$main.=" <a href=\"./validate.php?id=$item[0]&amp;sid=$sid\"><img src=\"../images/ok.gif\" alt=\"[validate]\"/></a>";
}
$main.="<br/>
<small>(File Being Processed If This Dnt Complete Contact An Admin)<br/>
$item[6] Downloads</small><br/>\n";
}
}
if($page>1){
$main.="<br/><a href=\"./viewcategory.php?id=$id&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./viewcategory.php?id=$id&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("viewcategory","id","$id",$sid);}
}else{
$main.="<br/>There Are No Downloads Atm...
</p>\n";
}
$main.="<p align=".align().">$fivekey<a $key5 href=\"./downloads.php?sid=$sid\">Back</a></p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
?>