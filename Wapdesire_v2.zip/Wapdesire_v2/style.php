<?php
define('WCS',true);
header("Content-type: text/css");
header("Cache-Control: no-cache, must-revalidate");
include('./core/main.inc');
$row_profiles=mysql_fetch_array(mysql_query("select * from profiles where uid='".getuid_nick($uid)."'"));
$body_background=$row_profiles["body_background"];
$body_text=$row_profiles["body_text"];
$font_size=$row_profiles["font_size"];
$border_color=$row_profiles["border_color"];
$div_background=$row_profiles["div_background"];
$link_color=$row_profiles["link_color"];
if(!$row_profiles["uid"]){
$body_background="#FFFFFF";
$body_text="#000000";
$font_size="medium";
$border_color="#0000FF";
$div_background="#000000";
$link_color="#0000FF";
}
?>

body {background-color:<?=$body_background?>;
font-family : Comic Sans MS;
font-size:<?=$font_size?>;
margin: 0px;
padding: 1px;
color:<?=$body_text?>;}
p {padding:0px;}
input, select {color:<?=$link_color?>;
border: 1px ridge <?=$border_color?>;
font-family: Comic Sans MS, Tahoma, Verdana;
font-weight: bold;
background-color:<?=$body_background?>;}
* {text-decoration:none;}
img {border: 0px none;}
a, a:active, a:visited, a:hover {color:<?=$link_color?>;}
head {font-family : Comic Sans MS;
font-size:<?=$font_size?>;}
.div {margin: 2px 0px 2px 0px;
padding: 2px 0px 2px 0px;
color:<?=$body_background?>;
background-color:<?=$div_background?>;
border: 1px solid <?=$border_color?>;
text-align: center;}
.center {text-align: center;}
.left {text-align: left;}
.link {color:<?=$extlink?>;}
