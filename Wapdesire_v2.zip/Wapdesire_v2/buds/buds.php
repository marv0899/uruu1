<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////BUDDYLIST/////////////////////////

addonline(getuid_sid($sid),"BuddyList","buds/buds.php");
echo head_tag(getnick_sid($sid)."@BuddyList",1,getnick_sid($sid));
$mood=mysql_fetch_array(mysql_query("SELECT mood FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$title="<b>BuddyList</b>";
if($mood!="")$title.="<br/>".getbbcode($mood[0],$sid,1);
if($count_popup[0]>0){
$rname=mysql_fetch_array(mysql_query("SELECT name FROM chatrooms WHERE id='".$rid."'"));
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$style="style=\"color:#0000FF\"";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$style="style=\"color:#FF0066\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main="<div class=".align().">
<b>Popup Message<br/>
From $usersex<span $style>".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"../popups.php?send=1&amp;who=$pminfo[2]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>\n";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$main.="<p align=".align().">
<a href=\"../$location[0]?sid=$sid\">Skip Msg</a><br/>\n";
//$main.="<a href=\"inbxproc.php?action=rptpop&amp;sid=$sid&amp;pmid=$pminfo[0]\">Report</a><br/>";
if($rid!=""){$main.="<a href=\"../chat/chat.php?sid=$sid&amp;rid=$rid$pass\">Back To $rname[0]</a><br/>\n";}
}else{
$main="<p align=".align().">\n";
}
$requests=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM buds WHERE tid='".getuid_sid($sid)."' AND agreed='0'"));
if($requests[0]>0){$main.="<a href=\"requests.php?sid=$sid\">Request Waiting!</a><br/><br/>";}
if($page==""||$page<=0)$page=1;
$num_items=online_buds(getuid_sid($sid));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if($num_pages==0)$num_pages=$page;
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if(!ghosts(getuid_sid($sid))){$hidden="AND a.hidden='0' ";}
else{$hidden="AND a.hidden<'2' ";}
$sql="SELECT a.id, a.username, d.mood, b.uid, b.tid, b.date FROM users a 
INNER JOIN buds b ON (a.id=b.uid) OR (a.id=b.tid) 
INNER JOIN online c ON (a.id=c.uid) INNER JOIN profiles d ON (a.id=d.uid) 
WHERE (b.uid='".getuid_sid($sid)."' OR b.tid='".getuid_sid($sid)."') $hidden
AND b.agreed='1' AND a.id!='".getuid_sid($sid)."' ORDER BY a.username 
DESC LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
if(($siteimage[0]!="")){$iml=getbbcode($siteimage[0],$sid,1);}
$bmsg=getbbcode($item[2],$sid,1);
if($bmsg!=""){$budmood="($bmsg)";}
else{$budmood="";}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='$item[0]'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color=" style=\"color:#0000FF\"";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color=" style=\"color:#FF0066\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main.="$usersex<a href=\"../profile.php?who=$item[0]&amp;sid=$sid\"$color>$item[1]</a>$budmood<br/>";
}
if($page>1){
$main.="<br/><a href=\"./buds.php?page=".($page-1)."&amp;sid=$sid\">&lt;- Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./buds.php?page=".($page+1)."&amp;sid=$sid\">Next -&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>";
if($num_pages>2){$main.=getjumper("buds","","",$sid);}
}else{
$main.="No Buds Online</p>";
}
$main.="<p align=".align().">
$onekey<a $key1 href=\"./buds.php?sid=$sid\">Refresh</a><br/>
$twokey<a $key2 href=\"../inbox/inbox.php?action=popupto&amp;sid=$sid\">Send Popup</a><br/>
$threekey<a $key3 href=\"./mood.php?sid=$sid\">Change Mood</a><br/>";
$popmsgs=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
if($popmsgs[0]==0){
$main.="$fourkey<a $key4 href=\"../settings/popups.php?id=1&amp;sid=$sid\">Enable Popups</a><br/>";
}else{
$main.="$fourkey<a $key4 href=\"../settings/popups.php?id=0&amp;sid=$sid\">Disable Popups</a><br/>";
}
$main.="$fivekey<a $key5 href=\"./dialog.php?sid=$sid\">Popup Dialog</a><br/>
$sixkey<a $key6 href=\"./offline.php?sid=$sid\">Offline Buds</a>
</p>";
$L1="$sevenkey<a $key7 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L3="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L4="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,0,0,0,0,$main);
echo foot_tag();
?>