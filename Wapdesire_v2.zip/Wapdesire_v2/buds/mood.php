<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MOOD/////////////////////////

if($update==1)
{
addonline(getuid_sid($sid),"Changing Mood","");
echo head_tag(getnick_sid($sid)."@Changing Mood",1,getnick_sid($sid));
$title="<b>Changing Mood</b>";
$main="<p align=".align().">\n";
$res=mysql_query("UPDATE profiles SET mood='".$mood."', site_mood='".$site_mood."' WHERE uid='".getuid_sid($sid)."'");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Your mood has been updated\n";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Database Error!\n";}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Changing Mood","");
echo head_tag(getnick_sid($sid)."@Changing Mood",1,getnick_sid($sid));
$mood=mysql_fetch_array(mysql_query("SELECT mood FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$title="<b>Change Mood</b>";
if($mood!="")$title.="<br/>".getbbcode($mood[0],$sid,1);
$mood=mysql_fetch_array(mysql_query("SELECT mood FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$main="<div class=".align().">
<form action=\"mood.php?update=1&amp;sid=$sid\" method=\"post\">
<b>mood:</b> <i>$mood[0]</i><br/>
<small>(20 Chars Max!)</small><br/>
<input name=\"mood\" maxlength=\"20\" value=\"$mood[0]\"/><br/>
<b>Option:</b><br/>
<select name=\"site_mood\">
<option value=\"0\">Buddies Only</option>
<option value=\"1\">Everyone</option>
</select><br/>
<input type=\"Submit\" Value=\"Change\">
</form>
</div>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();

/*

*/
?>