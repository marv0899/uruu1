<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////POPUP DIALOG/////////////////////////

addonline(getuid_sid($sid),"Popup Dialog","");
$nick=getnick_sid($sid);
echo head_tag($nick."@Popup Dialog",1,$nick);
$title="<b>Popup Dialog</b>";
$main="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$pms=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM popups WHERE toid='".getuid_sid($sid)."' ORDER BY timesent"));
$main.=mysql_error();
$num_items=$pms[0];
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if($num_items>0){
$pms=mysql_query("SELECT byid, text, timesent, toid FROM popups WHERE toid='".getuid_sid($sid)."' ORDER BY timesent DESC LIMIT $limit_start, $items_per_page");
while($pm=mysql_fetch_array($pms))
{
if(isonline($pm[0])){$iml="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
if(isonline($pm[3])){$iml2="<img src=\"../images/onl.gif\" alt=\"+\"/>";}
else{$iml2="<img src=\"../images/ofl.gif\" alt=\"-\"/>";}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='$pm[3]'"));
$sex2=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='$pm[0]'"));
if($sex[0]=="M"){$color=" style=\"color:#0000FF\"";}
else if($sex[0]=="F"){$color=" style=\"color:#FF0066\"";}
if($sex2[0]=="M"){$color2=" style=\"color:#0000FF\"";}
else if($sex2[0]=="F"){$color2=" style=\"color:#FF0066\"";}
$main.="<a href=\"../profile.php?who=$pm[0]&amp;sid=$sid\"$color2>$iml".getnick_uid($pm[0])."</a>
<img src=\"../images/in.gif\" alt=\"-&gt;\"/>
<a href=\"../profile.php?who=$pm[3]&amp;sid=$sid\"$color>$iml2".getnick_uid($pm[3])."</a><br/>
<small>(".date("d m y - h:i:s",$pm[2]).")</small><br/>
".getbbcode($pm[1],$sid,1)."
<br/>--------------<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./dialog.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./dialog.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("dialog","","",$sid);}
}
else{$main.="No Popups</p>\n";}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>