<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ADD BUDDY/////////////////////////

if($accept==1)
{
addonline(getuid_sid($sid),"Accepting Request","");
echo head_tag(getnick_sid($sid)."@Accepting Request",1,getnick_sid($sid));
$title="<b>Accepting Request</b>";
$main="<p align=".align().">";
if(buds(getuid_sid($sid),$who)==1){
$res=mysql_query("UPDATE buds SET agreed='1' WHERE uid='".$who."' AND tid='".getuid_sid($sid)."'");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>You have accepted ".getnick_uid($who)." into your buddylist";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't add ".getnick_uid($who)." to your buddylist!";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't add ".getnick_uid($who)." to your buddylist!";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($deny==1)
{
addonline(getuid_sid($sid),"Dennying Request","");
echo head_tag(getnick_sid($sid)."@Denny Request",1,getnick_sid($sid));
$title="<b>Denny Request</b>";
$main="<p align=".align().">";
if(buds(getuid_sid($sid),$who)==1){
$res=mysql_query("DELETE FROM buds WHERE agreed='0' AND uid='".$who."' AND tid='".getuid_sid($sid)."'");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>You have dennied ".getnick_uid($who)."";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't Deny ".getnick_uid($who)."!";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't Deny ".getnick_uid($who)."!";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Deleting Buddy","");
echo head_tag(getnick_sid($sid)."@Deleting Buddy",1,getnick_sid($sid));
$title="<b>Deleting Buddy</b>";
$main="<p align=".align().">";
if(buds(getuid_sid($sid),$who)==2){
$res=mysql_query("DELETE FROM buds WHERE agreed='1' AND (uid='".$who."' OR uid='".getuid_sid($sid)."') AND (tid='".$who."' OR tid='".getuid_sid($sid)."')");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>You have deleted ".getnick_uid($who)." from your buddylist";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't delete ".getnick_uid($who)." from your buddylist!";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't delete ".getnick_uid($who)." from your buddylist!";}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Adding Buddy","");
echo head_tag(getnick_sid($sid)."@Add Buddy",1,getnick_sid($sid));
$title="<b>Add Buddy</b>";
$main="<p align=".align().">";
if(ignored(getuid_sid($sid),$who,1)==2){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
Cannot buddy ".getnick_uid($who)." they have ignored you...
</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}
if(buds(getuid_sid($sid),$who)!=3){
if(buds(getuid_sid($sid),$who)==2){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>".getnick_uid($who)." is already in your buddylist!";
}
else if(buds(getuid_sid($sid),$who)==0){
$res=mysql_query("INSERT INTO buds SET uid='".getuid_sid($sid)."', tid='".$who."', date='".time()."'");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>A request has been sent to ".getnick_uid($who)."";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't add ".getnick_uid($who)." to your buddylist!";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>You can't add ".getnick_uid($who)." to your buddylist";}
}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>