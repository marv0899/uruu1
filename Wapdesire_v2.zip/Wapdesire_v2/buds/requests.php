<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////REQUESTS/////////////////////////

addonline(getuid_sid($sid),"Viewing Requests","");
echo head_tag(getnick_sid($sid)."@Viewing Requests",1,getnick_sid($sid));
$title="<b>Viewing Requests</b><br/>You have ".($max_buds-total_buds(getuid_sid($sid)))." Places left";
$main="<p align=".align().">";
$main.="The following members want you to add them to your buddy list<br/>";
if($page==""||$page<=0)$page=1;
$nor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM buds WHERE tid='".getuid_sid($sid)."' AND agreed='0'"));
$num_items=$nor[0];
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&($page!=1))$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="
SELECT uid FROM buds WHERE tid='".getuid_sid($sid)."' 
AND agreed='0' ORDER BY date DESC LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
echo mysql_error();
if(mysql_num_rows($items)>0){
while($item=mysql_fetch_array($items)){
$main.="<a href=\"../profile.php?who=$item[0]&amp;sid=$sid\">".getnick_uid($item[0])."</a>: 
<a href=\"./add.php?accept=1&amp;who=$item[0]&amp;sid=$sid\">Accept</a>, 
<a href=\"./add.php?deny=1&amp;who=$item[0]&amp;sid=$sid\">Deny</a><br/>";
}
}
if($page>1){
$main.="<br/><a href=\"./requests.php?page=".($page-1)."&amp;sid=$sid\">&lt;- Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./requests.php?page=".($page+1)."&amp;sid=$sid\">Next -&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>";
if($num_pages>2){$main.=getjumper("requests","","",$sid);}
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>