<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////OFFLINE BUDDYS/////////////////////////

addonline(getuid_sid($sid),"BuddyList","");
echo head_tag(getnick_sid($sid)."@Offline Buds",1,getnick_sid($sid));
$title="<b>Offline Buds</b>";
$main="<p align=".align().">";
if($page==""||$page<=0)$page=1;
$num_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM buds WHERE (uid='".getuid_sid($sid)."' OR tid='".getuid_sid($sid)."') AND agreed='1'"));
$items_per_page=10;
$num_pages=ceil($num_items[0]/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT a.id, a.username FROM users a 
INNER JOIN buds b ON a.id=b.uid OR a.id=b.tid 
WHERE ((b.uid='".getuid_sid($sid)."') 
OR (b.tid='".getuid_sid($sid)."')) 
AND b.agreed='1' AND a.id!='".getuid_sid($sid)."' ORDER BY a.username 
LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
$main.=mysql_error();
if(mysql_num_rows($items)>0){
while ($item=mysql_fetch_array($items)){
if(!isonline($item[0])){
$sex=mysql_fetch_array(mysql_query("SELECT sex, image, mood FROM profiles WHERE uid='".$item[0]."'"));
$bmsg=getbbcode($sex[2],$sid,1);
if($bmsg!=""){$budmood="($bmsg)";}
else{$budmood="";}
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color=" style=\"color:#0000FF\"";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color=" style=\"color:#FF0066\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main.="$usersex<a href=\"../profile.php?who=$item[0]&amp;sid=$sid\"$color>$item[1]</a>$budmood<br/>";
}
}
if($page>1){
$main.="<br/><a href=\"./offline.php?page=".($page-1)."&amp;sid=$sid\">&lt;- Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./offline.php?page=".($page+1)."&amp;sid=$sid\">Next- &gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>";
if($num_pages>2){$main.=getjumper("offline","","",$sid);}
}else{
$main.="No Buds Offline</p>";
}
$main.="<p align=".align().">
$onekey<a $key1 href=\"buds.php?sid=$sid\">Online Buds</a><br/>
$twokey<a $key2 href=\"index.php?action=chbmsg&amp;sid=$sid\">Change Mood</a><br/>";
$popmsgs=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
if($popmsgs[0]==0){$main.="$threekey<a $key3 href=\"../settings/popups.php?id=1&amp;sid=$sid\">Enable Popups</a><br/>";}
else{$main.="$threekey<a $key3 href=\"../settings/popups.php?id=0&amp;sid=$sid\">Disable Popups</a><br/>";}
$main.="$fourkey<a $key4 href=\"popups.php?action=dialog&amp;sid=$sid\">Popup Dialog</a>
</p>";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>