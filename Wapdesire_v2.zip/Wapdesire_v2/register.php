<?php
define('WCS',true);
include("./core/main.inc");
header_type();
if((!registration())||(ipbanned(ip(),browser()))){
echo head_tag("Error!!!",0,0);
$title="<img src=\"./images/error.gif\" alt=\"x\"/><br/><b>Error!!!</b>";
$main="<p align=".align().">Registration is closed at the moment</p>";
$L1="&lt;- $zerokey<a $key0 href=\"./index.php\"><img src=\"./images/home.gif\"/>Back</a>";
echo xhtml($sid,$title,1,$L1,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
if($action=="do"){
echo head_tag(sitename(),0,0);
$title="<b>Registration Failed</b>";
$main="<p align=".align().">";
$L1="&lt;- <a href=\"./register.php?uid=$uid&amp;pwd=$pwd&amp;usx=$usx&amp;email=$email\">Back</a>";
if(trim($uid)==""){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Pls type your username";}
else if(trim($pwd)==""){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Pls type your password";}
else if(spacesin($uid)||scharin($uid)){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Username can't contain special characters or spaces";}
else if(spacesin($pwd)||scharin($pwd)){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Password can't contain special characters or spaces";}
else if(strlen($uid)<3){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Username must be 3 characters or more";}
else if(strlen($pwd)<3){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Password must be 3 characters or more";}
else if(isdigitf($uid)){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Username must start with a number 0-9 or a letter from a-z";}
else if(checknick($uid)==1){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>This username was banned and deleted if this was not u then please choose another username";}
else if(checknick($uid)==2){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Please choose an appropriate username";}
else if(trim($email)==""){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>U must enter an email address";}
else if(register($uid,$pwd,$usx,$email)==1){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Username is taken";}
else if(register($uid,$pwd,$usx,$email)==2){$main.="<img src=\"images/point.gif\" alt=\"!\"/><br/>Unknown error pls try again l8r<br/>";$errl.=mysql_error();}
else{
$main.="
<b>Username: </b>$uid<br/>
<b>Password: </b>$pwd<br/><br/>
";
if(validation()){
$main.="
Please give us up to 12hrs to validate you<br/>
(normally it be done within an hour)<br/>
if you have not been after this period of time u can email the owner at:<br/>
$emailaddress
";
}
mail($email, 
"Registration details for ".sitename(), "<b>Username:</b> ".$uid."
<b>Password:</b> ".$pwd."

".sitename()." is a nice friendly chat community we are glad to hav u with us :o) pls feel free to bring ya m8s along

<b>Thank You
".sitename()."</b>", "From: admin@".sitename()."\r
Reply-To: admin@wapdesire.com\r
X-Mailer: PHP/".phpversion());
$title="<img src=\"images/ok.gif\" alt=\"o\"/><br/><b>Registration completed successfully!</b>";
$L1="$onekey<a $key1 href=\"./login.php?username=$uid&amp;password=$pwd\">Login</a>";
$L2="$zerokey<a $key0 href=\"./index.php\"><img src=\"images/home.gif\" alt=\"\"/>Back</a>";
}
$main.="</p>";
echo xhtml($sid,$title,1,$L1,$L2,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
echo head_tag(sitename(),0,0);
$title="<b>Registration Form</b>";
$main="
<p align=".align().">
<img src=\"./images/point.gif\" alt=\"!\"/>Allowed characters in username and password are a-z, 0-9, and -_<br/>
<img src=\"./images/point.gif\" alt=\"!\"/>This site is for 15s and over only anyone under the age of 15 will be blocked<br/>
<img src=\"./images/point.gif\" alt=\"!\"/>Username and password must contain at least 3 characters<br/>
<img src=\"./images/point.gif\" alt=\"!\"/>Username must not begin with any symbols<br/>
<img src=\"./images/point.gif\" alt=\"!\"/>Username and password must not contain capitals
</p>
<div class=".align().">
<form action=\"./register.php\" method=\"post\">
<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/><br/>
<b>Username:</b><br/><input name=\"uid\" style=\"-wap-input-format: '*x'\" maxlength=\"12\" size=\"12\" value=\"$uid\"/><br/>
<b>Password:</b><br/><input type=\"password\" name=\"pwd\" maxlength=\"10\" size=\"10\" value=\"$pwd\"/><br/>
<b>Sex:</b><br/>
<select name=\"usx\">
<option value=\"M\">Male</option>
<option value=\"F\"$selected>Female</option>
</select><br/>
<b>Email:</b><br/><input name=\"email\" maxlength=\"50\" value=\"$email\"/><br/>
<input type=\"hidden\" name=\"action\" value=\"do\"/>
<input type=\"submit\" value=\"Register\"/><br/>
<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/>
</form>
</div>
";
$L1="$zerokey<a $key0 href=\"index.php\"><img src=\"images/home.gif\" alt=\"\"/>Back</a>";
echo xhtml($sid,$title,1,$L1,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>
