<?php
define('WCS',true);
include('./core/main.inc');
header_type();
addvisitor();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}

/////////////////////////COPYRIGHT/////////////////////////

echo head_tag(sitename(),0,0);
$title="<img src=\"./images/copyright.jpg\" alt=\"&#169;".date("Y")."\"/><br/>
<b>Copyright &#169; ".date("Y")." Chris Anderson &amp; Frank Grant. All rights reserved.</b>";
$main="<p align=\"center\">
All scripts and site content including logos and banners are the property of chris anderson<br/>
any use of such content can only be done with the written concent of chris<br/>
they are protected by copyright laws,
any further information can be sent via the address down the bottom thank u.<br/>
<br/>
<a href=\"http://afta-dark.net\">Afta-Dark.Net</a>
</p>\n";
$L1="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
if(!islogged($sid)){$L1="&lt;- $zerokey<a $key0 href=\"./index.php\">Back</a>";}
echo xhtml($sid,$title,1,$L1,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>