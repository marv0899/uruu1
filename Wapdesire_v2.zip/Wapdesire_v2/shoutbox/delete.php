<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(shoutbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo shoutbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////DELETE SHOUT/////////////////////////

addonline(getuid_sid($sid),"Deleting Shout","");
echo head_tag(getnick_sid($sid)."@Shoutbox",1,getnick_sid($sid));
$title="<b>Delete Shout</b>";
$main="<p align=".align().">";
$sht=mysql_fetch_array(mysql_query("SELECT uid, shout, id FROM shouts WHERE id='".$delete."'"));
if(!delshout(getuid_sid($sid),$sht[2])){
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Permission Denied!\n";
}else{
$msg=getnick_uid($sht[0]);
$msg.=": ".htmlspecialchars((strlen($sht[1])<20?$sht[1]:substr($sht[1], 0, 20)));
$res=mysql_query("DELETE FROM shouts WHERE id ='".$delete."'");
if($res){
mysql_query("INSERT INTO logs SET action='shouts', details='<b>".getnick_sid($sid)."</b> Deleted the shout <b>".$delete."</b> - $msg', date='".time()."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>Shout deleted\n";
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Database Error\n";}
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>