<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(shoutbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo shoutbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ADD SHOUT/////////////////////////

addonline(getuid_sid($sid),"Shouting","");
echo head_tag(getnick_sid($sid)."@Shoutbox",1,getnick_sid($sid));
$title="<b>Add Shout</b>";
$main="<p align=".align().">\n";
if(points(getuid_sid($sid))<15){
$need=15-points(getuid_sid($sid));
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
You need $need more points to shout!
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
if(!blocked_site($shtxt,$uid)){
$res=mysql_query("INSERT INTO shouts SET shout='".$shtxt."', uid='".getuid_sid($sid)."', shtime='".time()."'");
$hehe=mysql_fetch_array(mysql_query("SELECT shouts FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$totl=$hehe[0]+1;
$msgst=mysql_query("UPDATE profiles SET shouts='".$totl."' WHERE uid='".getuid_sid($sid)."'");
$main.="<img src=\"../images/ok.gif\" alt=\"o\"/><br/>
Shout added successfully
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}else{
$bantime=time()+(30*24*60*60);
$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>
Can't Post Shout<br/><br/>
You just shouted a link to one of the crapiest sites on earth<br/>
The members of these sites spam here a lot, so go to that site and stay there if you don't like it here<br/>
as a result of your stupid action:<br/>
1. you have lost your sheild<br/>
2. you have lost all your plusses<br/>
3. You are BANNED!
</p>\n";
mysql_query("INSERT INTO logs SET action='autoban', details='<b>".getnick_uid(1)."</b> auto banned ".getnick_sid($sid)." for spamming shoutbox', date='".time()."'");
mysql_query("INSERT INTO banned SET uid='".getuid_sid($sid)."', penalty='3', byid='1', remaining='".$bantime."', reason='Banned: Automatic Ban for spamming for a crap site'");
mysql_query("UPDATE profiles SET points='0', WHERE uid='".getuid_sid($sid)."'");
mysql_query("INSERT INTO inbox SET text='[b](forwarded spam via shoutbox)[/b][br/]".$shtxt."', byid='".getuid_sid($sid)."', toid='1', reported='1', timesent='".time()."'");
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
?>