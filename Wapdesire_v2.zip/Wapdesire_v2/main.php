<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////MAIN PAGE/////////////////////////

addonline(getuid_sid($sid),"Main Menu","main.php");
echo head_tag(getnick_sid($sid)."@".sitename(),1,getnick_sid($sid));
$title="<img src=\"./phpThumb/phpThumb.php?src=../images/$logo\" alt=\"".sitename()."\"/><br/>
".date("g:ia",strtotime("-0 hours"))."<br/>".date("l jS F",strtotime("-0 hours"))."<br/>
".$row_users["username"]." Your Back ;o)";
if($count_popup[0]>0){
$rname=mysql_fetch_array(mysql_query("SELECT name FROM chatrooms WHERE id='".$rid."'"));
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"./images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"./images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main="<div class=".align().">
<b>Popup Message<br/>
From $usersex<span style=\"color:$color;\">".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"./popups.php?send=1&amp;who=$pminfo[2]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>\n";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$main.="<p align=".align().">
<a href=\"./$location[0]?sid=$sid\">Skip Msg</a><br/>\n";
//$main.="<a href=\"inbxproc.php?action=rptpop&amp;sid=$sid&amp;pmid=$pminfo[0]\">Report</a><br/>";
if($rid!=""){$main.="<a href=\"./chat/chat.php?sid=$sid&amp;rid=$rid$pass\">Back To $rname[0]</a><br/>\n";}
}
if(align()!=center)$main.="<div class=\"center\">\n";
else $main.="<div class=".align().">\n";
if(points(getuid_sid($sid))>14){$main.="<form action=\"./shoutbox/shout.php?sid=$sid\" method=\"post\">\n";}
$main.="<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/><br/>
<b>ShoutBox</b><br/>\n";
$lshout=mysql_fetch_array(mysql_query("SELECT shout, uid, id FROM shouts ORDER BY shtime DESC LIMIT 1"));
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$lshout[1]."'"));
if($sex[0]=="M"){$usersex="<img src=\"./images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"./images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$shnick=getnick_uid($lshout[1]);
$main.="$usersex<i><a href=\"./profile.php?who=$lshout[1]&amp;sid=$sid\" style=\"color:$color;\">".$shnick."</a></i>
 - 
".getbbcode($lshout[0],$sid,1);
if(delshout(getuid_sid($sid),$lshout[2])){
$main.=" <a href=\"./shoutbox/delete.php?sid=$sid&amp;delete=$lshout[2]\">
<img src=\"./images/error.gif\" alt=\"[x]\"/></a>\n";
}
$main.="<br/><a href=\"./shoutbox/history.php?sid=$sid\">History</a>\n";
if(points(getuid_sid($sid))<15){
$points="points";
if(points(getuid_sid($sid))==14){$points="point";}
$main.="<br/>You need ".(15-points(getuid_sid($sid)))." more $points to shout!<br/>
<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/>
</div>\n";
}else{
$main.="<br/>ShoutBox Message:<br/>
<input name=\"shtxt\" maxlength=\"100\"/><br/>
<input type=\"submit\" value=\"Add Shout\"/><br/>
<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/>
</form>
</div>\n";
}
$main.="<p align=".align().">\n";
if(getbbcode(greeting(),$sid,0)!=""){$main.=getbbcode(greeting(),$sid,0)."<br/>\n";}
$main.="$Skey<a $keyS href=\"./findfriends.php?sid=$sid\">Find Friends</a><br/>
$onekey<a $key1 href=\"online.php?sid=$sid\">".getnumonline($sid)." Online Members</a><br/>\n";
$allinboxes=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE ((toid='".getuid_sid($sid)."' AND fwd='0') or (fwd='".getuid_sid($sid)."'))"));
$readinboxes=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE ((toid='".getuid_sid($sid)."' AND fwd='0') or (fwd='".getuid_sid($sid)."')) AND unread='1'"));
$main.="$twokey<a $key2 href=\"./inbox/inbox.php?sid=$sid\">$readinboxes[0] New Messages</a><br/>\n";
$requests=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM buds WHERE tid='".getuid_sid($sid)."' AND agreed='0'"));
if($requests[0]>0){$request="!".$requests[0];}else{$request="";}
$main.="$threekey<a $key3 href=\"./buds/buds.php?sid=$sid\">".online_buds(getuid_sid($sid))." Buddies Online</a>$request";
if(forumview()==3){$main.="\n</p>\n<div class=".align().">\n";}else{$main.="<br/>\n";}
if(forumview()==0){
$topics=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics"));
$posts=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts"));
$main.="$fourkey<a $key4 href=\"./forums/forums.php?sid=$sid\">$topics[0] Topics ".htmlspecialchars("& ").$posts[0]." Posts</a><br/>\n";
}
$fcats=mysql_query("SELECT id, name FROM forumcats ORDER BY position, id");
while($fcat=mysql_fetch_array($fcats))
{
$forums=mysql_query("SELECT id, name FROM forums WHERE catid='".$fcat[0]."' AND clubid='0' ORDER BY position, id, name");
if(forumview()==1){
$main.="<b>$fcat[1]</b><br/>";
while($forum=mysql_fetch_array($forums)){
$topics=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$forum[0]."'"));
$posts=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread = b.id WHERE b.fid='".$forum[0]."'"));
$main.="<a href=\"./forums/viewforum.php?fid=$forum[0]&amp;sid=$sid\">$forum[1] $topics[0]/$posts[0]</a><br/>";
}
}else if(forumview()==2){
$topics=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics a INNER JOIN forums b ON a.fid = b.id WHERE b.catid='".$fcat[0]."'"));
$posts=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread = b.id INNER JOIN forums c ON b.fid = c.id WHERE c.catid='".$fcat[0]."'"));
$main.="<a href=\"./forums/forums.php?cat=$fcat[0]&amp;sid=$sid\">$fcat[1] $topics[0]/$posts[0]</a><br/>";
}else if(forumview()==3){
$main.="<form action=\"./forums/viewforum.php\" method=\"get\">
<b>$fcat[1]</b><br/><select name=\"fid\">\n";
while($forum=mysql_fetch_array($forums)){
$topics=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$forum[0]."'"));
$posts=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread = b.id WHERE b.fid='".$forum[0]."'"));
$main.="<option value=\"$forum[0]\"/>$forum[1] $topics[0]/$posts[0]</option>\n";
}
$main.="</select><br/>
<input type=\"hidden\" name=\"sid\" value=\"$sid\"/>
<input type=\"submit\" value=\"[view]\"/>
</form>\n";
}
}
if(forumview()==3){$main.="</div>\n<p align=".align().">\n";}
$chat_on=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatonline"));
$clubs=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubs"));
$main.="$fivekey<a $key5 href=\"./chat/public.php?sid=$sid\">$chat_on[0] In Chat</a><br/>
$sixkey<a $key6 href=\"./clubs/clubs.php?sid=$sid\">$clubs[0] Clubs</a><br/>\n";
$gallery=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM gallery_files"));
$main.="$eightkey<a $key8 href=\"./gallery/gallery.php?sid=$sid\">$gallery[0] Gallery Pix</a><br/>\n";
$main.="$ninekey<a $key9 href=\"./settings/settings.php?sid=$sid\">Settings</a><br/>\n";
$main.="$zerokey<a $key0 href=\"logout.php?sid=$sid\">Exit</a><br/>
<br/>\n";
$main.="<a href=\"./quiz/quiz.php?sid=$sid\">Quiz</a><br/>\n";
$main.="<a href=\"./games/games.php?sid=$sid\">Games</a><br/>\n";
$downloads=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM download_files WHERE category!=''"));
$main.="<a href=\"./downloads/downloads.php?sid=$sid\">$downloads[0] Downloads</a><br/>\n";
$main.="<a href=\"./smilies/smilies.php?sid=$sid\">Smiley List</a><br/>\n";
$main.="<a href=\"./links.php?sid=$sid\">Site Links</a><br/>\n";
$main.="<a href=\"./sitestats.php?sid=$sid\">Site Stats</a><br/>\n";
$staff_all=mysql_fetch_array(mysql_query("SELECT count(*) FROM users WHERE level>'0'"));
$staff_on=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users a INNER JOIN online b ON a.id=b.uid WHERE level>'0' AND level<'6'"));
$main.="<a href=\"./staff.php?sid=$sid\">".$staff_on[0]." Staff Online</a><br/>\n";
$members=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users"));
$memid=mysql_fetch_array(mysql_query("SELECT id, username FROM users ORDER BY regdate DESC LIMIT 0,1"));
$sex=mysql_fetch_array(mysql_query("SELECT sex FROM profiles WHERE uid='".$memid[0]."'"));
if($sex[0]=="M"){$color="#0000FF";}
if($sex[0]=="F"){$color="#FF0066";}
if(align()==left)$main.="Members: <a href=\"./members.php?sid=$sid\">$members[0]</a>\n".htmlspecialchars("&")."\n";
else $main.="<br/>\nMembers: <a href=\"./members.php?sid=$sid\">$members[0]</a><br/>\n".htmlspecialchars("&")."<br/>\n";
$main.="Newest Member: <a href=\"./profile.php?who=$memid[0]&amp;sid=$sid\" style=\"color:$color;\">$memid[1]</a>
</p>\n";
if(isowner(getuid_sid($sid))||isheadadmin(getuid_sid($sid))||isadmin(getuid_sid($sid))||ismod(getuid_sid($sid))||use_tools(getuid_sid($sid))){
if(align()!=center)$main.="<p align=\"center\">\n";
else $main.="<p align=".align().">\n";
$main.="<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/><br/>\n";
}
if(isowner(getuid_sid($sid))){
$main.="<a href=\"./admin/tools.php?type=tools&amp;sid=$sid\">Owner Tools</a><br/>\n";
}else if(isheadadmin(getuid_sid($sid))){
$main.="<a href=\"./admin/tools.php?type=tools&amp;sid=$sid\">Head Admin Tools</a><br/>\n";
}else if((ismod(getuid_sid($sid)))||(isadmin(getuid_sid($sid)))){
$main.="<a href=\"./admin/tools.php?type=tools&amp;sid=$sid\">Admin Tools</a><br/>\n";
}else if(use_tools(getuid_sid($sid))){
$main.="<a href=\"./admin/tools.php?type=tools&amp;sid=$sid\">Hidden Tools</a><br/>\n";
}
$noi=mysql_fetch_array(mysql_query("SELECT count(*) FROM users WHERE validated='0'"));
if((validate(getuid_sid($sid)))&&($noi[0]>0)){
$main.="<a href=\"./admin/validate.php?sid=$sid\">$noi[0] Members Awaiting Validation</a><br/>\n";
}
$noi=mysql_fetch_array(mysql_query("SELECT count(*) FROM download_files WHERE active='0'"));
if((download_tools(getuid_sid($sid)))&&($noi[0]>0)){
$main.="<a href=\"./downloads/downloads.php?sid=$sid\">$noi[0] Files Awaiting Validation</a><br/>\n";
}
if(use_tools(getuid_sid($sid))){
$adminclub="1";
$ismem=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$adminclub."' AND uid='".getuid_sid($sid)."'"));
if($ismem[0]==0){
$main.="<a href=\"./clubs/join.php?id=$adminclub&amp;sid=$sid\">Join Admin Club Now!</a><br/>\n";
}else{
$clinfo=mysql_fetch_array(mysql_query("SELECT name, owner, description, rules, logo, points, created FROM clubs WHERE id='".$adminclub."'"));
$clubname=htmlspecialchars($clinfo[0]);
$fid=mysql_fetch_array(mysql_query("SELECT id FROM forums WHERE clubid='".$adminclub."'"));
$rid=mysql_fetch_array(mysql_query("SELECT id FROM chatrooms WHERE clubid='".$adminclub."'"));
$topics=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE fid='".$fid[0]."'"));
$posts=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts a INNER JOIN forumtopics b ON a.thread=b.id WHERE b.fid='".$fid[0]."'"));
$cango=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$adminclub."' AND uid='".getuid_sid($sid)."' AND accepted='1'"));
if(($cango[0]>0)||(isheadadmin(getuid_sid($sid)))||(isowner(getuid_sid($sid)))){
$noa=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM announcements WHERE clubid='".$adminclub."'"));
$main.="<a href=\"./clubs/announcements.php?id=$adminclub&amp;sid=$sid\">$noa[0] Announcements</a><br/>\n";
$noa=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chat WHERE rid='".$rid[0]."'"));
$chat=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatonline WHERE rid='".$rid[0]."'"));
$main.="<a href=\"./chat/chat.php?rid=$rid[0]&amp;sid=$sid\">$chat[0] In $clubname Chat</a><br/>\n";
$main.="<a href=\"./forums/viewforum.php?fid=$fid[0]&amp;sid=$sid\">$topics[0] $clubname Topics ".htmlspecialchars("& ").$posts[0]." $clubname Posts</a><br/>\n";
if($clinfo[1]==getuid_sid($sid)){
$mems=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM clubmembers WHERE clubid='".$adminclub."' AND accepted='0'"));
if($mems[0]>0){
$main.="<a href=\"./clubs/requests.php?id=$adminclub&amp;sid=$sid\">$mems[0] New Requests</a><br/>\n";
}
}
}
}
$tnor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE reported='1'"));
$reports=$tnor[0];
$tnor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM popups WHERE reported='1'"));
$reports+=$tnor[0];
$tnor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumposts WHERE reported='1'"));
$reports+=$tnor[0];
$tnor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM forumtopics WHERE reported='1'"));
$reports+=$tnor[0];
$tnor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE reported='1'"));
$reports+=$tnor[0];
$tnor=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE reported='1'"));
$reports+=$tnor[0];
$tnol=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM logs"));
$logs=$tnol[0];
$main.="<a href=\"./admin/logs.php?sid=$sid\">".$reports." Reports ".htmlspecialchars("& ").$logs." Logs</a><br/>";
}
if(isowner(getuid_sid($sid))||isheadadmin(getuid_sid($sid))||isadmin(getuid_sid($sid))||ismod(getuid_sid($sid))||use_tools(getuid_sid($sid))){
$main.="<img src=\"./phpThumb/phpThumb.php?src=../images/$banner\" alt=\"-------\"/>\n
</p>\n";
}
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>