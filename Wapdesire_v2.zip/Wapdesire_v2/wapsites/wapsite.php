<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if($sid!=""&&$sid!="guest"){
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW WAPSITE/////////////////////////

if($who=="")$who=getuid_nick($uname);
if($sid=="")$sid="guest";
echo head_tag(getnick_sid($sid)."@View Wapsite",1,getnick_uid($who));
$nick=getnick_uid($who).htmlspecialchars("'",ENT_QUOTES)."s";
if(getuid_sid($sid)==$who)$nick="My";
addonline(getuid_sid($sid),"Viewing $nick Wapsite","");
$info=mysql_fetch_array(mysql_query("SELECT * FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE a.id='".$who."'"));
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
$blogs=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE uid='".$who."'"));
$title="$nick Personal Wapsite";
$main="<p align=\"center\">
".getbbcode($wapsite["mainpage"],$sid,1)."<br/>
<br/>
<a href=\"./profile.php?who=$who&amp;sid=$sid\">Profile</a><br/>\n";
if($info[pollid]>0){
$main.="<a href=\"./poll.php?who=$who&amp;sid=$sid\">Poll</a><br/>\n";
}
if($blogs[0]>0){
$main.="<a href=\"./blogs.php?who=$who&amp;sid=$sid\">Blogs</a><br/>\n";
}
if($wapsite[guestbook]>0){
$main.="<a href=\"./guestbook.php?who=$who&amp;sid=$sid\">Guestbook</a><br/>\n";
}
$main.="<br/>\n";
$folder="./";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
if($location[0]!="update.php"){$folder="../";}
if(strpos($location[0],"?")){$location[0].="&amp;";}
else{$location[0].="?";}
if(islogged($sid)){
$main.="$fivekey<a $key5 href=\"$folder".$location[0]."sid=$sid\">Back</a><br/>
$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a><br/>
$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a><br/>
$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a><br/>
$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a><br/>
$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>\n";
}else{
$main.="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>