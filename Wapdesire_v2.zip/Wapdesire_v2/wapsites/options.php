<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////WAPSITE OPTIONS/////////////////////////

if($save==1)
{
echo head_tag(getnick_sid($sid)."@Wapsite Options",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Wapsite Options","");
$title="<b>Wapsite Options</b>";
$main="<p align=".align().">\n";
$wapsite_exist=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite_exist[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."', blog_comments='".$blog_comments."', guestbook='".$guestbook."'");
}else{
$res=mysql_query("UPDATE wapsite SET blog_comments='".$blog_comments."', guestbook='".$guestbook."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Options Successfully Saved<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Options<br/>\n";
}
$main.="$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@Wapsite Options",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Wapsite Options","update.php");
$title="Wapsite Options";
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[blog_comments]=="1"){$blog_opt=" selected=\"selected\"";}else{$blog_opt="";}
if($wapsite[guestbook]=="0"){$gb0=" selected=\"selected\"";}else{$gb0="";}
if($wapsite[guestbook]=="2"){$gb2=" selected=\"selected\"";}else{$gb2="";}
$main="<div class=".align().">
<form action=\"./options.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Blog Comments:</b> 
<select name=\"blog_comments\">
<option value=\"0\">Disabled</option>
<option value=\"1\"$blog_opt>Enabled</option>
</select><br/>
<br/>
<b>Guestbook Status:</b> 
<select name=\"guestbook\">
<option value=\"1\">Enabled</option>
<option value=\"0\"$gb0>Disabled</option>
<option value=\"2\"$gb2>Restriced*</option>
</select><br/> 
* Note that when you select the *restricted option, 
Members usernames will be added to there messages.<br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>