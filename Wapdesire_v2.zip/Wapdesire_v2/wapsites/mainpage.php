<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////SAVE MAIN PAGE/////////////////////////

if($save==1)
{
echo head_tag(getnick_sid($sid)."@Updating Wapsite",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$info=mysql_fetch_array(mysql_query("SELECT * FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE a.id='".$who."'"));
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
$title="Updating Wapsite";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."', mainpage='".$msg."'");
}else{
$res=mysql_query("UPDATE wapsite SET mainpage='".$msg."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Main Page Successfully Saved<br/>
$fivekey<a $key5 href=\"./update.php?sid=$sid\">Ok</a>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Main Page<br/>
$fivekey<a $key5 href=\"./mainpage.php?sid=$sid\">Back</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@Update Wapsite",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Update Wapsite","");
$info=mysql_fetch_array(mysql_query("SELECT * FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE a.id='".$who."'"));
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
$title="Update Wapsite";
$main="<p align=".align().">
<b>Welcome words:</b><br/>
Type here your welcome message:<br/>
e.g: Welcome everybody! This is my first wap site ...
</p>
<div class=".align().">
<form action=\"./mainpage.php?save=1&amp;sid=$sid\" method=\"post\">
Text: 
<input type=\"text\" name=\"msg\" value=\"$wapsite[mainpage]\"/> 
<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"../main.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
?>