<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if($sid!=""&&$sid!="guest"){
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW WAPSITE APPEARANCE/////////////////////////

echo head_tag(getnick_sid($sid)."@View Appearance",1,getnick_uid($who));
$nick=getnick_uid($who).htmlspecialchars("'",ENT_QUOTES)."s";
if(getuid_sid($sid)==$who)$nick="My";
addonline(getuid_sid($sid),"Viewing $nick Appearance","");
$info=mysql_fetch_array(mysql_query("SELECT * FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE a.id='".$who."'"));
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
if($wapsite[bodytype]==0)$bodytype="Unknown";
else if($wapsite[bodytype]==1)$bodytype="Slim";
else if($wapsite[bodytype]==2)$bodytype="Slim, Toned";
else if($wapsite[bodytype]==3)$bodytype="Average";
else if($wapsite[bodytype]==4)$bodytype="Defined";
else if($wapsite[bodytype]==5)$bodytype="Medium Build";
else if($wapsite[bodytype]==6)$bodytype="Medium Build, Muscles";
else if($wapsite[bodytype]==7)$bodytype="Fuller Figure";
if($wapsite[origin]==0)$origin="Unknown";
else if($wapsite[origin]==1)$origin="Asian";
else if($wapsite[origin]==2)$origin="South Asian";
else if($wapsite[origin]==3)$origin="Oriental";
else if($wapsite[origin]==4)$origin="Black";
else if($wapsite[origin]==5)$origin="Latin/Hispanic";
else if($wapsite[origin]==6)$origin="Middle Eastern";
else if($wapsite[origin]==7)$origin="Mixed Race";
else if($wapsite[origin]==8)$origin="Mixed European";
else if($wapsite[origin]==9)$origin="White/Caucasian";
else if($wapsite[origin]==10)$origin="African American";
else if($wapsite[origin]==11)$origin="American Indian";
else if($wapsite[origin]==12)$origin="African";
else if($wapsite[origin]==13)$origin="Other";
if($wapsite[eyes]==0)$eyes="Unknown";
else if($wapsite[eyes]==1)$eyes="Blue";
else if($wapsite[eyes]==2)$eyes="Brown";
else if($wapsite[eyes]==3)$eyes="Green";
else if($wapsite[eyes]==4)$eyes="Gray";
else if($wapsite[eyes]==5)$eyes="Hazel";
else if($wapsite[eyes]==6)$eyes="Black";
$title="$nick Appearance";
$main="<p align=".align().">
<b>Height</b>: ".$wapsite[height]."<br/>
<b>Weight</b>: ".$wapsite[weight]."<br/>
<b>Body Type</b>: $bodytype<br/>
<b>Ethnic Origin</b>: $origin<br/>
<b>Hair</b>: ".$wapsite[hair]."<br/>
<b>Eyes</b>: $eyes<br/>
<br/>
<a href=\"./profile.php?who=$who&amp;sid=$sid\">&lt;-Back</a> | 
<a href=\"./profile3.php?who=$who&amp;sid=$sid\">Next-&gt;</a><br/>
$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back To Wapsite</a>
</p>\n";
if(islogged($sid)){
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>