<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if($sid!=""&&$sid!="guest"){
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW WAPSITE GUESTBOOK/////////////////////////

if($sign==1)
{
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
if($wapsite[guestbook]==2&&!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
echo head_tag(getnick_sid($sid)."@Signing Guestbook",1,getnick_uid($who));
addonline(getuid_sid($sid),"Sign Guestbook","");
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
$title="<b>Sign Guestbook</b>";
if($wapsite[guestbook]>0&&getuid_sid($sid)!=$who){
$main="<div class=".align().">
<form action=\"./guestbook.php?save=1&amp;who=$who&amp;sid=$sid\" method=\"post\">\n";
if($wapsite[guestbook]==1){
$main.="<b>Name:</b><br/>
<input type=\"text\" name=\"name\" value=\"\" maxlength=\"50\"/><br/>\n";
}else if($wapsite[guestbook]==2){
$main.="<input type=\"hidden\" name=\"name\" value=\"".getnick_sid($sid)."\"/>\n";
}
$main.="<b>Message:</b><br/>
<input type=\"text\" name=\"message\" value=\"\" maxlength=\"255\"/><br/>
<input type=\"submit\" value=\"Sign\"/>
</form>
</div>\n";
}else if(getuid_sid($sid)==$who){
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/>You Cannot Sign Your Own Guestbook 
</p>\n";
}else{
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/>".getnick_uid($who)." Has There Guestbook Turned Off
</p>\n";
}
if(islogged($sid)){
$main.="<p align=".align().">
$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$main.="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save==1)
{
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
if($wapsite[guestbook]==2&&!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
echo head_tag(getnick_sid($sid)."@Signing Guestbook",1,getnick_uid($who));
addonline(getuid_sid($sid),"Signing Guestbook","");
$title="<b>Signing Guestbook</b>";
$main="<p align=".align().">\n";
if($wapsite[guestbook]>0){
$res=mysql_query("INSERT INTO guestbook SET uid='".$who."', name='".$name."', message='".$message."', date='".time()."'");
if($res){
if($who!=getuid_sid($sid)&&automsgs($who)){
$nick=getnick_sid($sid);
if(empty($nick))$nick="[b]Guest[/b] $name";
$msg="Your guestbook has been signed by ".$nick."[br/][small][i]p.s: this is an automated pm[/i][/small]";
autopm($msg,$who);
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Guestbook Message Added<br/>\n";
}else{
echo mysql_error();
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Adding Message<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>".getnick_uid($who)." Has There Guestbook Turned Off<br/>\n";
}
if(islogged($sid)){
$main.="$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$main.="</p>\n";
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
echo head_tag(getnick_sid($sid)."@Deleting Guestbook Message",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Deleting Guestbook Message","");
$title="<b>Deleting Guestbook Message</b>";
$main="<p align=".align().">\n";
$message_exist=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM guestbook WHERE id='".$id."'"));
if($message_exist[0]==1){
$res=mysql_query("DELETE FROM guestbook WHERE uid='".getuid_sid($sid)."'AND id='".$id."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Message Successfully Deleted<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Deleting Message<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Message Does Not Exist<br/>\n";
}
$main.="$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

if($who=="")$who=getuid_nick($uname);
echo head_tag(getnick_sid($sid)."@View Wapsite",1,getnick_uid($who));
if($sid=="")$sid="guest";
$nick=getnick_uid($who).htmlspecialchars("'",ENT_QUOTES)."s";
if(getuid_sid($sid)==$who)$nick="My";
addonline(getuid_sid($sid),"Viewing $nick Wapsite","");
$title="$nick Guestbook";
$main="<p align=".align().">\n";
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM guestbook WHERE uid='".$who."'"));
$num_items=$noi[0];
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT * FROM guestbook WHERE uid='".$who."' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$query=mysql_query($sql);
if(mysql_num_rows($query)>0){
while($row_guestbook=mysql_fetch_array($query)){
$main.="<b>From: </b>".getbbcode($row_guestbook[name],$sid,1)."<br/>
<b>Date: </b>".date("H:i l jS F Y",$row_guestbook["date"])."<br/>
<b>Message: </b>".getbbcode($row_guestbook[message],$sid,1);
if(getuid_sid($sid)==$who){
$main.="\n<a href=\"./guestbook.php?delete=1&amp;id=$row_guestbook[id]&amp;who=$who&amp;sid=$sid\">
<img src=\"../images/error.gif\" alt=\"[Delete]\"/>
</a>\n";
}
$main.="<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./guestbook.php?who=$who&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./guestbook.php?who=$who&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("guestbook","who","$who",$sid);}
$main.="<p align=".align().">\n";
}else{
$main.=getnick_uid($who)." Has No Guestbook Messages
</p>
<p align=".align().">\n";
}
$main.="$fourkey<a $key4 href=\"./guestbook.php?sign=1&amp;who=$who&amp;sid=$sid\">Sign Guestbook</a><br/>
<br/>\n";
if(islogged($sid)){
$main.="$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$main.="</p>\n";
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>