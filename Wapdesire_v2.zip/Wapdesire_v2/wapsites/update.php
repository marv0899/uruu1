<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////UPDATE WAPSITE/////////////////////////

if($blogs==1)
{
echo head_tag(getnick_sid($sid)."@Update Wapsite",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Update Blogs","update.php?blogs=1");
$title="<b>Whats a blog?</b>";
$main="<p align=".align().">
<small>
A blog is a personal online diary.<br/>
A collaborative space.<br/>
A breaking-news outlet.<br/>
Your own private thoughts.<br/>
Memos to the world.<br/>
In simple terms a blog is a place, 
where you write stuff on an ongoing basis.<br/>
New stuff shows up at the top, so your visitors can read what's new.
</small><br/>
<br/>\n";
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE uid='".getuid_sid($sid)."'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT * FROM blogs WHERE uid='".getuid_sid($sid)."' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$query=mysql_query($sql);
if(mysql_num_rows($query)>0){
$main.="<b>My Blogs:</b><br/>\n";
while($row_blogs=mysql_fetch_array($query)){
$main.="<a href=\"./blogs.php?edit=1&amp;id=".$row_blogs["id"]."&amp;sid=$sid\"><img src=\"../images/edit.gif\" alt=\"[Edit]\"/></a> 
 | 
<a href=\"./blogs.php?delete=1&amp;id=".$row_blogs["id"]."&amp;sid=$sid\"><img src=\"../images/error.gif\" alt=\"[Delete]\"/></a> 
 | 
<a href=\"./blogs.php?read=1&amp;id=".$row_blogs["id"]."&amp;who=".getuid_sid($sid)."&amp;sid=$sid\"><img src=\"../images/eye.gif\" alt=\"[Preview]\"/></a> 
 | 
".getbbcode($row_blogs["subject"],$sid,1)." - 
<small>".date("l jS F",$row_blogs["date"])."</small><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./update.php?blogs=1&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./update.php?blogs=1&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("update","blogs","1",$sid);}
$main.="<p align=".align().">\n";
}
$main.="$onekey<a $key1 href=\"./blogs.php?add=1&amp;sid=$sid\">Add Blog</a><br/>
$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($poll==1)
{
echo head_tag(getnick_sid($sid)."@Update Wapsite",1,getuid_sid($sid));
addonline(getuid_sid($sid),"Update Poll","");
$title="Update Poll";
$main="<p align=".align().">\n";
if(points(getuid_sid($sid))>=50){
$pid=mysql_fetch_array(mysql_query("SELECT pollid FROM users WHERE id='".getuid_sid($sid)."'"));
if($pid[0]==0){$main.="<a href=\"./poll.php?create=1&amp;sid=$sid\">Create Poll</a><br/>\n";}
$main.="<a href=\"./poll.php?who=".getuid_sid($sid)."&amp;sid=$sid\">View Your Poll</a><br/>
<a href=\"./poll.php?delete=1&amp;sid=$sid\">Delete Your Poll</a><br/>\n";
}else{
$points="points";
if(points(getuid_sid($sid))==49){$points="point";}
$main.="You need ".(50-points(getuid_sid($sid)))." more $points Points required to administrate your poll\n";
}
$main.="</p>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@Update Wapsite",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Update Wapsite","update.php");
$title="Update Wapsite";
$main="<p align=".align().">
<a href=\"./mainpage.php?sid=$sid\">Main Page</a><br/>
<a href=\"./updateprofile.php?sid=$sid\">Profile</a><br/>
<a href=\"./update.php?blogs=1&amp;sid=$sid\">Blogs</a><br/>
<a href=\"./update.php?poll=1&amp;sid=$sid\">Poll</a><br/>
<a href=\"./options.php?sid=$sid\">Options</a><br/>
<br/>
<a href=\"./wapsite.php?who=".getuid_sid($sid)."&amp;sid=$sid\">Preview</a><br/>
<br/>
to share your wapsite with your friends, give them this link.<br/>
http://".sitename()."/?".getnick_sid($sid)."<br/>
<br/>
$fivekey<a $key5 href=\"../main.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>