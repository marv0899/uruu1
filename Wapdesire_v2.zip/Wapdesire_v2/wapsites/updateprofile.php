<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////UPDATE PROFILE/////////////////////////

if($save=="basicinfo")
{
echo head_tag(getnick_sid($sid)."@Saving Basic Info",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$title="Saving Basic Info";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."', name='".$name."', surname='".$surname."', nickname='".$nickname."', maritalstatus='".$maritalstatus."', city='".$city."'");
}else{
$res=mysql_query("UPDATE wapsite SET name='".$name."', surname='".$surname."', nickname='".$nickname."', maritalstatus='".$maritalstatus."', city='".$city."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
if(isspam($name|$surname|$nickname|$city)){
mysql_query("UPDATE wapsite SET reported='1' WHERE uid='".getuid_sid($sid)."'");
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Basic Info Successfully Saved<br/>
$fivekey<a $key5 href=\"./updateprofile.php?sid=$sid\">Ok</a>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Basic Info<br/>
$fivekey<a $key5 href=\"./updateprofile.php?page=basicinfo&amp;sid=$sid\">Back</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save=="appearance")
{
echo head_tag(getnick_sid($sid)."@Saving Appearance",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$title="Saving Appearance";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."' height='".$height."', weight='".$weight."', bodytype='".$bodytype."', origin='".$ethorigin."', hair='".$hair."', eyes='".$eyes."'");
}else{
$res=mysql_query("UPDATE wapsite SET height='".$height."', weight='".$weight."', bodytype='".$bodytype."', origin='".$ethorigin."', hair='".$hair."', eyes='".$eyes."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
if(isspam($height|$weight|$hair)){
mysql_query("UPDATE wapsite SET reported='1' WHERE uid='".getuid_sid($sid)."'");
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Appearance Successfully Saved<br/>
$fivekey<a $key5 href=\"./updateprofile.php?sid=$sid\">Ok</a>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Appearance<br/>
$fivekey<a $key5 href=\"./updateprofile.php?page=appearance&amp;sid=$sid\">Back</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save=="interests")
{
echo head_tag(getnick_sid($sid)."@Saving Interests",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$title="Saving Interests";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."' happy='".$happy."', sad='".$sad."', interests='".$interests."', profession='".$profession."', badhabits='".$badhabits."', goodhabits='".$goodhabits."'");
}else{
$res=mysql_query("UPDATE wapsite SET happy='".$happy."', sad='".$sad."', interests='".$interests."', profession='".$profession."', badhabits='".$badhabits."', goodhabits='".$goodhabits."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
if(isspam($happy|$sad|$interests|$profession|$badhabits|$goodhabits)){
mysql_query("UPDATE wapsite SET reported='1' WHERE uid='".getuid_sid($sid)."'");
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Interests Successfully Saved<br/>
$fivekey<a $key5 href=\"./updateprofile.php?sid=$sid\">Ok</a>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Interests<br/>
$fivekey<a $key5 href=\"./updateprofile.php?page=interests&amp;sid=$sid\">Back</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save=="favourites")
{
echo head_tag(getnick_sid($sid)."@Saving Favourites",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$title="Saving Favourites";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."' team='".$team."', band='".$band."', music='".$music."', tvshow='".$tvshow."', food='".$food."', author='".$author."', movie='".$movie."', animal='".$animal."', place='".$place."', thing='".$thing."'");
}else{
$res=mysql_query("UPDATE wapsite SET team='".$team."', band='".$band."', music='".$music."', tvshow='".$tvshow."', food='".$food."', author='".$author."', movie='".$movie."', animal='".$animal."', place='".$place."', thing='".$thing."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
if(isspam($team|$band|$music|$tvshow|$food|$author|$movie|$animal|$place|$thing)){
mysql_query("UPDATE wapsite SET reported='1' WHERE uid='".getuid_sid($sid)."'");
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Favourites Successfully Saved<br/>
$fivekey<a $key5 href=\"./updateprofile.php?sid=$sid\">Ok</a>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Favourites<br/>
$fivekey<a $key5 href=\"./updateprofile.php?page=favourites&amp;sid=$sid\">Back</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save=="aboutme")
{
echo head_tag(getnick_sid($sid)."@Saving More About Me",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$title="Saving More About Me";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[0]==0){
$res=mysql_query("INSERT INTO wapsite SET uid='".getuid_sid($sid)."' aboutme='".$aboutme."'");
}else{
$res=mysql_query("UPDATE wapsite SET aboutme='".$aboutme."' WHERE uid='".getuid_sid($sid)."'");
}
if($res){
if(isspam($aboutme)){
mysql_query("UPDATE wapsite SET reported='1' WHERE uid='".getuid_sid($sid)."'");
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>More About Me Successfully Saved<br/>
$fivekey<a $key5 href=\"./updateprofile.php?sid=$sid\">Ok</a>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving More About Me<br/>
$fivekey<a $key5 href=\"./updateprofile.php?page=aboutme&amp;sid=$sid\">Back</a>\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($page=="basicinfo")
{
echo head_tag(getnick_sid($sid)."@Updating Basic Info",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[nickname]=="")$nick=getnick_sid($sid);
else $nick=$wapsite[nickname];
if($wapsite[maritalstatus]==1){$ms1=" selected=\"selected\"";}else{$ms1="";}
if($wapsite[maritalstatus]==2){$ms2=" selected=\"selected\"";}else{$ms2="";}
if($wapsite[maritalstatus]==3){$ms3=" selected=\"selected\"";}else{$ms3="";}
if($wapsite[maritalstatus]==4){$ms4=" selected=\"selected\"";}else{$ms4="";}
$title="Basic Info";
$main="<div class=".align().">
<form action=\"./updateprofile.php?save=basicinfo&amp;sid=$sid\" method=\"post\">
<b>Name</b>: 
<input type=\"text\" name=\"name\" value=\"$wapsite[name]\" maxlength=\"50\"/><br/>
<b>Surname</b>: 
<input type=\"text\" name=\"surname\" value=\"$wapsite[surname]\" maxlength=\"50\"/><br/>
<b>Nickname</b>: 
<input type=\"text\" name=\"nickname\" value=\"$nick\" maxlength=\"50\"/><br/>
<b>Marital Status</b>: 
<select name=\"maritalstatus\">
<option value=\"0\">Single</option>
<option value=\"1\"$ms1>In relationship</option>
<option value=\"2\"$ms2>Engaged</option>
<option value=\"3\"$ms3>Married</option>
<option value=\"4\"$ms4>Divorced</option>
</select><br/>
<b>City/Suburb</b>: 
<input type=\"text\" name=\"city\" value=\"$wapsite[city]\" maxlength=\"50\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

else if($page=="appearance")
{
echo head_tag(getnick_sid($sid)."@Updating Appearance",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
if($wapsite[bodytype]==2){$bt2=" selected=\"selected\"";}else{$bt2="";}
if($wapsite[bodytype]==3){$bt3=" selected=\"selected\"";}else{$bt3="";}
if($wapsite[bodytype]==4){$bt4=" selected=\"selected\"";}else{$bt4="";}
if($wapsite[bodytype]==5){$bt5=" selected=\"selected\"";}else{$bt5="";}
if($wapsite[bodytype]==6){$bt6=" selected=\"selected\"";}else{$bt6="";}
if($wapsite[bodytype]==7){$bt7=" selected=\"selected\"";}else{$bt7="";}
if($wapsite[origin]==2){$or2=" selected=\"selected\"";}else{$or2="";}
if($wapsite[origin]==3){$or3=" selected=\"selected\"";}else{$or3="";}
if($wapsite[origin]==4){$or4=" selected=\"selected\"";}else{$or4="";}
if($wapsite[origin]==5){$or5=" selected=\"selected\"";}else{$or5="";}
if($wapsite[origin]==6){$or6=" selected=\"selected\"";}else{$or6="";}
if($wapsite[origin]==7){$or7=" selected=\"selected\"";}else{$or7="";}
if($wapsite[origin]==8){$or8=" selected=\"selected\"";}else{$or8="";}
if($wapsite[origin]==9){$or9=" selected=\"selected\"";}else{$or9="";}
if($wapsite[origin]==10){$or10=" selected=\"selected\"";}else{$or10="";}
if($wapsite[origin]==11){$or11=" selected=\"selected\"";}else{$or11="";}
if($wapsite[origin]==12){$or12=" selected=\"selected\"";}else{$or12="";}
if($wapsite[origin]==13){$or13=" selected=\"selected\"";}else{$or13="";}
if($wapsite[eyes]==2){$ey2=" selected=\"selected\"";}else{$ey2="";}
if($wapsite[eyes]==3){$ey3=" selected=\"selected\"";}else{$ey3="";}
if($wapsite[eyes]==4){$ey4=" selected=\"selected\"";}else{$ey4="";}
if($wapsite[eyes]==5){$ey5=" selected=\"selected\"";}else{$ey5="";}
if($wapsite[eyes]==6){$ey6=" selected=\"selected\"";}else{$ey6="";}
$title="Appearance";
$main="<div class=".align().">
<form action=\"./updateprofile.php?save=appearance&amp;sid=$sid\" method=\"post\">
<b>Height</b>: 
<input type=\"text\" name=\"height\" value=\"$wapsite[height]\" maxlength=\"50\"/><br/>
<b>Weight</b>: 
<input type=\"text\" name=\"weight\" value=\"$wapsite[weight]\" maxlength=\"50\"/><br/>
<b>Body Type</b>: 
<select name=\"bodytype\">
<option value=\"1\">Slim</option>
<option value=\"2\"$bt2>Slim, Toned</option>
<option value=\"3\"$bt3>Average</option>
<option value=\"4\"$bt4>Defined</option>
<option value=\"5\"$bt5>Medium Build</option>
<option value=\"6\"$bt6>Medium Build, Muscles</option>
<option value=\"7\"$bt7>Fuller Figure</option>
</select><br/>
<b>Ethnic Origin</b>: 
<select name=\"ethorigin\">
<option value=\"1\">Asian</option>
<option value=\"2\"$or2>South Asian</option>
<option value=\"3\"$or3>Oriental</option>
<option value=\"4\"$or4>Black</option>
<option value=\"5\"$or5>Latin/Hispanic</option>
<option value=\"6\"$or6>Middle Eastern</option>
<option value=\"7\"$or7>Mixed Race</option>
<option value=\"8\"$or8>Mixed European</option>
<option value=\"9\"$or9>White/Caucasian</option>
<option value=\"10\"$or10>African American</option>
<option value=\"11\"$or11>American Indian</option>
<option value=\"12\"$or12>African</option>
<option value=\"13\"$or13>Other</option>
</select><br/>
<b>Hair</b>: 
<input type=\"text\" name=\"hair\" value=\"$wapsite[hair]\" maxlength=\"50\"/><br/>
<b>Eyes</b>: 
<select name=\"eyes\">
<option value=\"1\">Blue</option>
<option value=\"2\"$ey2>Brown</option>
<option value=\"3\"$ey3>Green</option>
<option value=\"4\"$ey4>Gray</option>
<option value=\"5\"$ey5>Hazel</option>
<option value=\"6\"$ey6>Black</option>
</select><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

else if($page=="interests")
{
echo head_tag(getnick_sid($sid)."@Updating Interests",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
$title="Interests";
$main="<div class=".align().">
<form action=\"./updateprofile.php?save=interests&amp;sid=$sid\" method=\"post\">
<b>Makes Me Happy</b>: 
<input type=\"text\" name=\"happy\" value=\"$wapsite[happy]\" maxlength=\"255\"/><br/>
<b>Makes Me Sad</b>: 
<input type=\"text\" name=\"sad\" value=\"$wapsite[sad]\" maxlength=\"255\"/><br/>
<b>Interests</b>: 
<input type=\"text\" name=\"interests\" value=\"$wapsite[interests]\" maxlength=\"255\"/><br/>
<b>Profession</b>: 
<input type=\"text\" name=\"profession\" value=\"$wapsite[profession]\" maxlength=\"50\"/><br/>
<b>Bad Habits</b>: 
<input type=\"text\" name=\"badhabits\" value=\"$wapsite[badhabits]\" maxlength=\"255\"/><br/>
<b>Good Habits</b>: 
<input type=\"text\" name=\"goodhabits\" value=\"$wapsite[goodhabits]\" maxlength=\"255\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

else if($page=="favourites")
{
echo head_tag(getnick_sid($sid)."@Updating Favourites",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
$title="Favourites";
$main="<div class=".align().">
<form action=\"./updateprofile.php?save=favourites&amp;sid=$sid\" method=\"post\">
<b>Team</b>: 
<input type=\"text\" name=\"team\" value=\"$wapsite[team]\" maxlength=\"50\"/><br/>
<b>Singer/Band</b>: 
<input type=\"text\" name=\"band\" value=\"$wapsite[band]\" maxlength=\"50\"/><br/>
<b>Music</b>: 
<input type=\"text\" name=\"music\" value=\"$wapsite[music]\" maxlength=\"50\"/><br/>
<b>Tv Show</b>: 
<input type=\"text\" name=\"tvshow\" value=\"$wapsite[tvshow]\" maxlength=\"50\"/><br/>
<b>Food</b>: 
<input type=\"text\" name=\"food\" value=\"$wapsite[food]\" maxlength=\"50\"/><br/>
<b>Author</b>: 
<input type=\"text\" name=\"author\" value=\"$wapsite[author]\" maxlength=\"50\"/><br/>
<b>Movie</b>: 
<input type=\"text\" name=\"movie\" value=\"$wapsite[movie]\" maxlength=\"50\"/><br/>
<b>Animal</b>: 
<input type=\"text\" name=\"animal\" value=\"$wapsite[animal]\" maxlength=\"50\"/><br/>
<b>Place</b>: 
<input type=\"text\" name=\"place\" value=\"$wapsite[place]\" maxlength=\"255\"/><br/>
<b>Thing</b>: 
<input type=\"text\" name=\"thing\" value=\"$wapsite[thing]\" maxlength=\"255\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

else if($page=="aboutme")
{
echo head_tag(getnick_sid($sid)."@Updating More About Me",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Updating Wapsite","");
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".getuid_sid($sid)."'"));
$title="More About Me";
$main="<div class=".align().">
<form action=\"./updateprofile.php?save=aboutme&amp;sid=$sid\" method=\"post\">
<b>More About Me</b>: 
<input type=\"text\" name=\"aboutme\" value=\"$wapsite[aboutme]\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>\n";
$L1="$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>";
$L2="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L3="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L4="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L5="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L6="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@Update Wapsite",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Update Wapsite","");
$title="Update Wapsite";
$main="<p align=".align().">
<a href=\"./updateprofile.php?page=basicinfo&amp;sid=$sid\">Basic Info</a><br/>
<a href=\"./updateprofile.php?page=appearance&amp;sid=$sid\">Appearance</a><br/>
<a href=\"./updateprofile.php?page=interests&amp;sid=$sid\">Interests</a><br/>
<a href=\"./updateprofile.php?page=favourites&amp;sid=$sid\">Favourites</a><br/>
<a href=\"./updateprofile.php?page=aboutme&amp;sid=$sid\">More About Me</a><br/>
<br/>
$fivekey<a $key5 href=\"./update.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>