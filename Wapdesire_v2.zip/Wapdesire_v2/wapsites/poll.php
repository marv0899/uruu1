<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if($sid!=""&&$sid!="guest"){
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEWING POLL/////////////////////////

if($create==1)
{
echo head_tag(getnick_sid($sid)."@Creating Poll",1,getuid_sid($sid));
addonline(getuid_sid($sid),"Create Poll","");
$title="Create Poll";
$main="<p align=".align().">\n";
if(points(getuid_sid($sid))>=50){
$pid=mysql_fetch_array(mysql_query("SELECT pollid FROM users WHERE id='".getuid_sid($sid)."'"));
if($pid[0]==0){
$main="<div class=".align().">
<form action=\"./poll.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Question:</b><br/>
<input name=\"question\" maxlength=\"250\"/><br/>
<b>Option 1:</b><br/>
<input name=\"option1\" maxlength=\"100\"/><br/>
<b>Option 2:</b><br/>
<input name=\"option2\" maxlength=\"100\"/><br/>
<b>Option 3:</b><br/>
<input name=\"option3\" maxlength=\"100\"/><br/>
<b>Option 4:</b><br/>
<input name=\"option4\" maxlength=\"100\"/><br/>
<b>Option 5:</b><br/>
<input name=\"option5\" maxlength=\"100\"/><br/>
<input type=\"submit\" value=\"Create\"/>
</form>
</div\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You already have a poll, delete your current one before adding a new one\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You should have at least 50 points to create a poll\n";
}
$main.="</p>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?poll=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save==1)
{
echo head_tag(getnick_sid($sid)."@Creating Poll",1,getuid_sid($sid));
addonline(getuid_sid($sid),"Creating Poll","");
$title="Creating Poll";
$main="<p align=".align().">\n";
if(points(getuid_sid($sid))>=50){
$pid=mysql_fetch_array(mysql_query("SELECT pollid FROM users WHERE id='".getuid_sid($sid)."'"));
if($pid[0]==0){
if((trim($question)!="")&&(trim($option1)!="")&&(trim($option2)!="")){
$pex=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM polls WHERE question LIKE '".$question."'"));
if($pex[0]==0){
$res=mysql_query("INSERT INTO polls SET question='".$question."', option1='".$option1."', option2='".$option2."', option3='".$option3."', option4='".$option4."', option5='".$option5."', date='".time()."'");
if($res){
$pollid=mysql_fetch_array(mysql_query("SELECT id FROM polls WHERE question='".$question."' "));
mysql_query("UPDATE users SET pollid='".$pollid[0]."' WHERE id='".getuid_sid($sid)."'");
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Your poll created successfully\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Database Eroor!\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>There's already a poll with the same question\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>The poll must have a question, and at least 2 options\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You already have a poll\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You should have at least 50 plusses to create a poll\n";
}
$main.="</p>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?poll=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($vote==1)
{
echo head_tag(getnick_sid($sid)."@Voting In A Poll",1,getuid_sid($sid));
addonline(getuid_sid($sid),"Vote","");
$title="Vote";
$main="<p align=".align().">\n";
$voted=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE uid='".getuid_sid($sid)."' AND pollid='".$id."'"));
if($voted[0]==0){
$res=mysql_query("INSERT INTO pollresults SET uid='".getuid_sid($sid)."', pollid='".$id."', answer='".$answer."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Thanx for your voting\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Database Error!\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>You already voted for this poll\n";
}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
echo head_tag(getnick_sid($sid)."@Deleting Poll",1,getuid_sid($sid));
addonline(getuid_sid($sid),"Deleting Poll","");
$title="Deleting Poll";
$main="<p align=".align().">\n";

$pid=mysql_fetch_array(mysql_query("SELECT pollid FROM users WHERE id='".getuid_sid($sid)."'"));
$res=mysql_query("UPDATE users SET pollid='0' WHERE id='".getuid_sid($sid)."'");
if($res){
$res=mysql_query("DELETE FROM pollresults WHERE pollid='".$pid[0]."'");
$res=mysql_query("DELETE FROM polls WHERE id='".$pid[0]."'");
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Poll Deleted\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Database Error!\n";
}
$main.="</p>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?poll=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@Poll",1,getnick_uid($who));
addonline(getuid_sid($sid),"Viewing Poll","");
$title="Poll";
$main="<p align=".align().">\n";
$pollid=mysql_fetch_array(mysql_query("SELECT pollid FROM users WHERE id='".$who."'"));
if($pollid[0]>0){
$polli=mysql_fetch_array(mysql_query("SELECT id, question, option1, option2, option3, option4, option5, date FROM polls WHERE id='".$pollid[0]."'"));
if(trim($polli[1])!=""){
$main.="<b>Question:</b> ".getbbcode($polli[1],$sid,1)."<br/>
<b>Created:</b> ".date("h:ia - l jS F Y",$polli[7])."<br/>
<br/>\n";
$vdone=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE uid='".getuid_sid($sid)."' AND pollid='".$pollid[0]."'"));
$nov=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE pollid='".$pollid[0]."'"));
$nov=$nov[0];
if($vdone[0]>0){$voted=true;}
else{$voted=false;}
$opt1=$polli[2];
if(trim($opt1)!=""){
$opt1=htmlspecialchars($opt1);
$nov1=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE pollid='".$pollid[0]."' AND answer='1'"));
$nov1=$nov1[0];
if($nov>0){
$per=floor(($nov1/$nov)*100);
$rests="<small>$nov1 Votes</small> $per%";
}else{
$rests="<small>0 Votes</small> 0%";
}
if($voted||!islogged($sid)){
$lnk="<b>1.</b> $opt1 $rests<br/>";
}else{
$lnk="<b>1.</b> <a href=\"./poll.php?vote=1&amp;id=$pollid[0]&amp;answer=1&amp;sid=$sid\">$opt1</a> $rests<br/>";
}
$main.="$lnk";
}
$opt2=$polli[3];
if(trim($opt2)!=""){
$opt2=htmlspecialchars($opt2);
$nov2=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE pollid='".$pollid[0]."' AND answer='2'"));
$nov2=$nov2[0];
if($nov>0){
$per=floor(($nov2/$nov)*100);
$rests="<small>$nov2 Votes</small> $per%";
}else{
$rests="<small>0 Votes</small> 0%";
}
if($voted||!islogged($sid)){
$lnk="<b>2.</b> $opt2 $rests<br/>";
}else{
$lnk="<b>2.</b> <a href=\"./poll.php?vote=1&amp;id=$pollid[0]&amp;answer=2&amp;sid=$sid\">$opt2</a> $rests<br/>";
}
$main.="$lnk";
}
$opt3=$polli[4];
if(trim($opt3)!=""){
$opt3=htmlspecialchars($opt3);
$nov3=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE pollid='".$pollid[0]."' AND answer='3'"));
$nov3=$nov3[0];
if($nov>0){
$per=floor(($nov3/$nov)*100);
$rests="<small>$nov3 Votes</small> $per%";
}else{
$rests="<small>0 Votes</small> 0%";
}
if($voted||!islogged($sid)){
$lnk="<b>3.</b> $opt3 $rests<br/>";
}else{
$lnk="<b>3.</b> <a href=\"./poll.php?vote=1&amp;id=$pollid[0]&amp;answer=3&amp;sid=$sid\">$opt3</a> $rests<br/>";
}
$main.="$lnk";
}
$opt4=$polli[5];
if(trim($opt4)!=""){
$opt4=htmlspecialchars($opt4);
$nov4=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE pollid='".$pollid[0]."' AND answer='4'"));
$nov4=$nov4[0];
if($nov>0){
$per=floor(($nov4/$nov)*100);
$rests="<small>$nov4 Votes</small> $per%";
}else{
$rests="<small>0 Votes</small> 0%";
}
if($voted||!islogged($sid)){
$lnk="<b>4.</b> $opt4 $rests<br/>";
}else{
$lnk="<b>4.</b> <a href=\"./poll.php?vote=1&amp;id=$pollid[0]&amp;answer=4&amp;sid=$sid\">$opt4</a> $rests<br/>";
}
$main.="$lnk";
}
$opt5=$polli[6];
if(trim($opt5)!=""){
$opt5=htmlspecialchars($opt5);
$nov5=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM pollresults WHERE pollid='".$pollid[0]."' AND answer='5'"));
$nov5=$nov5[0];
if($nov>0){
$per=floor(($nov5/$nov)*100);
$rests="<small>$nov5 Votes</small> $per%";
}else{
$rests="<small>0 Votes</small> 0%";
}
if($voted||!islogged($sid)){
$lnk="<b>5.</b> $opt5 $rests<br/>";
}else{
$lnk="<b>5.</b> <a href=\"./poll.php?vote=1&amp;id=$pollid[0]&amp;answer=5&amp;sid=$sid\">$opt5</a> $rests<br/>";
}
$main.="$lnk";
}
}else{
$main.="<img src=\"../images/notok.gif\" alt=\"x\"/>This poll doesn't exist";
}
}else{
$main.="<img src=\"../images/notok.gif\" alt=\"x\"/>This user have no poll";
}
$main.="</p>\n";
if(islogged($sid)){
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>
