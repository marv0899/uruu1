<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if($sid!=""&&$sid!="guest"){
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW WAPSITE INTERESTS/////////////////////////

echo head_tag(getnick_sid($sid)."@View Interests",1,getnick_uid($who));
$nick=getnick_uid($who).htmlspecialchars("'",ENT_QUOTES)."s";
if(getuid_sid($sid)==$who)$nick="My";
addonline(getuid_sid($sid),"Viewing $nick Interests","");
$info=mysql_fetch_array(mysql_query("SELECT * FROM users a INNER JOIN profiles b ON a.id = b.uid WHERE a.id='".$who."'"));
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
$title="$nick Interests";
$main="<p align=".align().">
<b>Makes Me Happy</b>: ".$wapsite[happy]."<br/>
<b>Makes Me Sad</b>: ".$wapsite[sad]."<br/>
<b>Interests</b>: ".$wapsite[interests]."<br/>
<b>Profession</b>: ".$wapsite[profession]."<br/>
<b>Bad Habits</b>: ".$wapsite[badhabits]."<br/>
<b>Good Habits</b>: ".$wapsite[goodhabits]."<br/>
<br/>
<a href=\"./profile2.php?who=$who&amp;sid=$sid\">&lt;-Back</a> | 
<a href=\"./profile4.php?who=$who&amp;sid=$sid\">Next-&gt;</a><br/>
$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back To Wapsite</a>
</p>\n";
if(islogged($sid)){
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>