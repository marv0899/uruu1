<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if($sid!=""&&$sid!="guest"){
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////VIEW BLOGS/////////////////////////

if($read==1)
{
$blogs=mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE id='".$id."'"));
$who=$blogs[uid];
echo head_tag(getnick_sid($sid)."@Reading Blog",1,getnick_uid($who));
addonline(getuid_sid($sid),"Read Blog","");
$title="<b>Read Blog</b>";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
$main.="<b>Date:</b> ".date("l jS F",$blogs["date"])."
</p>
<p align=".align().">
".getbbcode($blogs["subject"],$sid,1)."
</p> 
<p align=".align().">
".getbbcode($blogs["body"],$sid,1)."
</p>
<p align=".align().">\n";
if($wapsite[blog_comments]==1){
$main.="$onekey<a $key1 href=\"./blogs.php?comments=add&amp;id=$id&amp;who=$who&amp;sid=$sid\">Add Comment</a><br/>\n";
$comments=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blog_comments WHERE blogid='".$id."'"));
$main.="$twokey<a $key2 href=\"./blogs.php?comments=view&amp;id=$id&amp;who=$who&amp;sid=$sid\">$comments[0] Comments</a><br/>\n";
}
if(islogged($sid)){
$main.="$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$main.="</p>\n";
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($add==1)
{
echo head_tag(getnick_sid($sid)."@Adding Blog",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Add Blog","");
$title="<b>Add Blog</b>";
$main="<div class=".align().">
<form action=\"./blogs.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Subject:</b><br/>
<input type=\"text\" name=\"subject\" value=\"\" maxlength=\"50\"/><br/>
<b>Text:</b><br/>
<input type=\"text\" name=\"body\" value=\"\" maxlength=\"255\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?blogs=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($edit==1)
{
echo head_tag(getnick_sid($sid)."@Edit Blog",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Edit Blog","");
$title="<b>Edit Blog</b>";
$blogs=mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE uid='".getuid_sid($sid)."' AND id='".$id."'"));
$main="<div class=".align().">
<form action=\"./blogs.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Subject:</b><br/>
<input type=\"text\" name=\"subject\" value=\"$blogs[subject]\" maxlength=\"50\"/><br/>
<b>Text:</b><br/>
<input type=\"text\" name=\"body\" value=\"$blogs[body]\" maxlength=\"255\"/><br/>
<input type=\"hidden\" name=\"id\" value=\"$id\"/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./update.php?blogs=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save==1)
{
echo head_tag(getnick_sid($sid)."@Saving Blog",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Saving Blog","");
$title="<b>Saving Blog</b>";
$main="<p align=".align().">\n";
$blog_exist=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE id='".$id."'"));
if($blog_exist[0]==0){
$res=mysql_query("INSERT INTO blogs SET uid='".getuid_sid($sid)."', subject='".$subject."', body='".$body."', date='".time()."'");
}else{
$res=mysql_query("UPDATE blogs SET subject='".$subject."', body='".$body."' WHERE id='".$id."'");
}
if($res){
if(isspam($subject)||isspam($body)){mysql_query("UPDATE blogs SET reported='1' WHERE subject='".$subject."'");}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Blog Successfully Saved<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Blog<br/>\n";
}
$main.="$fivekey<a $key5 href=\"./update.php?blogs=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
echo head_tag(getnick_sid($sid)."@Deleting Blog",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Deleting Blog","");
$title="<b>Deleting Blog</b>";
$main="<p align=".align().">\n";
$blog_exist=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE id='".$id."'"));
if($blog_exist[0]==1){
$res=mysql_query("DELETE FROM blogs WHERE uid='".getuid_sid($sid)."'AND id='".$id."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Blog Successfully Deleted<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Deleting Blog<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Blog Does Not Exist<br/>\n";
}
$main.="$fivekey<a $key5 href=\"./update.php?blogs=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($comments=="view")
{
echo head_tag(getnick_sid($sid)."@Blog Comments",1,getnick_uid($who));
addonline(getuid_sid($sid),"Blog Comments","profile.php?who=$who");
$title="<b>Blog Comments</b>";
$main="<p align=".align().">\n";
$blog=mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE id='".$id."'"));
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blog_comments WHERE blogid='".$id."'"));
$num_items=$noi[0];
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT * FROM blog_comments WHERE blogid='".$id."' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$query=mysql_query($sql);
if(mysql_num_rows($query)>0){
while($row_comments=mysql_fetch_array($query)){
$main.="<b>Date:</b> ".date("l jS F",$row_comments["date"])."<br/>
<b>Nickname:</b> ".getnick_uid($row_comments[uid])."<br/>
<b>Comment:</b> ".getbbcode($row_comments["comment"],$sid,1)."<br/>\n";
if($blog[uid]==getuid_sid($sid)){
$main.="<a href=\"./blogs.php?comments=delete&amp;id=$row_comments[id]&amp;sid=$sid\">[Delete]</a>\n";
}
if(mysql_num_rows($query)>1)$main.="<br/>\n";
}
$main.="<br/>\n";
if($page>1){
$main.="<br/><a href=\"./blogs.php?id=$id&amp;who=$who&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./blogs.php?id=$id&amp;who=$who&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages";
//if($num_pages>2){$main.=getjumper("guestbook","who","$who",$sid);}
}else{
$main.="Blog Has No Comments\n";
}
if(islogged($sid)){
$main.="</p>
<p align=".align().">
$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$main.="</p>\n";
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($comments=="add")
{
echo head_tag(getnick_sid($sid)."@Adding Blog Comment",1,getnick_uid($who));
addonline(getuid_sid($sid),"Add Blog Comment","profile.php?who=$who");
$title="<b>Add Blog Comment</b>";
$main="<div class=".align().">
<form action=\"./blogs.php?comments=save&amp;who=$who&amp;id=$id&amp;sid=$sid\" method=\"post\">
<b>Comment:</b><br/>
<input type=\"text\" name=\"comment\" value=\"\" maxlength=\"255\"/><br/>
<input type=\"submit\" value=\"Save\"/>
</form>
</div>
<p align=".align().">
$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($comments=="save")
{
if(islogged($sid)){
echo head_tag(getnick_sid($sid)."@Saving Blog Comment",1,getnick_uid($who));
addonline(getuid_sid($sid),"Saving Blog Comment","");
$title="<b>Saving Blog Comment</b>";
$main="<p align=".align().">\n";
$wapsite=mysql_fetch_array(mysql_query("SELECT * FROM wapsite WHERE uid='".$who."'"));
$blog=mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE id='".$id."'"));
if($wapsite[blog_comments]==1){
$res=mysql_query("INSERT INTO blog_comments SET uid='".getuid_sid($sid)."', blogid='".$id."', comment='".$comment."', date='".time()."'");
if($res){
if($blog[uid]!=getuid_sid($sid)&&automsgs($blog[uid])){
$msg="Your Blog [blog=$id]".$blog[subject]."[/blog] has received a comment by ".getnick_sid($sid)."[br/][small][i]p.s: this is an automated pm[/i][/small]";
autopm($msg,$blog[uid]);
}
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Blog Comment Successfully Saved<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Saving Blog Comment<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>User Has Turned Off Blog Comments<br/>\n";
}
}else{
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(islogged($sid)){
$main.="$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($comments==delete)
{
echo head_tag(getnick_sid($sid)."@Deleting Blog Comment",1,getnick_sid($sid));
addonline(getuid_sid($sid),"Deleting Blog Comment","");
$title="<b>Deleting Blog Comment</b>";
$main="<p align=".align().">\n";
$comment_exist=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blog_comments WHERE id='".$id."'"));
$blog_comment=mysql_fetch_array(mysql_query("SELECT * FROM blog_comments WHERE id='".$id."'"));
$blog=mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE id='".$blog_comment[blogid]."'"));
if($blog[uid]==getuid_sid($sid)){
if($comment_exist[0]==1){
$res=mysql_query("DELETE FROM blog_comments WHERE id='".$id."'");
if($res){
$main.="<img src=\"../images/ok.gif\" alt=\"[o]\"/>Blog Comment Successfully Deleted<br/>\n";
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Error Deleting Blog Comment<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>Blog Comment Does Not Exist<br/>\n";
}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>This Blog Comment Is Not From Your Blog<br/>\n";
}
$main.="$fivekey<a $key5 href=\"./update.php?blogs=1&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

echo head_tag(getnick_sid($sid)."@View Blogs",1,getnick_uid($who));
addonline(getuid_sid($sid),"View Blogs","profile.php?who=$who");
$title="<b>View Blogs</b>";
$main="<p align=".align().">\n";
if($page==""||$page<=0)$page=1;
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blogs WHERE uid='".$who."'"));
$num_items=$noi[0];
$items_per_page=5;
$num_pages=ceil($num_items/$items_per_page);
if(($page>$num_pages)&&$page!=1)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
$sql="SELECT * FROM blogs WHERE uid='".$who."' ORDER BY date DESC LIMIT $limit_start, $items_per_page";
$query=mysql_query($sql);
if(mysql_num_rows($query)>0){
while($row_blogs=mysql_fetch_array($query)){
$main.="<a href=\"./blogs.php?read=1&amp;id=".$row_blogs["id"]."&amp;who=$who&amp;sid=$sid\">[Read]</a> 
".getbbcode($row_blogs["subject"],$sid,1)." 
<small>".date("l jS F",$row_blogs["date"])."</small><br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./blogs.php?who=$who&amp;page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./blogs.php?who=$who&amp;page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("blogs","who","$who",$sid);}
}else{
$main.="<img src=\"../images/error.gif\" alt=\"[x]\"/>".getnick_uid($who)." Has No Blogs<br/>\n";
}
if(islogged($sid)){
$main.="$fivekey<a $key5 href=\"./wapsite.php?who=$who&amp;sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"../chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
}else{
$main.="</p>\n";
$L1="$zerokey<a $key0 href=\"../index.php\"><img src=\"../images/home.gif\" alt=\"\"/>".sitename()."</a>\n";
}
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>