<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(chatbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo chatbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////PUBLIC CHATROOMS/////////////////////////

addonline(getuid_sid($sid),"Chatroom List","");
echo head_tag(getnick_sid($sid)."@Chatroom List",1,getnick_sid($sid));
$title="<b>Chatroom List</b>";
$main="<p align=".align().">\n";
$rooms=mysql_query("SELECT id, name FROM chatrooms WHERE public='1' AND clubid='0'");
while($room= mysql_fetch_array($rooms)){
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatonline WHERE rid='".$room[0]."'"));
$main.="<a href=\"chat.php?action=chat&amp;sid=$sid&amp;rid=$room[0]\">$room[1] $noi[0]</a><br/>\n";
}
$main.="<br/>$sixkey<a $key6 href=\"./private.php?sid=$sid\">Private Rooms</a>\n</p>\n";
$L1="$sevenkey<a $key7 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$eightkey<a $key8 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L4="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,0,0,0,0,$main);
echo foot_tag();
?>