<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(chatbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo chatbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CHAT/////////////////////////

if($pass!=""){$pw="&amp;pass=$pass";}
$roomname=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$title="<b>".getnick_sid($sid)."@$roomname[1]</b>";
$isroom=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatrooms WHERE id='".$rid."'"));
if($isroom[0]==0){
echo head_tag(getnick_sid($sid)."@".$roomname[1],1,getnick_sid($sid));
$main="<p align=".align().">
<b>Room Doesn't Exist</b><br/>
You can't enter this room
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
$passworded=mysql_fetch_array(mysql_query("SELECT password FROM chatrooms WHERE id='".$rid."'"));
if($passworded[0]!=""){
if($pass!=$passworded[0]){
echo head_tag(getnick_sid($sid)."@".$roomname[1],1,getnick_sid($sid));
$main="<p align=".align().">
<b>Enter Password!</b>
</p>\n";
$main.="<div class=".align().">
<form action=\"chat.php?sid=$sid&amp;rid=$roomname[0]\" method=\"post\">
<b>Room Name:</b><br/>$roomname[1]<br/>
<b>Password:</b><br/><input name=\"pass\" maxlength=\"10\"/><br/>
<input type=\"submit\" Value=\"Enter\"/>
</form>
</div>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
}

if(!canenter(getuid_sid($sid),$rid))
{
echo head_tag(getnick_sid($sid)."@".$roomname[1],1,getnick_sid($sid));
$main="<p align=".align().">
<img src=\"../images/error.gif\" alt=\"[x]\"/><b>Permission denied!</b><br/>
You can't enter this room
</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addtochat(getuid_sid($sid),$rid);
$timeto=300;
$timenw=time();
$timeout=$timenw-$timeto;
$deleted=mysql_query("DELETE FROM chat WHERE timesent<".$timeout."");
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
echo "<head>
<title>".getnick_sid($sid)."@$roomname[1]</title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"../style.php?uid=".getnick_sid($sid)."\"/>\n";
if($count_popup[0]<1){
echo "<meta http-equiv=\"refresh\" content=\"20; url=chat.php?sid=$sid&amp;rid=$rid$pw\"/>\n";
}
echo "</head>
<body>\n";
addonline(getuid_sid($sid),"Chatting In ".$roomname[1],"chat/chat.php?rid=$rid$pw");
if($count_popup[0]>0){
$rname=mysql_fetch_array(mysql_query("SELECT name FROM chatrooms WHERE id='".$rid."'"));
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main.="<div class=\"left\">
<b>Popup Message<br/>
From $usersex<span style=\"color:$color;\">".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"../popups.php?send=1&amp;who=$pminfo[2]&amp;msgid=$pminfo[0]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>";
$main.="<a href=\"./chat.php?rid=$rid&amp;sid=$sid$pw\">Skip Msg</a>\n";
//$main.="<a href=\"inbxproc.php?action=rptpop&amp;sid=$sid&amp;pmid=$pminfo[0]\">Report</a><br/>";
$main.="</div>\n";
}
$main.="$onekey<a $key1 name=\"top\" id=\"top\" href=\"write.php?sid=$sid&amp;rid=$rid$pw\">Write</a><br/>
$twokey<a $key2 href=\"#opt\">options</a><br/>\n";
$unreadinbox=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
$unrd="".$unreadinbox[0]."";
if($unreadinbox[0]>0){
$inbox="Inboxes";
if($unreadinbox[0]==1)$inbox="Inbox";
$main.="$fivekey<a $key5 href=\"../inbox/inbox.php?sid=$sid&amp;rid=$rid$pw\">$unrd New $inbox!</a><br/>\n";
}
$main.="$Skey<a $keyS href=\"./chat.php?sid=$sid&amp;rid=$rid$pw\">Refresh</a><br/>\n";
$message=$_POST["message"];
$who=$_POST["who"];
$rinfo=mysql_fetch_array(mysql_query("SELECT censored, freaky FROM chatrooms WHERE id='".$rid."'"));
if(trim($message)!=""){
if(!blocked_site($message,getuid_sid($sid)))
{
if($to_user=="*")$to_user="";
$chatok=mysql_query("INSERT INTO chat SET uid='".getuid_sid($sid)."', toid='".$to_user."', timesent='".time()."', text='".$message."', rid='".$rid."'");
$points=mysql_fetch_array(mysql_query("SELECT points FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$update=$points[0]+1;
$point=mysql_query("UPDATE profiles SET points='".$update."' WHERE uid='".getuid_sid($sid)."'");
$lstmsg=mysql_query("UPDATE chatrooms SET lastmsg='".time()."' WHERE id='".$rid."'");
$hehe=mysql_fetch_array(mysql_query("SELECT chatmsgs FROM profiles WHERE uid='".getuid_sid($sid)."'"));
$totl=$hehe[0]+1;
$msgst=mysql_query("UPDATE profiles SET chatmsgs='".$totl."' WHERE uid='".getuid_sid($sid)."'");
$clubid=mysql_fetch_array(mysql_query("SELECT clubid FROM chatrooms WHERE id='".$rid."'"));
$pts=mysql_fetch_array(mysql_query("SELECT points FROM clubs WHERE id='".$clubid[0]."'"));
if($clubid[0]!=0){mysql_query("UPDATE clubs SET points='".($pts[0]+1)."' WHERE id='".$clubid[0]."'");}
}else{
$bantime=time()+(30*24*60*60);
$main.="<img src=\"images/notok.gif\" alt=\"X\"/><br/>Can't Post Msg<br/>
You just tried sending a msg with a link to one of the crapiest sites on earth<br/>
The members of these sites spam here a lot, so go to that site and stay there if you don't like it here<br/>
as a result of your stupid action:<br/>
1. you have lost your sheild<br/>
2. you have lost all your plusses<br/>
3. You are BANNED!";
mysql_query("INSERT INTO logs SET action='autoban', details='<b>".getnick_uid(1)."</b> auto banned ".getnick_sid($sid)." for spamming chat', date='".time()."'");
mysql_query("INSERT INTO banned SET uid='".getuid_sid($sid)."', penalty='3', byid='1', remaining='".$bantime."', reason='Banned: Automatic Ban for spamming for a crap site'");
mysql_query("UPDATE profiles SET points='0', WHERE uid='".getuid_sid($sid)."'");
mysql_query("INSERT INTO inbox SET text='[b](forwarded spam via chat)[/b][br/]".$message."', byid='".getuid_sid($sid)."', toid='1', reported='1', timesent='".time()."'");
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
if($rinfo[1]==2){
$botid="eeb070e74e366473";
$hostname="www.pandorabots.com";
$hostpath="/pandora/talk-xml";
$sendData="botid=".$botid."&input=".urlencode($message)."&custid=".$custid;
$result=PostToHost($hostname, $hostpath, $sendData);
$pos=strpos($result, "custid=\"");
$pos=strpos($result, "<that>");
if($pos===false){$reply="";}
else{
$pos+=6;
$endpos=strpos($result, "</that>", $pos);
$reply=substr($result, $pos, $endpos - $pos);
$reply=mysql_escape_string($reply);
}
$chatok=mysql_query("INSERT INTO chat SET uid='1', toid='', timesent='".time()."', text='".$reply." @".getnick_uid(getuid_sid($sid))."', rid='".$rid."';");
}
$message="";
}
$main.="<p>\n";
$chats=mysql_query("SELECT uid, toid, timesent, text, exposed FROM chat WHERE rid='".$rid."' ORDER BY timesent DESC, id DESC");
$counter=0;
while($chat=mysql_fetch_array($chats)){
$canc=true;
if($counter<40){
/*if(ignored($chat[0],getuid_sid($sid))){$canc=false;}*/
if($chat[0]!=getuid_sid($sid)){
if($chat[1]!=0){
if($chat[1]!=getuid_sid($sid)){$canc=false;}
}
}
if(($chat[4]=='1')&&(ismod(getuid_sid($sid)))){$canc=true;}
if($canc){
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='$chat[0]'"));
if($sex[0]=="M"){$usersex="<img src=\"../images/male.gif\" alt=\"(M)\"/>";$color=" style=\"color:#0000FF\"";}
if($sex[0]=="F"){$usersex="<img src=\"../images/female.gif\" alt=\"(F)\"/>";$color=" style=\"color:#FF0066\"";}
if($sex[0]==""){$usersex="";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$chnick=getnick_uid($chat[0]);
$optlink=$usersex.$chnick;
if(($chat[1]!=0)&&($chat[0]==getuid_sid($sid))){$optlink="<img src=\"../images/out.gif\" alt=\"!\"/>Pm To ".getnick_uid($chat[1])."";}
if($chat[1]==getuid_sid($sid)){$optlink="<img src=\"../images/in.gif\" alt=\"!\"/>Pm By ".getnick_uid($chat[0])."";}
if($chat[4]=='1'){$optlink="<img src=\"../images/point.gif\" alt=\"!\"/>".getnick_uid($chat[0])."<img src=\"../images/in.gif\" alt=\"!\"/>".getnick_uid($chat[1])."";}
if(isspam(getbbcode($chat[3],$sid,1))){$main.="<b>Chat System&#187;<i>*oi! ".getnick_uid($chat[0]).", no spamming*</i></b><br/>";}
else if(substr_count(getbbcode($chat[3],$sid,1),"<img src=")>2){$main.="<b>Chat System&#187;<i>*hey! ".getnick_uid($chat[0]).", you can only use 2 smilies per msg*</i></b><br/>";}
else{
$flood=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chat WHERE text='".htmlspecialchars($chat[3],ENT_QUOTES)."' AND uid='".$chat[0]."'"));
if(substr($chat[3],0,3)=="/me"){$main.="<b>$chnick&#187;<i>*".getbbcode(substr($chat[3],4,strlen($chat[3])-3),$sid,1)."*</i></b><br/>";}
else if($flood[0]>1){$main.="<b>Chat System&#187;<i>*hey! ".getnick_uid($chat[0]).", U Cannot Flood This Room!*</i></b><br/>";
$points=mysql_fetch_array(mysql_query("SELECT points FROM profiles WHERE uid='".$chat[0]."'"));
$update=$points[0]-1;
$point=mysql_query("UPDATE profiles SET points='".$update."' WHERE uid='".$chat[0]."'");
mysql_query("DELETE FROM chat WHERE text='".$chat[3]."' AND uid='$chat[0]' LIMIT 1");
}
else if($chat[3]!=""){
if($rinfo[0]==0){$tosay=getbbcode($chat[3],$sid,0);}
else{$tosay=getbbcode($chat[3],$sid,1);}
if($rinfo[1]==1){$tosay=strrev($tosay);}
$main.="<a href=\"./pm.php?who=$chat[0]&amp;sid=$sid&amp;rid=$rid$pw\"$color>$optlink</a> - $tosay<br/>\n";
}
}
$counter++;
}
}
}
$main.="</p>
$Skey<a $keyS name=\"opt\" id=\"opt\" href=\"./chat.php?sid=$sid&amp;rid=$rid$pw\">Refresh</a><br/>
$onekey<a $key1 href=\"./write.php?sid=$sid&amp;rid=$rid$pw\">Write</a><br/>
$threekey<a $key3 href=\"./settings.php?sid=$sid&amp;rid=$rid$pw\">Settings</a><br/>";
$chatters=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatonline where rid='".$rid."'"));
$main.="$fourkey<a $key4 href=\"./inside.php?sid=$sid&amp;rid=$rid$pw\">Whos Inside $chatters[0]</a><br/>
$fivekey<a $key5 href=\"../inbox/inbox.php?sid=$sid&amp;rid=$rid$pw\">Inbox</a><br/>
$sixkey<a $key6 href=\"../buds/buds.php?sid=$sid\">BuddyList</a><br/>
$sevenkey<a $key7 href=\"./public.php?sid=$sid\">Chat</a><br/>
$eightkey<a $key8 href=\"../forums/forums.php?sid=$sid\">Forums</a><br/>
$ninekey<a $key9 href=\"#top\">Top</a> | 
$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>