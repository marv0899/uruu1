<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(chatbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo chatbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////WRITE PRIVATE CHAT MSG/////////////////////////

if($pass!=""){$pw="&amp;pass=$pass";}
$roomname=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
addonline(getuid_sid($sid),"Writing Chat Msg","");
echo head_tag(getnick_sid($sid)."@Writing Chat Msg",1,getnick_sid($sid));
$title="<b>Writing Chat Msg</b>";
$main="<p align=".align().">
<b>Send Pm To ".getnick_uid($who)."</b>
</p>
<div class=".align().">
<form action=\"./chat.php?sid=$sid&amp;rid=$rid$pw\" method=\"post\">
<b>Message:</b><br/>
<input name=\"message\" type=\"text\" maxlength=\"500\"/><br/>
<input type=\"hidden\" name=\"to_user\" value=\"$who\"/>
<input type=\"submit\" Value=\"Send\"/>
</form>
</div>\n";
$main.="<p align=".align().">\n$twokey<a $key2 href=\"./chat.php?sid=$sid&amp;rid=$rid$pw\">Back To $roomname[1]</a>\n";
if(mod_tools("rid",$rid,0,getuid_sid($sid),1)){
$main.="<br/>
<br/>$threekey<a $key3 href=\"./clear.php?who=$who&amp;sid=$sid&amp;rid=$rid$pw\">Clear Msgs</a>\n";
}
$main.="</p>\n";
$L1="$fourkey<a $key4 href=\"../profile.php?sid=$sid&amp;who=$who&amp;rid=$rid$pw\">View ".getnick_uid($who)."'s Profile</a>";
$L2="$fivekey<a $key5 href=\"./expose.php?who=$who&amp;sid=$sid&amp;rid=$rid$pw\">Expose ".getnick_uid($who)."'s Msgs</a>";
$L3="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L4="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L5="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L6="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L7="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,$L6,$L7,0,$main);
echo foot_tag();
?>