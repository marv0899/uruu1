<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(chatbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo chatbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////WRITE CHAT MSG/////////////////////////

if($pass!=""){$pw="&amp;pass=$pass";}
$roomname=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
addonline(getuid_sid($sid),"Writing Chat Msg","chat.php?action=$action&amp;rid=$rid$pass");
echo head_tag(getnick_sid($sid)."@Writing Chat Msg",1,getnick_sid($sid));
$title="<b>Writing Chat Msg</b>";
$main="<div class=".align().">
<form action=\"chat.php?sid=$sid&amp;rid=$rid$pw\" method=\"post\">
<b>Message:</b><br/>
<input name=\"message\" type=\"text\" maxlength=\"500\"/><br/>
<b>To:</b><br/>
<select name=\"to_user\">
<option value=\"*\">All</option>\n";
$query="select uid from chatonline where rid='".$rid."' and uid!='".getuid_sid($sid)."'";
$result=mysql_query($query);
while($row_chat=mysql_fetch_array($result)){
$nick=getnick_uid($row_chat["uid"]);
$main.="<option value=\"".$row_chat["uid"]."\">$nick</option>\n";
}
$main.="</select>
<input type=\"submit\" value=\"Send!\"/>
</form>
</div>\n";
$main.="<p align=".align().">\n$fivekey<a $key5 href=\"chat.php?sid=$sid&amp;rid=$rid$pw\">Back To $roomname[1]</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>