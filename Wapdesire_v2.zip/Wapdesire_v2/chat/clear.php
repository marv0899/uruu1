<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(chatbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo chatbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////CLEAR USER MSGS/////////////////////////

if($pass!=""){$pw="&amp;pass=$pass";}
$roomname=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
addonline(getuid_sid($sid),"Chat Options","");
echo head_tag(getnick_sid($sid)."@Chat Options",1,getnick_sid($sid));
$title="<b>Chat Options</b>";
$main="<p align=".align().">";
if(!mod_tools("rid",$rid,0,getuid_sid($sid),0)||!chat_tools(getuid_sid($sid),$who)){ 
$main.="<b><img src=\"../images/error.gif\" alt=\"x\"/><br/>Error!!!<br/>Permission Denied...</b><br/>
<br/>U Cannot Clear ".getnick_uid($who)."'s Msgs";
}else{
if(($who!="")||($who!=0)){
$res=mysql_query("DELETE FROM chat WHERE uid='".$who."'");
if($res){$main.=getnick_uid($who)."'s msgs have been cleared";}
else{$main.="Failed clearing ".getnick_uid($who)."'s msgs";}
}
else{$main.="Username does not exist";}
}
$main.="<br/><br/>\n$fivekey<a $key5 href=\"./chat.php?sid=$sid&amp;rid=$rid$pw\">Back To $roomname[1]</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>