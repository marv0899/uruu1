<?php
define('WCS',true);
include('../core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if(chatbanned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo chatbanned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////PRIVATE CHATROOMS/////////////////////////

if($create==1)
{
addonline(getuid_sid($sid),"Create Chatroom","chat.php?mode=$mode");
echo head_tag(getnick_sid($sid)."@Create Chatroom",1,getnick_sid($sid));
$title="<b>Create Chatroom</b>";
$main="<p align=".align().">\n";
if($password==""){$cns=1;}
else{$cns=0;}
$prooms=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatrooms WHERE public='0'"));
if($prooms[0]<10){
$res=mysql_query("INSERT INTO chatrooms SET name='".$name."', password='".$password."', censored='".$cns."', public='0', lastmsg='".time()."'");
if($res){$main.="<img src=\"../images/ok.gif\" alt=\"O\"/><br/>Room created successfully";}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>Database Error!";}
}
else{$main.="<img src=\"../images/error.gif\" alt=\"x\"/><br/>There's already 10 users rooms";}
$main.="\n</p>
<p align=".align().">\n$fivekey<a $key5 href=\"./private.php?sid=$sid\">Private Rooms</a>\n</p>\n";
$L1="$sixkey<a $key6 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Chatroom List","chat.php?action=$action");
echo head_tag(getnick_sid($sid)."@Chatroom List",1,getnick_sid($sid));
$title="<b>Private Room List</b>";
$main="<p align=".align().">\n";
$rooms=mysql_query("SELECT id, name FROM chatrooms WHERE public='0' AND clubid='0'");
while($room= mysql_fetch_array($rooms)){
$noi=mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM chatonline WHERE rid='".$room[0]."'"));
$main.="<a href=\"chat.php?action=chat&amp;sid=$sid&amp;rid=$room[0]\">$room[1] $noi[0]</a>
</p>";
}
$main.="<div class=".align().">
<form action=\"private.php?create=1&amp;sid=$sid\" method=\"post\">
<img src=\"../images/point.gif\" alt=\"!\"/><br/>
You can leave the password blank how ever anyone will be able to get in if you do<br/>
<b>Room Name:</b><input name=\"name\" maxlength=\"30\"/><br/>
<b>Password:</b><input name=\"password\" maxlength=\"10\"/><br/>
<input type=\"submit\" Value=\"Create\"/>
</form>
</div>\n";
$main.="<p align=".align().">\n$sixkey<a $key6 href=\"./public.php?sid=$sid\">Public Rooms</a>\n</p>\n";
$L1="$sevenkey<a $key7 href=\"../inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$eightkey<a $key8 href=\"../buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$ninekey<a $key9 href=\"../forums/forums.php?sid=$sid\">Forums</a>";
$L4="$zerokey<a $key0 href=\"../main.php?sid=$sid\"><img src=\"../images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,0,0,0,0,$main);
echo foot_tag();
?>