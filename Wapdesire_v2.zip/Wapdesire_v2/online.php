<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////ONLINE LIST/////////////////////////

addonline(getuid_sid($sid),"Online List","online.php");
echo head_tag(getnick_sid($sid)."@Online List",1,getnick_sid($sid));
$title="<b>Online Users ".getnumonline($sid)."</b>";
if($count_popup[0]>0){
$rname=mysql_fetch_array(mysql_query("SELECT name FROM chatrooms WHERE id='".$rid."'"));
$popsenabled=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".getuid_sid($sid)."'"));
$pminfo=mysql_fetch_array(mysql_query("SELECT id, text, byid, timesent, toid, reported FROM popups WHERE unread='1' AND toid='".getuid_sid($sid)."'"));
mysql_query("UPDATE popups SET unread='0' WHERE id='".$pminfo[0]."'");
if(isspam($pminfo[1])){mysql_query("UPDATE popups SET reported='1' WHERE id='".$pminfo[0]."'");}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image FROM profiles WHERE uid='".$pminfo[2]."'"));
if($sex[0]=="M"){$usersex="<img src=\"./images/male.gif\" alt=\"(M)\"/>";$color="#0000FF";}
if($sex[0]=="F"){$usersex="<img src=\"./images/female.gif\" alt=\"(F)\"/>";$color="#FF0066";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
$main="<div class=".align().">
<b>Popup Message<br/>
From $usersex<span style=\"color:$color;\">".getnick_uid($pminfo[2])."</span></b><br/>
<small>(".date("H:i-D jS M y",$pminfo[3]).")</small><br/>\n";
$main.=getbbcode($pminfo[1],$sid,1)."
<form action=\"./popups.php?send=1&amp;who=$pminfo[2]&amp;sid=$sid\" method=\"post\">
<b>Reply</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"submit\" value=\"Send\"/>
</form>
</div>\n";
$location=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$main.="<p align=".align().">
<a href=\"./$location[0]?sid=$sid\">Skip Msg</a><br/><br/>\n";
//$main.="<a href=\"inbxproc.php?action=rptpop&amp;sid=$sid&amp;pmid=$pminfo[0]\">Report</a><br/>";
if($rid!=""){$main.="<a href=\"./chat/chat.php?sid=$sid&amp;rid=$rid$pass\">Back To $rname[0]</a><br/>\n";}
}else{
$main="<p align=".align().">\n";
}
if($page==""||$page<=0)$page=1;
$num_items=getnumonline($sid);
$items_per_page=10;
$num_pages=ceil($num_items/$items_per_page);
if($page>$num_pages)$page=$num_pages;
$limit_start=($page-1)*$items_per_page;
if(!ghosts(getuid_sid($sid))){$hidden="a.hidden='0'";}
else{$hidden="a.hidden<'2'";}
$sql="
SELECT a.username, a.level, b.place, b.uid, a.hidden 
FROM users a INNER JOIN online b ON a.id = b.uid 
WHERE $hidden OR (a.id='".getuid_sid($sid)."' AND hidden='1') 
GROUP BY 1,2 LIMIT $limit_start, $items_per_page
";
$items=mysql_query($sql);
$main.=mysql_error();
while($item=mysql_fetch_array($items))
{
if($item[1]=='1'){$lvl="&#179;";}
else if($item[1]=='2'){$lvl="&#178;";}
else if($item[1]=='3'){$lvl="&#185;";}
else if($item[1]=='4'){$lvl="&#170;";}
else if($item[1]=='5'){$lvl="&#176;";}
else{$lvl="";}
$sex=mysql_fetch_array(mysql_query("SELECT sex, image, site_mood, mood FROM profiles WHERE uid='".$item[3]."'"));
if($sex[0]=="M"){$usersex="<img src=\"./images/male.gif\" alt=\"(M)\"/>";$color=" style=\"color:#0000FF\"";}
if($sex[0]=="F"){$usersex="<img src=\"./images/female.gif\" alt=\"(F)\"/>";$color=" style=\"color:#FF0066\"";}
if($sex[1]!=""){$usersex=getbbcode($sex[1],$sid,1);}
if($item[4]==1){$hide="<img src=\"./images/hidden.gif\" alt=\"[H]\"/>";}else{$hide="";}
if($sex[2]==1&&$sex[3]!=""){$item[2]=getbbcode($sex[3],$sid,1);}
$main.=$usersex.$lvl."<a href=\"./profile.php?who=$item[3]&amp;sid=$sid\"$color>".$item[0]."</a>".$hide." - ".$item[2]."<br/>\n";
}
if($page>1){
$main.="<br/><a href=\"./online.php?page=".($page-1)."&amp;sid=$sid\">&lt;-Prev</a> ";
}
if($page<$num_pages){
if($page==1)$main.="<br/>";
$main.="<a href=\"./online.php?page=".($page+1)."&amp;sid=$sid\">Next-&gt;</a>\n";
}
$main.="<br/>Page - $page/$num_pages</p>\n";
if($num_pages>2){$main.=getjumper("online","","",$sid);}
$L1="$sixkey<a $key6 title=\"Inbox\" href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 title=\"BuddyList\" href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 title=\"Chat\" href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 title=\"Forums\" href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 title=\"Main Menu\" href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>