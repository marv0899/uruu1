<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////LINKS/////////////////////////

if($add==1)
{
addonline(getuid_sid($sid),"Add Link","");
echo head_tag(getnick_sid($sid)."@Add Link",1,getnick_sid($sid));
$title="<b>Add Link</b>";
$main="<p align=".align().">\n";
if(link_tools(getuid_sid($sid))){
$main.="Please Enter The Address Of the Site To Add<br/>
</p>
<div class=".align().">
<form action=\"./links.php?save=1&amp;sid=$sid\" method=\"post\">
<b>Url Address:</b><br/>
<input name=\"url\" value=\"http://\"/><br/>
<b>Site Title:</b><br/>
<input name=\"name\"/><br/>
<input type=\"submit\" value=\"Add Link\">
</form>
</div>\n";
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>Permission Denied<br/>
<br/>\n";
}
$main.="<a href=\"./links.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($save==1)
{
addonline(getuid_sid($sid),"Adding Link","");
echo head_tag(getnick_sid($sid)."@Adding Link",1,getnick_sid($sid));
$title="<b>Adding Link</b>";
$main="<p align=".align().">\n";
if(link_tools(getuid_sid($sid))){
$res=mysql_query("INSERT INTO links SET url='".$url."', title='".$name."'");
if($res){
$main.="<img src=\"./images/ok.gif\" alt=\"[o]\"/>Site $title Added Successfully<br/>\n";
}else{
echo "<img src=\"./images/error.gif\" alt=\"[x]\"/>Error Adding Link<br/>\n";
}
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>Permission Denied<br/>\n";
}
$main.="<br/>
<a href=\"./links.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

else if($delete==1)
{
addonline(getuid_sid($sid),"Deleting Link","");
echo head_tag(getnick_sid($sid)."@Deleting Link",1,getnick_sid($sid));
$title="<b>Deleting Link</b>";
$main="<p align=".align().">\n";
if(link_tools(getuid_sid($sid))){
$sitename=mysql_fetch_array(mysql_query("SELECT title FROM links WHERE url='".$url."'"));
$res=mysql_query("DELETE FROM links WHERE url='".$url."'");
if($res){
$main.="<img src=\"./images/ok.gif\" alt=\"[o]\"/>$sitename[0] deleted Successfully<br/>\n";
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[X]\"/>Error deleting $sitename[0]<br/>\n";
}
}else{
$main.="<img src=\"./images/error.gif\" alt=\"[x]\"/>Permission Denied<br/>\n";
}
$main.="<br/>
<a href=\"./links.php?sid=$sid\">Back</a>
</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Links","");
echo head_tag(getnick_sid($sid)."@Links",1,getnick_sid($sid));
$title="<b>Links</b>";
$main="<p align=".align().">
If u have a site and want a link placed here inbox ".getnick_uid(1)."<br/>
<br/>\n";
$query=mysql_query("SELECT url, title FROM links");
if(mysql_num_rows($query)>0){
while($links=mysql_fetch_array($query)){
$link="<a href=\"$links[0]\">$links[1]</a>\n";
if(link_tools(getuid_sid($sid))){
$del=" <a href=\"./links.php?delete=1&amp;url=$links[0]&amp;sid=$sid\">
<img src=\"./images/error.gif\" alt=\"[x]\"/></a>\n";
}
$main.=$link.$del."<br/>";
}
}else{
$main.="No Links Atm...<br/>\n";
}
if(link_tools(getuid_sid($sid))){
$main.="<br/>\n<a href=\"./links.php?add=1&amp;sid=$sid\">Add Link</a>\n";
}
$main.="</p>";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>