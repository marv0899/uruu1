<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////LOGOUT/////////////////////////

addonline(getuid_sid($sid),"Logging Out","logout.php");
echo head_tag(getnick_sid($sid)."@Logout",1,getnick_sid($sid));
$title="<img src=\"./images/ok.gif\" alt=\"o\"/><br/><b>".getnick_sid($sid)."</b>";
$main="<p align=".align().">";
if(mysql_query("DELETE FROM ses WHERE uid='".getuid_sid($sid)."'")){
$main.="U Hav Successfully Logged Out Pls Come Back Soon :o)";
$L1="$zerokey<a $key0 href=\"./index.php\"><img src=\"./images/home.gif\" alt=\"\"/>Exit</a>";
}
else{
addonline(getuid_sid($sid),"Argh!!! Im Stuck...","");
$title="<img src=\"./images/error.gif\" alt=\"x\"/><br/><b>Error!!!</b>";
$main.="Unknown Error Cannot Log Out...";
$L1="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Back</a>";
}
$main.="</p>";
echo xhtml($sid,$title,1,$L1,0,0,0,0,0,0,0,$main);
echo foot_tag();
?>