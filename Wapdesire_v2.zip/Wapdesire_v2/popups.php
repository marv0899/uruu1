<?php
define('WCS',true);
include('./core/main.inc');
header_type();
cleardata();
if(ipbanned(ip(),browser())){
if(!shield(getuid_sid($sid))){
echo head_tag("Ip Blocked!!!",0,0);
echo ipbanned_msg();
echo foot_tag();
exit();
}
}
if(!islogged($sid)){
echo head_tag("Error!!!",0,0);
echo session_expired();
echo foot_tag();
exit();
}
if(banned(getuid_sid($sid))){
echo head_tag("Error!!!",1,getnick_sid($sid));
echo banned_msg($sid);
echo foot_tag();
exit();
}
if($pass!=""){$pw="&amp;pass=$pass";}
if($rid!=""){
$rooms=mysql_fetch_array(mysql_query("SELECT id, name FROM chatrooms WHERE id='".$rid."'"));
$rname=$rooms[1];
$chatlink="&amp;rid=$rid$pw";
}
mysql_query("UPDATE users SET browser='".browser()."', ipaddress='".ip()."', host='".subno()."' WHERE id='".getuid_sid($sid)."'");

/////////////////////////POPUPS/////////////////////////

if($send==1)
{
addonline(getuid_sid($sid),"Sending Popup","");
echo head_tag(getnick_sid($sid)."@Sending Popup",1,getnick_sid($sid));
$title="<b>Send Popup</b>";
$main="<p align=".align().">\n";
$popupson=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".$who."'"));
$lastinbox=mysql_fetch_array(mysql_query("SELECT MAX(timesent) FROM popups WHERE byid='".getuid_sid($sid)."'"));
if(($lastinbox[0]+antiflood())>time()){
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>
Flood control: ".(($lastinbox[0]+antiflood())-time())." Seconds
</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if(!isuser($who)){
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>User Does Not exist\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if(buds(getuid_sid($sid),$who)!=2){
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>".getnick_uid($who)." is not in your buddylist\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if(ignored(getuid_sid($sid),$who,0)==2){
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>
Failed Sending inbox To ".getnick_uid($who)." they hav u on ignore...\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if($popupson[0]==0){
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>
".getnick_uid($who)." has their popups disabled\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if(blocked_site($message,getuid_sid($sid))){
$bantime=time()+(30*24*60*60);
$main.="<img src=\"./images/error.gif\" alt=\"X\"/><br/>
Can't Send Popup to ".getnick_uid($who)."<br/>
You just sent a link to one of the crapiest sites on earth<br/>
The members of these sites spam here a lot, so go to that site and stay there if you don't like it here<br/>
as a result of your stupid action:<br/>
1. you have lost your sheild<br/>
2. you have lost all your plusses<br/>
3. You are BANNED!
</p>\n";
mysql_query("INSERT INTO logs SET action='autoban', details='<b>".getnick_uid(1)."</b> auto banned ".getnick_sid($sid)." for spamming via popups', date='".time()."'"); 
mysql_query("INSERT INTO banned SET uid='".getuid_sid($sid)."', penalty='3', byid='1', remaining='".$bantime."', reason='Banned: Automatic Ban for spamming for a crap site'");
mysql_query("UPDATE users SET points='0', shield='0' WHERE id='".getuid_sid($sid)."'");
mysql_query("INSERT INTO inbox SET text='[b](forwarded spam via popups)[/b][br/]".$message."', byid='".getuid_sid($sid)."', toid='1', reported='1', timesent='".time()."'");
echo xhtml($sid,$title,0,0,0,0,0,0,0,0,0,$main);
echo foot_tag();
exit;
}
if($message!=""){
if(isspam($message))$spam=" reported='1',";
else $spam="";
$res=mysql_query("INSERT INTO popups SET text='".$message."', byid='".getuid_sid($sid)."', toid='".$who."',$spam timesent='".time()."'");
}
if($res){
$main.="<img src=\"./images/ok.gif\" alt=\"o\"/><br/>
Popup sent to ".getnick_uid($who)."\n";
}else{
$main.="<img src=\"./images/error.gif\" alt=\"x\"/><br/>
Can't Send Popup to ".getnick_uid($who)."\n";
}
$link=mysql_fetch_array(mysql_query("SELECT link FROM online WHERE uid='".getuid_sid($sid)."'"));
$opt="?";
if(strpos($link[0],"?")==true){$opt="&amp;";}
$link_page=$link[0];
//if(!is_file("$link_page"))$link_page="../$link[0]";
$main.="<br/>$onekey<a $key1 href=\"".$link_page.$opt."sid=$sid$chatlink\">Ok!</a><br/>\n";
if($rid!=""){$main.="<br/>$fivekey<a $key5 href=\"./chat.php?sid=$sid$chatlink\">Back To $rname</a>\n";}
$main.="</p>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}

addonline(getuid_sid($sid),"Sending Popup","");
echo head_tag(getnick_sid($sid)."@Send Popup",1,getnick_sid($sid));
$title="<b>Send Popup</b>";
$popupson=mysql_fetch_array(mysql_query("SELECT popups FROM users WHERE id='".$who."'"));
if(!isuser($who)){
$main="<p align=".align().">
<img src=\"./images/error.gif\" alt=\"x\"/><br/>User Does Not exist\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if(buds(getuid_sid($sid),$who)!=2){
$main="<p align=".align().">
<img src=\"./images/error.gif\" alt=\"x\"/><br/>".getnick_uid($who)." is not in your buddylist\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if(ignored(getuid_sid($sid),$who,0)==2){
$main="<p align=".align().">
<img src=\"./images/error.gif\" alt=\"x\"/><br/>".getnick_uid($who)." hav chosen to ignore u\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit;
}
else if($popupson[0]==0){
$main="<p align=".align().">
<img src=\"./images/error.gif\" alt=\"x\"/><br/>".getnick_uid($who)." has their popups disabled\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
exit();
}
$main="<div class=".align().">
<form action=\"./popups.php?send=1&amp;sid=$sid$chatlink\" method=\"post\">
<b>To:</b> ".getnick_uid($who)."<br/>
<b>Message:</b><br/>
<input name=\"message\" maxlength=\"500\"/><br/>
<input type=\"hidden\" name=\"who\" value=\"$who\">
<input type=\"submit\" value=\"Send\">
</form>
<div>\n";
$L1="$sixkey<a $key6 href=\"./inbox/inbox.php?sid=$sid\">Inbox</a>";
$L2="$sevenkey<a $key7 href=\"./buds/buds.php?sid=$sid\">BuddyList</a>";
$L3="$eightkey<a $key8 href=\"./chat/public.php?sid=$sid\">Chat</a>";
$L4="$ninekey<a $key9 href=\"./forums/forums.php?sid=$sid\">Forums</a>";
$L5="$zerokey<a $key0 href=\"./main.php?sid=$sid\"><img src=\"./images/home.gif\" alt=\"\"/>Main Menu</a>";
echo xhtml($sid,$title,1,$L1,$L2,$L3,$L4,$L5,0,0,0,$main);
echo foot_tag();
?>